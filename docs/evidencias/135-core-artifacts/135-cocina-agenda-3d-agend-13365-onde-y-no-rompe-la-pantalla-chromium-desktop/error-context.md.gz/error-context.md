# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: 135-cocina-agenda-3d.spec.ts >> agenda: revisar sin Google conectado responde y no rompe la pantalla
- Location: tests\e2e\135-cocina-agenda-3d.spec.ts:86:5

# Error details

```
Error: expect(received).toEqual(expected) // deep equality

- Expected  - 1
+ Received  + 3

- Array []
+ Array [
+   "Failed to fetch",
+ ]
```

# Test source

```ts
  1   | import fs from 'node:fs';
  2   | import path from 'node:path';
  3   | import { test, expect, type Page } from '@playwright/test';
  4   | import { crearFiestaDeEstaNoche, guardarFiesta, borrarFiesta, ponerSesionDelEquipo } from './helpers/fiesta-de-prueba';
  5   | 
  6   | test.skip(process.env.AK_ENTORNO_AISLADO !== 'true', 'Solo copia QA ficticia');
  7   | const id = `e2e_135_${process.pid}_${Date.now()}`;
  8   | const budgetId = `${id}_presupuesto`;
  9   | const snapshots = new Map<string, Buffer | null>();
  10  | 
  11  | test.beforeAll(() => {
  12  |   const fiesta = crearFiestaDeEstaNoche({ id });
  13  |   fiesta.configuracion.nombreEvento = 'Cocina y salon QA135';
  14  |   fiesta.presupuestoId = budgetId;
  15  |   fiesta.invitados = [
  16  |     { id: 'celiaco', nombre: 'Familia QA135', rsvp: 'Confirmado', partySize: 5, dietaryRestriction: 'Celiaco' },
  17  |     { id: 'pendiente', nombre: 'Pendiente QA135', rsvp: 'Pendiente', partySize: 2, dietaryRestriction: 'Vegano' },
  18  |   ] as any;
  19  |   fiesta.listaMusicaPortal = { siEsPosible: ['Opcional QA135 - Artista QA135'] } as any;
  20  |   fiesta.decoracion = { ...fiesta.decoracion, salonWidth: 20, salonHeight: 15, pixelsPerMeter: 40,
  21  |     salonElements: [
  22  |       { id: 'mesa135', type: 'element', category: 'mesa', name: 'Mesa QA135', x: 180, y: 160, width: 80, height: 80, rotation: 0 },
  23  |       { id: 'pista135', type: 'area', category: 'pista', name: 'Pista QA135', x: 420, y: 300, width: 160, height: 160, rotation: 0 },
  24  |     ],
  25  |   } as any;
  26  |   guardarFiesta(fiesta);
  27  |   const presupuesto = { id: budgetId, clienteNombre: 'Cliente ficticio QA135', invitadosAdultos: 80,
  28  |     invitadosNinos: 15, invitadosAdolescentes: 5, totalFinal: 1000,
  29  |     itemsPresupuestados: [
  30  |       { idServicioCatalogo: 'dish_135_entrada', nombreServicio: 'Entrada QA135', categoriaServicio: 'Entrada' },
  31  |       { idServicioCatalogo: 'dish_135_principal', nombreServicio: 'Principal QA135', categoriaServicio: 'Plato Principal' },
  32  |       { idServicioCatalogo: 'dish_135_infantil', nombreServicio: 'Infantil QA135', categoriaServicio: 'Menu Infantil' },
  33  |       { idServicioCatalogo: 'dish_135_postre', nombreServicio: 'Postre QA135', categoriaServicio: 'Postre' },
  34  |     ] };
  35  |   for (const dir of ['data', 'src/data']) {
  36  |     const file = path.join(process.cwd(), dir, 'presupuestos.json');
  37  |     const prior = fs.existsSync(file) ? fs.readFileSync(file) : null;
  38  |     snapshots.set(file, prior);
  39  |     const rows = prior ? JSON.parse(prior.toString('utf8').replace(/^\uFEFF/, '')) : [];
  40  |     if (!Array.isArray(rows)) throw new Error('Unexpected QA budgets fixture');
  41  |     fs.mkdirSync(path.dirname(file), { recursive: true });
  42  |     fs.writeFileSync(file, JSON.stringify([...rows, presupuesto], null, 2));
  43  |   }
  44  | });
  45  | test.afterAll(() => {
  46  |   borrarFiesta(id);
  47  |   for (const [file, prior] of snapshots) {
  48  |     if (prior) fs.writeFileSync(file, prior);
  49  |     else if (fs.existsSync(file)) fs.unlinkSync(file);
  50  |   }
  51  | });
  52  | 
  53  | test.beforeEach(async ({ context, baseURL }) => {
  54  |   await context.route('**/*', (route) => {
  55  |     const url = new URL(route.request().url());
  56  |     return ['127.0.0.1', 'localhost'].includes(url.hostname) || ['data:', 'blob:'].includes(url.protocol)
  57  |       ? route.continue() : route.abort('blockedbyclient');
  58  |   });
  59  |   await context.addInitScript(() => { Reflect.deleteProperty(Navigator.prototype, 'serviceWorker'); });
  60  |   await ponerSesionDelEquipo(context, baseURL);
  61  | });
  62  | 
  63  | test('cocina: evento y porciones reales, recarga y salida de impresion', async ({ page }, info) => {
  64  |   await page.goto(`/fiestas/nueva/catering/hoja-de-cocina?fiestaId=${id}`, { waitUntil: 'domcontentloaded' });
  65  |   await expect(page.getByRole('heading', { name: 'Cocina y salon QA135', exact: true })).toBeVisible();
  66  |   for (const [dish, amount] of [['Entrada QA135', 100], ['Principal QA135', 80], ['Infantil QA135', 20], ['Postre QA135', 100]] as const) {
  67  |     const row = page.getByRole('row').filter({ hasText: dish });
  68  |     await expect(row.getByRole('cell').nth(2)).toContainText(String(amount));
  69  |   }
  70  |   await expect(page.getByText('Celiaco', { exact: true })).toBeVisible();
  71  |   await expect(page.locator('body')).toContainText('5 confirmaron');
  72  |   await expect(page.getByText('Vegano', { exact: true })).toHaveCount(0);
  73  |   await page.reload({ waitUntil: 'domcontentloaded' });
  74  |   await expect(page.getByRole('row').filter({ hasText: 'Principal QA135' })).toContainText('80');
  75  |   await page.evaluate(() => { (window as any).__qaPrintCalls = 0; window.print = () => { (window as any).__qaPrintCalls++; }; });
  76  |   await page.getByRole('button', { name: 'Imprimir para la cocina' }).click();
  77  |   expect(await page.evaluate(() => (window as any).__qaPrintCalls)).toBe(1);
  78  |   await page.emulateMedia({ media: 'print' });
  79  |   await expect(page.getByRole('heading', { name: 'Cocina y salon QA135', exact: true })).toBeVisible();
  80  |   const pdf = await page.pdf({ path: info.outputPath('hoja-cocina.pdf'), format: 'A4', printBackground: true });
  81  |   expect(pdf.subarray(0, 4).toString()).toBe('%PDF');
  82  |   expect(pdf.length).toBeGreaterThan(2000);
  83  |   await info.attach('hoja-cocina.pdf', { body: pdf, contentType: 'application/pdf' });
  84  | });
  85  | 
  86  | test('agenda: revisar sin Google conectado responde y no rompe la pantalla', async ({ page }, info) => {
  87  |   const errors: string[] = [];
  88  |   page.on('pageerror', (error) => errors.push(error.message));
  89  |   await page.goto('/settings/sincronizaciones', { waitUntil: 'domcontentloaded' });
  90  |   const card = page.getByTestId('limpiar-agenda');
  91  |   await expect(card).toBeVisible();
  92  |   await expect(card).toContainText(/personales no se tocan/i);
  93  |   await card.getByRole('button', { name: /revisar mi agenda/i }).click();
  94  |   await expect(page.locator('body')).toContainText(/no est[aá] conectada|no se pudo mirar la agenda/i);
> 95  |   expect(errors).toEqual([]);
      |                  ^ Error: expect(received).toEqual(expected) // deep equality
  96  |   await info.attach('agenda.json', { body: JSON.stringify({ errors, observed: await card.innerText(), realGoogle: false }), contentType: 'application/json' });
  97  | });
  98  | 
  99  | test('DJ: la cancion opcional persistida aparece tambien tras recargar', async ({ page }) => {
  100 |   await page.goto(`/evento/dj/${id}`, { waitUntil: 'domcontentloaded' });
  101 |   await expect(page.getByText('Opcional QA135 - Artista QA135', { exact: true })).toBeVisible();
  102 |   await page.reload({ waitUntil: 'domcontentloaded' });
  103 |   await expect(page.getByText('Opcional QA135 - Artista QA135', { exact: true })).toBeVisible();
  104 | });
  105 | 
  106 | async function pixels(page: Page) {
  107 |   return page.locator('canvas').first().evaluate((canvas: HTMLCanvasElement) => {
  108 |     const copy = document.createElement('canvas'); copy.width = canvas.width; copy.height = canvas.height;
  109 |     const ctx = copy.getContext('2d'); if (!ctx) throw new Error('Canvas reader missing');
  110 |     ctx.drawImage(canvas, 0, 0);
  111 |     const data = ctx.getImageData(0, 0, copy.width, copy.height).data;
  112 |     const colors = new Set<string>();
  113 |     for (let i = 0; i < data.length; i += 256) colors.add(`${data[i]},${data[i + 1]},${data[i + 2]}`);
  114 |     return { colors: colors.size, width: canvas.width, height: canvas.height, image: canvas.toDataURL() };
  115 |   });
  116 | }
  117 | 
  118 | test('salon 3D: canvas real no blanco y giro, sin aceptar imagen de respaldo', async ({ page, context, isMobile }, info) => {
  119 |   test.setTimeout(120_000);
  120 |   const errors: string[] = []; page.on('pageerror', (error) => errors.push(error.message));
  121 |   await page.goto(`/portal/${id}/decoracion`, { waitUntil: 'domcontentloaded' });
  122 |   const canvas = page.locator('canvas').first();
  123 |   await expect(canvas).toBeVisible({ timeout: 45_000 });
  124 |   await canvas.scrollIntoViewIfNeeded();
  125 |   await expect.poll(async () => (await pixels(page)).colors, { timeout: 20_000 }).toBeGreaterThan(20);
  126 |   const before = await pixels(page);
  127 |   expect(before.width).toBeGreaterThan(100); expect(before.height).toBeGreaterThan(100);
  128 |   const box = await canvas.boundingBox(); if (!box) throw new Error('No visible canvas bounds');
  129 |   const x = box.x + box.width / 2, y = box.y + box.height / 2;
  130 |   if (isMobile) {
  131 |     const cdp = await context.newCDPSession(page);
  132 |     await cdp.send('Input.dispatchTouchEvent', { type: 'touchStart', touchPoints: [{ x, y }] });
  133 |     for (let i = 1; i <= 10; i++) await cdp.send('Input.dispatchTouchEvent', { type: 'touchMove', touchPoints: [{ x: x + i * 5, y: y + i }] });
  134 |     await cdp.send('Input.dispatchTouchEvent', { type: 'touchEnd', touchPoints: [] }); await cdp.detach();
  135 |   } else {
  136 |     await page.mouse.move(x, y); await page.mouse.down(); await page.mouse.move(x + 65, y + 20, { steps: 10 }); await page.mouse.up();
  137 |   }
  138 |   await page.waitForTimeout(800);
  139 |   const after = await pixels(page);
  140 |   expect(after.colors).toBeGreaterThan(20); expect(after.image).not.toBe(before.image);
  141 |   expect(errors).toEqual([]);
  142 |   await info.attach('salon-3d.png', { body: await canvas.screenshot(), contentType: 'image/png' });
  143 |   await info.attach('salon-3d.json', { body: JSON.stringify({ before: { ...before, image: undefined }, after: { ...after, image: undefined }, errors }), contentType: 'application/json' });
  144 | });
  145 | 
```