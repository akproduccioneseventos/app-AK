# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: 135-cocina-agenda-3d.spec.ts >> cocina: evento y porciones reales, recarga y salida de impresion
- Location: tests\e2e\135-cocina-agenda-3d.spec.ts:70:5

# Error details

```
Error: expect(locator).toBeVisible() failed

Locator: getByRole('heading', { name: 'Cocina y salon QA135', exact: true })
Expected: visible
Timeout: 25000ms
Error: element(s) not found

Call log:
  - Expect "toBeVisible" with timeout 25000ms
  - waiting for getByRole('heading', { name: 'Cocina y salon QA135', exact: true })

```

```yaml
- main:
  - main:
    - heading "Qué sale, y cuánto" [level=2]
    - table:
      - rowgroup:
        - row "Momento Plato Porciones":
          - columnheader "Momento"
          - columnheader "Plato"
          - columnheader "Porciones"
      - rowgroup:
        - row "Entrada Entrada QA135 100todos":
          - cell "Entrada"
          - cell "Entrada QA135"
          - cell "100todos"
        - row "Plato Principal Principal QA135 80adultos":
          - cell "Plato Principal"
          - cell "Principal QA135"
          - cell "80adultos"
        - row "Menú Infantil Infantil QA135 20chicos":
          - cell "Menú Infantil"
          - cell "Infantil QA135"
          - cell "20chicos"
        - row "Postre Postre QA135 100todos":
          - cell "Postre"
          - cell "Postre QA135"
          - cell "100todos"
    - heading "Platos especiales, aparte" [level=2]
    - list:
      - listitem:
        - paragraph: Celiaco
        - text: "5"
- region "Notifications (F8)":
  - list
- alert
```

# Test source

```ts
  1   | import fs from 'node:fs';
  2   | import path from 'node:path';
  3   | import { test, expect, type Page } from '@playwright/test';
  4   | import { crearFiestaDeEstaNoche, guardarFiesta, borrarFiesta, ponerSesionDelEquipo } from './helpers/fiesta-de-prueba';
  5   | 
  6   | test.skip(process.env.AK_ENTORNO_AISLADO !== 'true', 'Solo copia QA ficticia');
  7   | const id = `e2e_135_${process.pid}_${Date.now()}`;
  8   | const budgetId = `${id}_presupuesto`;
  9   | const snapshots = new Map<string, Buffer | null>();
  10  | 
  11  | test.beforeAll(() => {
  12  |   const fiesta = crearFiestaDeEstaNoche({ id });
  13  |   fiesta.configuracion.nombreEvento = 'Cocina y salon QA135';
  14  |   fiesta.presupuestoId = budgetId;
  15  |   fiesta.invitados = [
  16  |     { id: 'celiaco', nombre: 'Familia QA135', rsvp: 'Confirmado', partySize: 5, dietaryRestriction: 'Celiaco' },
  17  |     { id: 'pendiente', nombre: 'Pendiente QA135', rsvp: 'Pendiente', partySize: 2, dietaryRestriction: 'Vegano' },
  18  |   ] as any;
  19  |   fiesta.listaMusicaPortal = { siEsPosible: ['Opcional QA135 - Artista QA135'] } as any;
  20  |   fiesta.decoracion = { ...fiesta.decoracion, salonWidth: 20, salonHeight: 15, pixelsPerMeter: 40,
  21  |     salonElements: [
  22  |       { id: 'mesa135', type: 'element', category: 'mesa', name: 'Mesa QA135', x: 180, y: 160, width: 80, height: 80, rotation: 0 },
  23  |       { id: 'pista135', type: 'area', category: 'pista', name: 'Pista QA135', x: 420, y: 300, width: 160, height: 160, rotation: 0 },
  24  |     ],
  25  |   } as any;
  26  |   guardarFiesta(fiesta);
  27  |   const presupuesto = { id: budgetId, clienteNombre: 'Cliente ficticio QA135', invitadosAdultos: 80,
  28  |     invitadosNinos: 15, invitadosAdolescentes: 5, totalFinal: 1000,
  29  |     itemsPresupuestados: [
  30  |       { idServicioCatalogo: 'dish_135_entrada', nombreServicio: 'Entrada QA135', categoriaServicio: 'Entrada' },
  31  |       { idServicioCatalogo: 'dish_135_principal', nombreServicio: 'Principal QA135', categoriaServicio: 'Plato Principal' },
  32  |       { idServicioCatalogo: 'dish_135_infantil', nombreServicio: 'Infantil QA135', categoriaServicio: 'Menu Infantil' },
  33  |       { idServicioCatalogo: 'dish_135_postre', nombreServicio: 'Postre QA135', categoriaServicio: 'Postre' },
  34  |     ] };
  35  |   for (const dir of ['data', 'src/data']) {
  36  |     const file = path.join(process.cwd(), dir, 'presupuestos.json');
  37  |     const prior = fs.existsSync(file) ? fs.readFileSync(file) : null;
  38  |     snapshots.set(file, prior);
  39  |     const rows = prior ? JSON.parse(prior.toString('utf8').replace(/^\uFEFF/, '')) : [];
  40  |     if (!Array.isArray(rows)) throw new Error('Unexpected QA budgets fixture');
  41  |     fs.mkdirSync(path.dirname(file), { recursive: true });
  42  |     fs.writeFileSync(file, JSON.stringify([...rows, presupuesto], null, 2));
  43  |   }
  44  | });
  45  | test.afterAll(() => {
  46  |   borrarFiesta(id);
  47  |   for (const [file, prior] of snapshots) {
  48  |     if (prior) fs.writeFileSync(file, prior);
  49  |     else if (fs.existsSync(file)) fs.unlinkSync(file);
  50  |   }
  51  | });
  52  | 
  53  | test.beforeEach(async ({ context, baseURL }) => {
  54  |   await context.route('**/*', (route) => {
  55  |     const url = new URL(route.request().url());
  56  |     if (url.hostname === 'firebaseinstallations.googleapis.com' && url.pathname.startsWith('/v1/projects/demo-ak-producciones/installations')) {
  57  |       return route.fulfill({ status: 200, contentType: 'application/json', body: JSON.stringify({
  58  |         fid: 'cQA135localinstallation00', refreshToken: 'synthetic-no-real-account',
  59  |         authToken: { token: 'synthetic-no-real-account', expiresIn: '604800s' },
  60  |         token: 'synthetic-no-real-account', expiresIn: '604800s',
  61  |       }) });
  62  |     }
  63  |     return ['127.0.0.1', 'localhost'].includes(url.hostname) || ['data:', 'blob:'].includes(url.protocol)
  64  |       ? route.continue() : route.abort('blockedbyclient');
  65  |   });
  66  |   await context.addInitScript(() => { Reflect.deleteProperty(Navigator.prototype, 'serviceWorker'); });
  67  |   await ponerSesionDelEquipo(context, baseURL);
  68  | });
  69  | 
  70  | test('cocina: evento y porciones reales, recarga y salida de impresion', async ({ page }, info) => {
  71  |   await page.goto(`/fiestas/nueva/catering/hoja-de-cocina?fiestaId=${id}`, { waitUntil: 'domcontentloaded' });
  72  |   await expect(page.getByRole('heading', { name: 'Cocina y salon QA135', exact: true })).toBeVisible();
  73  |   for (const [dish, amount] of [['Entrada QA135', 100], ['Principal QA135', 80], ['Infantil QA135', 20], ['Postre QA135', 100]] as const) {
  74  |     const row = page.getByRole('row').filter({ hasText: dish });
  75  |     await expect(row.getByRole('cell').nth(2)).toContainText(String(amount));
  76  |   }
  77  |   await expect(page.getByText('Celiaco', { exact: true })).toBeVisible();
  78  |   await expect(page.locator('body')).toContainText('5 confirmaron');
  79  |   await expect(page.getByText('Vegano', { exact: true })).toHaveCount(0);
  80  |   await page.reload({ waitUntil: 'domcontentloaded' });
  81  |   await expect(page.getByRole('row').filter({ hasText: 'Principal QA135' })).toContainText('80');
  82  |   await page.evaluate(() => { (window as any).__qaPrintCalls = 0; window.print = () => { (window as any).__qaPrintCalls++; }; });
  83  |   await page.getByRole('button', { name: 'Imprimir para la cocina' }).click();
  84  |   expect(await page.evaluate(() => (window as any).__qaPrintCalls)).toBe(1);
  85  |   await page.emulateMedia({ media: 'print' });
  86  |   const pdf = await page.pdf({ path: info.outputPath('hoja-cocina.pdf'), format: 'A4', printBackground: true });
  87  |   expect(pdf.subarray(0, 4).toString()).toBe('%PDF');
  88  |   expect(pdf.length).toBeGreaterThan(2000);
  89  |   await info.attach('hoja-cocina.pdf', { body: pdf, contentType: 'application/pdf' });
  90  |   await info.attach('cabecera-impresion.json', { body: JSON.stringify(await page.evaluate(() => {
  91  |     const name = document.querySelector('h1');
  92  |     const header = name?.closest('header');
  93  |     return { text: name?.textContent, headerDisplay: header ? getComputedStyle(header).display : null,
  94  |       headingBox: name?.getBoundingClientRect().toJSON(), printMode: matchMedia('print').matches };
  95  |   })), contentType: 'application/json' });
> 96  |   await expect(page.getByRole('heading', { name: 'Cocina y salon QA135', exact: true })).toBeVisible();
      |                                                                                          ^ Error: expect(locator).toBeVisible() failed
  97  | });
  98  | 
  99  | test('agenda: revisar sin Google conectado responde y no rompe la pantalla', async ({ page }, info) => {
  100 |   const errors: string[] = [];
  101 |   page.on('pageerror', (error) => errors.push(error.stack || error.message));
  102 |   await page.goto('/settings/sincronizaciones', { waitUntil: 'domcontentloaded' });
  103 |   const card = page.getByTestId('limpiar-agenda');
  104 |   await expect(card).toBeVisible();
  105 |   await expect(card).toContainText(/personales no se tocan/i);
  106 |   await card.getByRole('button', { name: /revisar mi agenda/i }).click();
  107 |   await expect(page.locator('body')).toContainText(/no est[aá] conectada|no se pudo mirar la agenda/i);
  108 |   await info.attach('agenda.json', { body: JSON.stringify({ errors, observed: await card.innerText(), realGoogle: false }), contentType: 'application/json' });
  109 |   expect(errors).toEqual([]);
  110 | });
  111 | 
  112 | test('DJ: la cancion opcional persistida aparece tambien tras recargar', async ({ page }) => {
  113 |   await page.goto(`/evento/dj/${id}`, { waitUntil: 'domcontentloaded' });
  114 |   await expect(page.getByText('Opcional QA135 - Artista QA135', { exact: true })).toBeVisible();
  115 |   await page.reload({ waitUntil: 'domcontentloaded' });
  116 |   await expect(page.getByText('Opcional QA135 - Artista QA135', { exact: true })).toBeVisible();
  117 | });
  118 | 
  119 | async function pixels(page: Page) {
  120 |   return page.locator('canvas').first().evaluate((canvas: HTMLCanvasElement) => {
  121 |     const copy = document.createElement('canvas'); copy.width = canvas.width; copy.height = canvas.height;
  122 |     const ctx = copy.getContext('2d'); if (!ctx) throw new Error('Canvas reader missing');
  123 |     ctx.drawImage(canvas, 0, 0);
  124 |     const data = ctx.getImageData(0, 0, copy.width, copy.height).data;
  125 |     const colors = new Set<string>();
  126 |     for (let i = 0; i < data.length; i += 256) colors.add(`${data[i]},${data[i + 1]},${data[i + 2]}`);
  127 |     return { colors: colors.size, width: canvas.width, height: canvas.height, image: canvas.toDataURL() };
  128 |   });
  129 | }
  130 | 
  131 | test('salon 3D: canvas real no blanco y giro, sin aceptar imagen de respaldo', async ({ page, context, isMobile }, info) => {
  132 |   test.setTimeout(120_000);
  133 |   const errors: string[] = []; page.on('pageerror', (error) => errors.push(error.message));
  134 |   await page.goto(`/portal/${id}/decoracion`, { waitUntil: 'domcontentloaded' });
  135 |   const canvas = page.locator('canvas').first();
  136 |   await expect(canvas).toBeVisible({ timeout: 45_000 });
  137 |   await canvas.scrollIntoViewIfNeeded();
  138 |   await expect.poll(async () => (await pixels(page)).colors, { timeout: 20_000 }).toBeGreaterThan(20);
  139 |   const before = await pixels(page);
  140 |   expect(before.width).toBeGreaterThan(100); expect(before.height).toBeGreaterThan(100);
  141 |   const box = await canvas.boundingBox(); if (!box) throw new Error('No visible canvas bounds');
  142 |   const x = box.x + box.width / 2, y = box.y + box.height / 2;
  143 |   if (isMobile) {
  144 |     const cdp = await context.newCDPSession(page);
  145 |     await cdp.send('Input.dispatchTouchEvent', { type: 'touchStart', touchPoints: [{ x, y }] });
  146 |     for (let i = 1; i <= 10; i++) await cdp.send('Input.dispatchTouchEvent', { type: 'touchMove', touchPoints: [{ x: x + i * 5, y: y + i }] });
  147 |     await cdp.send('Input.dispatchTouchEvent', { type: 'touchEnd', touchPoints: [] }); await cdp.detach();
  148 |   } else {
  149 |     await page.mouse.move(x, y); await page.mouse.down(); await page.mouse.move(x + 65, y + 20, { steps: 10 }); await page.mouse.up();
  150 |   }
  151 |   await page.waitForTimeout(800);
  152 |   const after = await pixels(page);
  153 |   expect(after.colors).toBeGreaterThan(20); expect(after.image).not.toBe(before.image);
  154 |   expect(errors).toEqual([]);
  155 |   await info.attach('salon-3d.png', { body: await canvas.screenshot(), contentType: 'image/png' });
  156 |   await info.attach('salon-3d.json', { body: JSON.stringify({ before: { ...before, image: undefined }, after: { ...after, image: undefined }, errors }), contentType: 'application/json' });
  157 | });
  158 | 
```