import fs from 'node:fs';
import path from 'node:path';
import os from 'node:os';
import net from 'node:net';
import crypto from 'node:crypto';
import assert from 'node:assert/strict';
import { spawn,spawnSync } from 'node:child_process';
import { gzipSync } from 'node:zlib';
import { fileURLToPath } from 'node:url';
const root="C:\\Users\\Usuario\\Documents\\Codex\\ak-codex88\\ak-auditoria267-cierre\\",dir=path.join(root,'docs/evidencias');
const source='3e45a4ac6b479f89605163168e31b37dc84f2d0f';
const runId='33602';assert.match(runId,/^\d+$/);
const specFilter=process.env.AK_AUDIT_SPEC_FILTER?.split(',').filter(Boolean);
const includePortal=process.env.AK_AUDIT_SKIP_PORTAL!=='true';
const batchSize=Number(process.env.AK_AUDIT_BATCH_SIZE||0);assert.ok(Number.isInteger(batchSize)&&batchSize>=0&&batchSize<=12);
const build=JSON.parse(fs.readFileSync(path.join(dir,'291-entorno.json'),'utf8'));
assert.equal(build.source,source);assert.equal(build.buildExit,0,'Wait for frozen-source build');
const target=path.join(dir,`${runId}-ejecucion.json`);assert.equal(fs.existsSync(target)||fs.existsSync(target+'.gz'),false,'Preserve run including published gzip');
const qa=path.resolve(build.qa);assert.match(qa.replaceAll('\\','/'),/\/Temp\/ak-qa-280-[^/]+$/);
const safe=Object.fromEntries(['PATH','TEMP','TMP','SYSTEMROOT','WINDIR','PROGRAMDATA','PROGRAMFILES','COMSPEC','PATHEXT','LOCALAPPDATA'].filter(k=>process.env[k]!==undefined).map(k=>[k,process.env[k]]));
const git=args=>{const r=spawnSync('git',args,{cwd:qa,env:safe,encoding:'utf8',maxBuffer:4*1024**2});assert.equal(r.status,0,r.stderr);return r.stdout.trim();};
assert.equal(git(['rev-parse','HEAD']),source);assert.equal(git(['diff','--name-only']),'');
assert.equal(fs.readdirSync(qa).some(n=>/^\.env(?:\.(?:local|production|development|test)(?:\.local)?)?$/.test(n)),false);
assert.ok(os.freemem()>=1024**3,'No Next/browser under1GiB');
const inside=file=>{const p=path.resolve(file);assert.ok(p.startsWith(qa+path.sep),'Own QA only');return p;};
const jsonFiles=()=>{const out=[];const walk=folder=>{if(!fs.existsSync(folder))return;for(const entry of fs.readdirSync(folder,{withFileTypes:true})){const file=inside(path.join(folder,entry.name));if(entry.isDirectory()&&!entry.isSymbolicLink())walk(file);else if(entry.isFile()&&file.endsWith('.json'))out.push(file);}};for(const folder of ['data','src/data'])walk(path.join(qa,folder));return out;};
const snapshots=new Map(jsonFiles().map(file=>[file,fs.readFileSync(file)]));
const restoreData=()=>{for(const file of jsonFiles())if(!snapshots.has(file))fs.unlinkSync(inside(file));for(const[file,bytes]of snapshots)fs.writeFileSync(inside(file),bytes);};
const copied=[],manifest=[];
const hash=data=>crypto.createHash('sha256').update(data).digest('hex');
const hook=`\nimport { test as __akAudit207 } from '@playwright/test';\n__akAudit207.beforeEach(async ({context}, testInfo) => {\n  await context.route('**/*',async route=>{const url=new URL(route.request().url());if(/^https?:$/.test(url.protocol)&&!['127.0.0.1','localhost','[::1]'].includes(url.hostname)){await testInfo.attach('qa-egress-blocked',{contentType:'text/plain',body:url.origin+url.pathname});await route.abort('blockedbyclient');}else await route.continue();});\n});\n`;
const copy=(from,to)=>{const dest=inside(to);assert.equal(fs.existsSync(dest),false,dest);fs.copyFileSync(from,dest);copied.push(dest);};
const walkTests=folder=>{for(const entry of fs.readdirSync(folder,{withFileTypes:true})){const file=inside(path.join(folder,entry.name));if(entry.isDirectory())walkTests(file);else if(entry.name.endsWith('.spec.ts')&&!entry.name.startsWith('ak207-')&&(!specFilter||specFilter.includes(entry.name))){
  const raw=fs.readFileSync(file,'utf8');assert.ok(!raw.includes('__akAudit207'));
  const dest=inside(path.join(folder,'ak207-'+entry.name));assert.equal(fs.existsSync(dest),false);let content=hook+raw;if(entry.name==='recorrido-de-pantallas.spec.ts'){for(const[from,to]of [["await page.waitForLoadState('networkidle', { timeout: 10_000 }).catch(() => {});","r.qaReadyBody=await page.waitForFunction(passive=>{const area=document.querySelector('main')||document.body;const rect=area.getBoundingClientRect(),style=getComputedStyle(area);const busy=!passive&&Array.from(area.querySelectorAll('[aria-busy=\"true\"],svg.animate-spin')).some(el=>el.getClientRects().length>0&&getComputedStyle(el).visibility!=='hidden');return rect.width>0&&rect.height>0&&style.visibility!=='hidden'&&Number(style.opacity)>0.1&&(area.innerText||'').trim().length>=40&&!busy;},Boolean(r.passive),{timeout:10000}).then(()=>true,()=>false);await page.waitForTimeout(500);"],["const results: any[] = [];","const results: any[] = [];const qaPartial=path.join(process.cwd(),'test-results','recorrido','partial-33602.json');fs.mkdirSync(path.dirname(qaPartial),{recursive:true});const qaPush=results.push.bind(results);results.push=(...rows:any[])=>{const count=qaPush(...rows);fs.writeFileSync(qaPartial,JSON.stringify(results,null,2));return count;};"],["// Capture screenshot","if(r.qaReadyBody===false){results.push({...r,estado:'NO_PROBADA',motivo:'No confirmo cuerpo visible/listo dentro de10s; no se aprueba por header solo',duracionMs});return;}\n        // Capture screenshot"],["const response = await page.goto(r.testUrl, {","if(r.pathname==='/fiestas/nueva'||r.pathname.startsWith('/fiestas/nueva/')){const qaUrl=new URL(r.testUrl,'http://127.0.0.1');if(!qaUrl.searchParams.has('fiestaId'))qaUrl.searchParams.set('fiestaId','fiesta_esta_noche');r.qaInputContext='Explicit existing fictitious fiestaId, not app edit';r.testUrl=qaUrl.pathname+qaUrl.search;}\n        const response = await page.goto(r.testUrl, {"],["await page.screenshot({ path: shotPath, fullPage: false });","await page.screenshot({path:shotPath,fullPage:false,animations:'disabled',timeout:5000}).then(()=>{r.qaScreenshot='captured';},error=>{r.qaScreenshot='unavailable';r.qaScreenshotError=String(error.message||error);});"]]){assert(content.includes(from),from);content=content.replaceAll(from,to);}}if(entry.name==='recorrido-de-pantallas.spec.ts'){assert(content.includes("await context.addCookies(["));assert(content.includes("const html = await page.content();"));content=content.replace("await context.addCookies([","await context.route('**/*',async route=>{const u=new URL(route.request().url());if(/^https?:$/.test(u.protocol)&&!['127.0.0.1','localhost','[::1]'].includes(u.hostname))await route.abort('blockedbyclient');else await route.continue();});\nawait context.addInitScript(()=>{if(!['http:','https:'].includes(location.protocol))return;window.localStorage.setItem('ak_session','true');window.sessionStorage.setItem('ak_session','true');});\nawait context.route('https://firebaseinstallations.googleapis.com/**',async route=>{const u=new URL(route.request().url());const body=u.pathname.endsWith('authTokens:generate')?{token:'qa-fis-only',expiresIn:'604800s'}:{fid:'c'+'a'.repeat(21),refreshToken:'qa-fis-refresh-only',authToken:{token:'qa-fis-only',expiresIn:'604800s'}};await route.fulfill({status:200,contentType:'application/json',body:JSON.stringify(body)});});\nawait context.addCookies([").replace("const html = await page.content();","r.qaFinalPath=new URL(page.url()).pathname;if(r.qaFinalPath==='/login'&&new URL(r.testUrl,baseURL).pathname!=='/login'){results.push({...r,estado:'NO_PROBADA',motivo:'Fixture no autorizo la ruta: ingreso no cuenta como pantalla esperada',duracionMs});page.off('pageerror',errorListener);return;}\nconst html = await page.content();");}fs.writeFileSync(dest,content);copied.push(dest);
  manifest.push({original:path.relative(qa,file).replaceAll('\\','/'),copy:path.relative(qa,dest).replaceAll('\\','/'),originalSha256:hash(raw),instrumentedSha256:hash(fs.readFileSync(dest))});
}}};
walkTests(path.join(qa,'tests/e2e'));assert.equal(manifest.length,1);
if(includePortal){const newTest=inside(path.join(qa,'tests/e2e/ak207-portal-activo.spec.ts'));assert.equal(fs.existsSync(newTest),false);fs.writeFileSync(newTest,hook+fs.readFileSync(path.join(dir,'207-portal-activo.spec.ts'),'utf8'));copied.push(newTest);}
const configDest=inside(path.join(qa,'208-config.ts'));assert(!fs.existsSync(configDest));
const configSource=fs.readFileSync(path.join(dir,'208-config.ts'),'utf8');
assert(configSource.includes("testIgnore:['**/ak207-recorrido-de-pantallas.spec.ts']"));assert(configSource.includes("trace:'retain-on-failure'"));
fs.writeFileSync(configDest,configSource.replace("testIgnore:['**/ak207-recorrido-de-pantallas.spec.ts']",'testIgnore:[]').replace("trace:'retain-on-failure'","trace:'off'"));copied.push(configDest);copy(path.join(dir,'208-egress-guard.cjs'),path.join(qa,'208-egress-guard.cjs'));
const envResult=spawnSync(process.execPath,['scripts/entorno-de-pruebas.mjs'],{cwd:qa,env:{...safe,AK_ENTORNO_SOLO_MOSTRAR_AMBIENTE:'true'},encoding:'utf8'});assert.equal(envResult.status,0,envResult.stderr);
const home=inside(path.join(qa,'.qa209-home'));fs.mkdirSync(path.join(home,'config'),{recursive:true});
const env={...safe,...JSON.parse(envResult.stdout).forzadas,HOME:home,USERPROFILE:home,APPDATA:path.join(home,'config'),XDG_CONFIG_HOME:path.join(home,'config'),
  AK_DISABLE_STANDALONE:'true',COMMIT_SHA:source,NODE_ENV:'production',PLAYWRIGHT_BASE_URL:'http://127.0.0.1:3300',AK_QA_RESULTS:path.join(dir,`${runId}-resultados.json`),
  NODE_OPTIONS:`--max-old-space-size=1024 --require "${path.join(qa,'208-egress-guard.cjs').replaceAll('\\','/')}"`};
const record={source,qa,started:new Date().toISOString(),phase:'prepared',buildFinished:build.finished,dependencyLimit:build.dependencyLimit,realServices:false,appEdited:false,specFilter:specFilter||null,batchSize,copiedTests:manifest.length,newTestSha256:includePortal?hash(fs.readFileSync(path.join(dir,'207-portal-activo.spec.ts'))):null,manifest,
  limits:'Selected E2E specs (all only if specFilter is null) on one frozen-source Next build, plus active portal cases. Tests copied without changing assertions, adding only common local-network guard. Existing deliberate skips remain skips, not acceptance. Default inventory traversal excluded separately; route availability is not function acceptance. External requests blocked; no real services or zero-error certificate.'};
const save=()=>fs.writeFileSync(target,JSON.stringify(record,null,2)+'\n');save();
let server,child;
const serverFile=path.join(dir,`${runId}-servidor.log`),testFile=path.join(dir,`${runId}-pruebas.log`);const serverLog=fs.createWriteStream(serverFile),testLog=fs.createWriteStream(testFile);
try{
  const listener=net.createServer();await new Promise((yes,no)=>{listener.once('error',no);listener.listen(3300,'127.0.0.1',yes);});await new Promise(yes=>listener.close(yes));
  server=spawn(process.execPath,['C:/Users/Usuario/Documents/Codex/ak-codex88/ak-react19-candidato-103/node_modules/next/dist/bin/next','start','--hostname','127.0.0.1','--port','3300'],{cwd:qa,env,stdio:['ignore','pipe','pipe']});record.serverPid=server.pid;save();server.stdout.pipe(serverLog,{end:false});server.stderr.pipe(serverLog,{end:false});
  const deadline=Date.now()+90000;while(!record.health){try{const h=await(await fetch('http://127.0.0.1:3300/api/health',{signal:AbortSignal.timeout(10000)})).json();assert.ok(h.version?.startsWith(source));assert.ok(Object.values(h.services).every(v=>v===false));record.health=h;}catch(error){if(Date.now()>deadline)throw error;await new Promise(resolve=>setTimeout(resolve,1000));}}
  assert.ok(os.freemem()>=512*1024**2,'No browser under512MiB');
  record.phase='running';save();console.log(JSON.stringify({phase:record.phase,source,serverPid:server.pid,copiedTests:manifest.length}));
  const allFiles=manifest.map(item=>path.basename(item.copy));
  if(includePortal)allFiles.push('ak207-portal-activo.spec.ts');
  const groups=batchSize?Array.from({length:Math.ceil(allFiles.length/batchSize)},(_,index)=>allFiles.slice(index*batchSize,(index+1)*batchSize)):[[]];
  record.batches=[];record.exitCode=0;save();
  for(let index=0;index<groups.length;index++){
    if(index>0){restoreData();const deadline=Date.now()+10*60*1000;while(os.freemem()<1024**3&&Date.now()<deadline)await new Promise(resolve=>setTimeout(resolve,15000));assert.ok(os.freemem()>=1024**3,'No next browser batch under1GiB');}
    const label=batchSize?`${runId}-batch-${String(index+1).padStart(3,'0')}`:runId;
    const runEnv={...env,AK_RECORRIDO_CARRILES:'1',AK_RECORRIDO_SOLO:"/fiestas/nueva/resumen-imprimible,/fiestas/nueva/resumen-planificacion,/fiestas/nueva/reunion-organizacion,/fiestas/nueva/reuniones/imprimir,/fiestas/nueva/reuniones,/fiestas/nueva/servicios-contratados,/fiestas/nueva/social-fiesta-pro/cierre-final",AK_QA_RESULTS:path.join(dir,`${label}-resultados.json`)};
    record.currentBatch=index+1;record.totalBatches=groups.length;save();
    child=spawn(process.execPath,['C:/Users/Usuario/Documents/Codex/ak-codex88/ak-react19-candidato-103/node_modules/@playwright/test/cli.js','test','--project','chromium-desktop','--config','208-config.ts','--output',path.join(dir,`${label}-artifacts`),...groups[index]],{cwd:qa,env:runEnv,stdio:['ignore','pipe','pipe']});record.testPid=child.pid;save();child.stdout.pipe(testLog,{end:false});child.stderr.pipe(testLog,{end:false});
    const code=await new Promise((yes,no)=>{child.once('exit',yes);child.once('error',no);});if(code!==0){record.exitCode=1;process.exitCode=1;}
    const batch={index:index+1,files:groups[index],exitCode:code,finished:new Date().toISOString(),report:path.basename(runEnv.AK_QA_RESULTS)};
    if(fs.existsSync(runEnv.AK_QA_RESULTS)){const report=JSON.parse(fs.readFileSync(runEnv.AK_QA_RESULTS,'utf8'));Object.assign(batch,{stats:report.stats,errors:report.errors});}
    record.batches.push(batch);save();console.log(JSON.stringify({batch:batch.index,totalBatches:groups.length,exitCode:code,stats:batch.stats}));
  }
  if(!batchSize&&fs.existsSync(env.AK_QA_RESULTS)){const report=JSON.parse(fs.readFileSync(env.AK_QA_RESULTS,'utf8'));record.stats=report.stats;record.reportErrors=report.errors;}
  else if(batchSize){record.stats=Object.fromEntries(['expected','skipped','unexpected','flaky'].map(key=>[key,record.batches.reduce((sum,batch)=>sum+(batch.stats?.[key]||0),0)]));record.reportErrors=record.batches.flatMap(batch=>batch.errors||[]);fs.writeFileSync(env.AK_QA_RESULTS,JSON.stringify({format:'AK_BATCH_REPORT_NOT_PLAYWRIGHT_NATIVE',source,stats:record.stats,batches:record.batches},null,2)+'\n');}
}catch(error){record.error=String(error.stack||error);process.exitCode=1;}
finally{
  for(const process of [child,server])if(process&&process.exitCode===null){const done=new Promise(resolve=>process.once('exit',resolve));process.kill();await Promise.race([done,new Promise(resolve=>setTimeout(resolve,5000))]);}
  await new Promise(resolve=>testLog.end(resolve));await new Promise(resolve=>serverLog.end(resolve));
  for(const file of copied)if(fs.existsSync(file))fs.unlinkSync(inside(file));
  restoreData();
  record.snapshotCount=snapshots.size;record.sourceDiff=git(['diff','--name-only']);record.finished=new Date().toISOString();record.phase='finished';save();
  for(const file of [serverFile,testFile])fs.writeFileSync(file+'.gz',gzipSync(fs.readFileSync(file)));
  console.log(JSON.stringify({...record,manifest:undefined}));if(record.sourceDiff)process.exitCode=1;
}
