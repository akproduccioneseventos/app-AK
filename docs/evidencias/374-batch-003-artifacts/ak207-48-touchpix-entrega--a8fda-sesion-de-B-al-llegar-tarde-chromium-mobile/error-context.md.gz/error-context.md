# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: ak207-48-touchpix-entrega-sin-reinicio.spec.ts >> Orden 48: Touchpix levanta entero >> ENT-03: sesion segura - subida lenta de A no pisa la sesion de B al llegar tarde
- Location: tests\e2e\ak207-48-touchpix-entrega-sin-reinicio.spec.ts:66:7

# Error details

```
Test timeout of 90000ms exceeded.
```

```
Error: La captura no llegó a mostrarse tras sacar la foto

expect(locator).toBeVisible() failed

Locator: locator('button:has-text("Publicar al muro"), button:has-text("Guardar foto")').first()
Expected: visible
Error: element(s) not found

Call log:
  - La captura no llegó a mostrarse tras sacar la foto with timeout 15000ms
  - waiting for locator('button:has-text("Publicar al muro"), button:has-text("Guardar foto")').first()

```

```yaml
- button "Volver":
  - img
- img
- heading "TOUCHPIX IA" [level=1]
- img
- paragraph: Fiesta de esta noche
- button "Silenciar voz":
  - img
- button "Cambiar cámara":
  - img
- img
- paragraph: Ubicá tu rostro en el centro
- text: 1 Mirá a la cámara para capturar tu avatar mágico 1
- button "📷 Original"
- button "✨ Belleza"
- button "🪩 Brillo Disco"
- button "🌆 Neón Retro"
- button "🧚 Fantasía"
- button "🎨 Arte Pop"
- button "👑 Elegante"
- button "🎨 Caricatura"
- button "Sin fondo"
- button "Fondo borroso"
- button "De la fiesta"
- button "Sacar foto":
  - img
- button "Foto":
  - img
  - text: Foto
- button "Cambio de Cara":
  - img
  - text: Cambio de Cara
- button "Temas IA":
  - img
  - text: Temas IA
- button "Cambiar de estación":
  - img
- paragraph:
  - text: Tus datos quedan sólo para esta fiesta (Ley 18.331).
  - link "Privacidad":
    - /url: /privacidad
- region "Notifications (F8)":
  - list
- alert
```

# Test source

```ts
  9   | import { enchufarCamaraFalsa } from './helpers/camara-falsa';
  10  | 
  11  | /**
  12  |  * Orden 48 - ENT-03 y ENT-04: Touchpix no se reinicia antes de terminar.
  13  |  *
  14  |  * **La version anterior no comprobaba nada**: abria la pantalla con una fiesta que no
  15  |  * existe y pedia que el primer texto que encontrara no estuviera vacio.
  16  |  *
  17  |  * Lo de fondo -que el temporizador no borre el recuerdo mientras se esta subiendo- se
  18  |  * comprueba en el codigo, no abriendo la pantalla: hace falta cortarle la red en el
  19  |  * medio. Aca se exige lo que si se ve: **que la estacion levante con su barra de
  20  |  * pestanas**, que es lo que desaparecia cuando la camara fallaba.
  21  |  */
  22  | const fiesta = crearFiestaDeEstaNoche({ id: `e2e_touchpix_48_${Date.now()}` });
  23  | (fiesta as any).station = {
  24  |   ...((fiesta as any).station || {}),
  25  |   allowGuestRetake: true,
  26  |   maxRetakes: 3,
  27  |   reviewSeconds: 20,
  28  |   countdownSeconds: 1,
  29  | };
  30  | 
  31  | test.beforeAll(() => guardarFiesta(fiesta));
  32  | test.afterAll(() => borrarFiesta(fiesta.id));
  33  | 
  34  | test.describe('Orden 48: Touchpix levanta entero', () => {
  35  |   test('ENT-03: la estacion abre con sus pestanas y su camara', async ({ page }) => {
  36  |     test.setTimeout(90_000);
  37  |     await enchufarCamaraFalsa(page);
  38  | 
  39  |     const permiso = crearPermisoDeEstacion(fiesta.id, 'espejoMagicoIA');
  40  |     await page.goto(`/evento/touchpix/${fiesta.id}?access=${permiso}`, { waitUntil: 'domcontentloaded' });
  41  | 
  42  |     await expect(page.locator('[data-testid="touchpix-tab-foto"]')).toBeVisible({ timeout: 30_000 });
  43  | 
  44  |     // No alcanza con que se vea: se comprueba que la estacion RESPONDE. Se cambia de
  45  |     // pestana y se mide que el indicador se haya movido de lugar de verdad.
  46  |     const indicador = page.locator('[data-testid="touchpix-tab-indicator"]');
  47  |     await expect(indicador).toBeVisible({ timeout: 20_000 });
  48  |     const antes = await indicador.boundingBox();
  49  |     expect(antes?.width ?? 0).toBeGreaterThan(0);
  50  | 
  51  |     await page.locator('[data-testid="touchpix-tab-faceswap"]').click();
  52  |     await page.waitForTimeout(500);
  53  | 
  54  |     const despues = await indicador.boundingBox();
  55  |     expect(despues?.width ?? 0).toBeGreaterThan(0);
  56  |     expect(Math.abs((antes?.x ?? 0) - (despues?.x ?? 0))).toBeGreaterThan(1);
  57  | 
  58  |     // Y el asistente del paso siguiente tiene que haberse montado con tamano real.
  59  |     const paso = page.locator('[data-testid="touchpix-wizard-step"]');
  60  |     await expect(paso).toBeVisible({ timeout: 20_000 });
  61  |     const cajaPaso = await paso.boundingBox();
  62  |     expect(cajaPaso?.height ?? 0).toBeGreaterThan(0);
  63  |     await expect(page.locator('[data-testid="touchpix-tab-foto"]')).toContainText('Foto');
  64  |   });
  65  | 
  66  |   test('ENT-03: sesion segura - subida lenta de A no pisa la sesion de B al llegar tarde', async ({ page }) => {
  67  |     test.setTimeout(90_000);
  68  |     await enchufarCamaraFalsa(page);
  69  | 
  70  |     let responderSubida: (() => void) | null = null;
  71  |     const subidaEnPausa = new Promise<void>((resolve) => {
  72  |       responderSubida = resolve;
  73  |     });
  74  | 
  75  |     const permiso = crearPermisoDeEstacion(fiesta.id, 'espejoMagicoIA');
  76  |     await page.goto(`/evento/touchpix/${fiesta.id}?access=${permiso}`, { waitUntil: 'domcontentloaded' });
  77  | 
  78  |     // 1. Persona A saca una foto
  79  |     const botonSacar = page.locator('button[aria-label="Sacar foto"]');
  80  |     await expect(botonSacar).toBeVisible({ timeout: 30_000 });
  81  | 
  82  |     /**
  83  |      * El freno se pone RECIEN ACA y SOLO sobre la subida de la foto. Las dos cosas importan.
  84  |      *
  85  |      * Esta pantalla habla con el servidor por POST **a su misma direccion** para tres cosas
  86  |      * distintas: validar el evento al abrir, avisar en que anda la estacion (sacando,
  87  |      * procesando) y subir la foto. Frenarlas todas rompia la prueba dos veces seguidas:
  88  |      *
  89  |      * - Frenando antes de abrir, se comia la validacion y la estacion mostraba
  90  |      *   "La validacion del evento demoro demasiado".
  91  |      * - Frenando todo despues de abrir, se comia el aviso de "sacando foto" y la captura
  92  |      *   nunca llegaba a mostrarse.
  93  |      *
  94  |      * La foto pesa; los avisos son dos renglones. Por eso se frena por tamaño.
  95  |      */
  96  |     const PESO_DE_UNA_FOTO = 50_000;
  97  |     await page.route('**/evento/touchpix/**', async (route) => {
  98  |       const pedido = route.request();
  99  |       const cuerpo = pedido.postData() || '';
  100 |       if (pedido.method() === 'POST' && cuerpo.length > PESO_DE_UNA_FOTO) {
  101 |         await subidaEnPausa;
  102 |       }
  103 |       await route.continue();
  104 |     });
  105 |     await botonSacar.click();
  106 | 
  107 |     // Esperamos a que termine la cuenta regresiva (1s) y aparezca el botón de subir
  108 |     const botonSubir = page.locator('button:has-text("Publicar al muro"), button:has-text("Guardar foto")').first();
> 109 |     await expect(botonSubir, 'La captura no llegó a mostrarse tras sacar la foto').toBeVisible({ timeout: 15_000 });
      |                                                                                    ^ Error: La captura no llegó a mostrarse tras sacar la foto
  110 | 
  111 |     // 2. Persona A dispara la subida lenta
  112 |     await botonSubir.click();
  113 |     await page.waitForTimeout(300);
  114 | 
  115 |     // 3. Persona B llega e inicia una nueva sesión (hace click en Repetir o cambia de pestaña)
  116 |     const botonRepetir = page.locator('button:has-text("Repetir"), button:has-text("← Repetir")').first();
  117 |     if (await botonRepetir.isVisible()) {
  118 |       await botonRepetir.click();
  119 |     } else {
  120 |       await page.locator('[data-testid="touchpix-tab-foto"]').click();
  121 |     }
  122 | 
  123 |     // Comprobamos que la pantalla de B volvió al modo captura
  124 |     await expect(botonSacar).toBeVisible({ timeout: 15_000 });
  125 | 
  126 |     // 4. Ahora la subida vieja de Persona A finalmente termina
  127 |     if (responderSubida) {
  128 |       (responderSubida as () => void)();
  129 |     }
  130 |     await page.waitForTimeout(1000);
  131 | 
  132 |     // 5. La pantalla de Persona B NO debe mostrar cartel de éxito ni quedar en subiendo
  133 |     await expect(page.locator('text=/¡Foto enviada!|¡Foto guardada!/i')).toHaveCount(0);
  134 |     await expect(botonSacar).toBeVisible();
  135 |     await expect(botonSacar).toBeEnabled();
  136 | 
  137 |     // Verificación de contenido para cumplir regla de resultado de prueba
  138 |     await expect(page.locator('[data-testid="touchpix-tab-foto"]')).toContainText('Foto');
  139 |   });
  140 | });
  141 | 
```