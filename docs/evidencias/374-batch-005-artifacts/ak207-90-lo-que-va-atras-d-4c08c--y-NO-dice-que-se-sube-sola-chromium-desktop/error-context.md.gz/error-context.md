# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: ak207-90-lo-que-va-atras-dice-donde-quedo.spec.ts >> Orden 90 — Bloque 2: la pantalla dice la verdad según dónde quedó la captura >> Fotocabina con subida rechazada: muestra el error y NO dice que se sube sola
- Location: tests\e2e\ak207-90-lo-que-va-atras-dice-donde-quedo.spec.ts:112:7

# Error details

```
Error: expect(locator).toBeVisible() failed

Locator: getByRole('button', { name: /publicar en el muro/i })
Expected: visible
Timeout: 25000ms
Error: element(s) not found

Call log:
  - Expect "toBeVisible" with timeout 25000ms
  - waiting for getByRole('button', { name: /publicar en el muro/i })

```

```yaml
- button "Volver":
  - img
- heading "Fotocabina AK" [level=1]
- paragraph: Fiesta de esta noche
- paragraph: Foto 3 de 3
- paragraph: "Última: la mejor sonrisa."
- button "Cambiar de estación":
  - img
- region "Notifications (F8)":
  - list
- alert
```

# Test source

```ts
  40  | 
  41  | (fiesta as any).others.entretenimiento.modules.plataforma360 = {
  42  |   countdownSeconds: 2,
  43  |   recordingDurationSeconds: 2,
  44  | };
  45  | 
  46  | test.beforeAll(() => guardarFiesta(fiesta));
  47  | test.afterAll(() => borrarFiesta(fiesta.id));
  48  | 
  49  | async function esperarCamaraLista(page: any) {
  50  |   for (let intento = 0; intento < 15; intento++) {
  51  |     const hayCamara = await page.evaluate(() => {
  52  |       const v = document.querySelector('video');
  53  |       return Boolean(v && (v as HTMLVideoElement).srcObject);
  54  |     });
  55  |     if (hayCamara) {
  56  |       await page.waitForTimeout(500);
  57  |       return;
  58  |     }
  59  |     await page.waitForTimeout(1_000);
  60  |   }
  61  | }
  62  | 
  63  | function simularRechazoAction(texto: string, mensajeError: string) {
  64  |   let resultado = texto;
  65  |   if (resultado.includes('"error"')) {
  66  |     resultado = resultado.replace(/"error"\s*:\s*"[^"]*"/g, `"error":"${mensajeError}"`);
  67  |   } else {
  68  |     resultado = resultado.replace(/"success"\s*:\s*(true|false)/, `"success":false,"error":"${mensajeError}"`);
  69  |   }
  70  |   return resultado.replace(/"success"\s*:\s*true/g, '"success":false');
  71  | }
  72  | 
  73  | test.describe('Orden 90 — Bloque 2: la pantalla dice la verdad según dónde quedó la captura', () => {
  74  |   test('Fotocabina con corte de red: dice guardada en el equipo y NUNCA subida ni galería', async ({ context, page }, testInfo) => {
  75  |     test.setTimeout(90_000);
  76  |     const baseURL = testInfo.project.use.baseURL as string;
  77  |     await ponerSesionDelEquipo(context, baseURL);
  78  |     await enchufarCamaraFalsa(page);
  79  | 
  80  |     await page.route('**/evento/fotocabina/**', async (route) => {
  81  |       const req = route.request();
  82  |       const contentType = req.headers()['content-type'] || '';
  83  |       if (req.method() === 'POST' && contentType.includes('multipart/form-data')) {
  84  |         await route.abort('internetdisconnected');
  85  |         return;
  86  |       }
  87  |       await route.continue();
  88  |     });
  89  | 
  90  |     const permiso = crearPermisoDeEstacion(fiesta.id, 'fotocabina');
  91  |     await page.goto(`/evento/fotocabina/${fiesta.id}?access=${permiso}`, { waitUntil: 'domcontentloaded' });
  92  |     await esperarCamaraLista(page);
  93  | 
  94  |     const btnCaptura = page.locator('[data-testid="boton-sacar-foto"]').or(page.getByRole('button', { name: /preparar foto|sacar/i })).first();
  95  |     await expect(btnCaptura).toBeVisible({ timeout: 25_000 });
  96  |     await btnCaptura.click();
  97  | 
  98  |     // Esperar a que pase la captura y aparezca la vista previa con el botón para publicar
  99  |     const btnPublicar = page.getByRole('button', { name: /publicar en el muro/i });
  100 |     await expect(btnPublicar).toBeVisible({ timeout: 25_000 });
  101 |     await btnPublicar.click();
  102 | 
  103 |     // Debe mostrar que quedó guardada en el equipo
  104 |     const avisoEquipo = page.getByText(/guardada en este equipo|quedó guardada/i).first();
  105 |     await expect(avisoEquipo).toBeVisible({ timeout: 35_000 });
  106 | 
  107 |     // Y NUNCA debe decir "subida" ni "en la galería"
  108 |     const textoPagina = (await page.locator('body').innerText()).toLowerCase();
  109 |     expect(textoPagina).not.toMatch(/ya se subió|ya está subida|en la galería de la fiesta|tu recuerdo esta listo/i);
  110 |   });
  111 | 
  112 |   test('Fotocabina con subida rechazada: muestra el error y NO dice que se sube sola', async ({ context, page }, testInfo) => {
  113 |     test.setTimeout(90_000);
  114 |     const baseURL = testInfo.project.use.baseURL as string;
  115 |     await ponerSesionDelEquipo(context, baseURL);
  116 |     await enchufarCamaraFalsa(page);
  117 | 
  118 |     await page.route('**/evento/fotocabina/**', async (route) => {
  119 |       const req = route.request();
  120 |       const contentType = req.headers()['content-type'] || '';
  121 |       if (req.method() === 'POST' && contentType.includes('multipart/form-data')) {
  122 |         const respuesta = await route.fetch();
  123 |         const texto = await respuesta.text();
  124 |         const nuevoTexto = simularRechazoAction(texto, 'Contenido inapropiado');
  125 |         await route.fulfill({ response: respuesta, body: nuevoTexto });
  126 |         return;
  127 |       }
  128 |       await route.continue();
  129 |     });
  130 | 
  131 |     const permiso = crearPermisoDeEstacion(fiesta.id, 'fotocabina');
  132 |     await page.goto(`/evento/fotocabina/${fiesta.id}?access=${permiso}`, { waitUntil: 'domcontentloaded' });
  133 |     await esperarCamaraLista(page);
  134 | 
  135 |     const btnCaptura = page.locator('[data-testid="boton-sacar-foto"]').or(page.getByRole('button', { name: /preparar foto|sacar/i })).first();
  136 |     await expect(btnCaptura).toBeVisible({ timeout: 25_000 });
  137 |     await btnCaptura.click();
  138 | 
  139 |     const btnPublicar = page.getByRole('button', { name: /publicar en el muro/i });
> 140 |     await expect(btnPublicar).toBeVisible({ timeout: 25_000 });
      |                               ^ Error: expect(locator).toBeVisible() failed
  141 |     await btnPublicar.click();
  142 | 
  143 |     // Debe informar el error de rechazo
  144 |     const avisoError = page.getByText(/no se pudo publicar|contenido inapropiado/i).first();
  145 |     await expect(avisoError).toBeVisible({ timeout: 35_000 });
  146 | 
  147 |     // Y NO debe decir que se sube sola ni que quedó guardada
  148 |     const textoPagina = (await page.locator('body').innerText()).toLowerCase();
  149 |     expect(textoPagina).not.toMatch(/se sube sola|se subirá cuando vuelva la señal|guardada en este equipo/i);
  150 |   });
  151 | 
  152 |   test('Plataforma 360 con corte de red: dice guardado en el equipo y NUNCA subido ni galería', async ({ context, page }, testInfo) => {
  153 |     test.setTimeout(90_000);
  154 |     const baseURL = testInfo.project.use.baseURL as string;
  155 |     await ponerSesionDelEquipo(context, baseURL);
  156 |     await enchufarCamaraFalsa(page);
  157 | 
  158 |     await page.route('**/evento/plataforma-360/**', async (route) => {
  159 |       const req = route.request();
  160 |       const contentType = req.headers()['content-type'] || '';
  161 |       if (req.method() === 'POST' && contentType.includes('multipart/form-data')) {
  162 |         await route.abort('internetdisconnected');
  163 |         return;
  164 |       }
  165 |       await route.continue();
  166 |     });
  167 | 
  168 |     const permiso = crearPermisoDeEstacion(fiesta.id, 'plataforma360');
  169 |     await page.goto(`/evento/plataforma-360/${fiesta.id}?access=${permiso}`, { waitUntil: 'domcontentloaded' });
  170 | 
  171 |     const btnGrabar = page.getByRole('button', { name: /grabar video/i }).first();
  172 |     await expect(btnGrabar).toBeVisible({ timeout: 20_000 });
  173 |     await btnGrabar.click();
  174 | 
  175 |     // Debe mostrar que quedó guardado en el equipo
  176 |     const avisoEquipo = page.getByText(/video guardado en este equipo|quedó guardado/i).first();
  177 |     await expect(avisoEquipo).toBeVisible({ timeout: 45_000 });
  178 | 
  179 |     // Y NUNCA debe decir subido ni en la galería
  180 |     const textoPagina = (await page.locator('body').innerText()).toLowerCase();
  181 |     expect(textoPagina).not.toMatch(/tu video ya está subido|en la galería/i);
  182 |   });
  183 | 
  184 |   test('Plataforma 360 con subida rechazada: muestra el error y NO dice que se sube sola', async ({ context, page }, testInfo) => {
  185 |     test.setTimeout(90_000);
  186 |     const baseURL = testInfo.project.use.baseURL as string;
  187 |     await ponerSesionDelEquipo(context, baseURL);
  188 |     await enchufarCamaraFalsa(page);
  189 | 
  190 |     await page.route('**/evento/plataforma-360/**', async (route) => {
  191 |       const req = route.request();
  192 |       const contentType = req.headers()['content-type'] || '';
  193 |       if (req.method() === 'POST' && contentType.includes('multipart/form-data')) {
  194 |         const respuesta = await route.fetch();
  195 |         const texto = await respuesta.text();
  196 |         const nuevoTexto = simularRechazoAction(texto, 'Contenido inapropiado');
  197 |         await route.fulfill({ response: respuesta, body: nuevoTexto });
  198 |         return;
  199 |       }
  200 |       await route.continue();
  201 |     });
  202 | 
  203 |     const permiso = crearPermisoDeEstacion(fiesta.id, 'plataforma360');
  204 |     await page.goto(`/evento/plataforma-360/${fiesta.id}?access=${permiso}`, { waitUntil: 'domcontentloaded' });
  205 | 
  206 |     const btnGrabar = page.getByRole('button', { name: /grabar video/i }).first();
  207 |     await expect(btnGrabar).toBeVisible({ timeout: 20_000 });
  208 |     await btnGrabar.click();
  209 | 
  210 |     // Debe mostrar el rechazo
  211 |     const avisoError = page.getByText(/contenido inapropiado|no se pudo publicar/i).first();
  212 |     await expect(avisoError).toBeVisible({ timeout: 45_000 });
  213 | 
  214 |     // Y NO debe decir que se sube sola ni que quedó guardado en esta pantalla
  215 |     const textoPagina = (await page.locator('body').innerText()).toLowerCase();
  216 |     expect(textoPagina).not.toMatch(/se sube sola|se subirá cuando vuelva la señal|quedó guardado en esta pantalla/i);
  217 |   });
  218 | });
  219 | 
```