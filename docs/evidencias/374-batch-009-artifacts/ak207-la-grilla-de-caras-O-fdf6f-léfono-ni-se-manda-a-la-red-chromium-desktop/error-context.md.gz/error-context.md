# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: ak207-la-grilla-de-caras.spec.ts >> Orden 36: La grilla de caras >> la selfie no sale del teléfono ni se manda a la red
- Location: tests\e2e\ak207-la-grilla-de-caras.spec.ts:244:7

# Error details

```
Error: muestra la pantalla de resultados, armada en el propio teléfono

expect(received).toBeGreaterThan(expected)

Expected: > 0
Received:   0
```

# Test source

```ts
  189 | 
  190 |     // Deben haber 2 caras (Ana y Beto, el que pasaba por atrás se filtró)
  191 |     const caritas = grilla.locator('button');
  192 |     await expect(caritas).toHaveCount(2);
  193 | 
  194 |     // REGLA 2: NUNCA un nombre al lado de una cara
  195 |     const textoGrilla = await grilla.innerText();
  196 |     expect(textoGrilla.trim()).toBe(''); // Las caritas no tienen texto
  197 | 
  198 |     // Al tocar una cara se filtran sus fotos y aparece "Descargar todas"
  199 |     await caritas.first().click();
  200 |     await expect(page.getByText(/Fotos de esta persona/i)).toBeVisible();
  201 |     await expect(page.getByRole('button', { name: /Descargar todas/i })).toBeVisible();
  202 | 
  203 |     // Siempre a la vista: "Ver todas las fotos de la fiesta"
  204 |     const botonVerTodas = page.getByRole('button', { name: /Ver todas las fotos de la fiesta/i });
  205 |     await expect(botonVerTodas).toBeVisible();
  206 |     await botonVerTodas.click();
  207 | 
  208 |     // Vuelve a la galería completa
  209 |     await expect(page.getByText(/Fotos de esta persona/i)).toHaveCount(0);
  210 |   });
  211 | 
  212 |   test('con el interruptor apagado no se ve ni la grilla ni el botón', async ({ page }, testInfo) => {
  213 |     test.setTimeout(120_000);
  214 | 
  215 |     await page.goto(`/evento/galeria/${ID_APAGADO}`, { waitUntil: 'domcontentloaded' });
  216 |     await page.waitForTimeout(3000);
  217 | 
  218 |     await expect(page.getByRole('button', { name: /Encontrame/i })).toHaveCount(0);
  219 |     await expect(page.locator('[data-testid="grilla-caras"]')).toHaveCount(0);
  220 |   });
  221 | 
  222 |   test('sin aceptar el permiso, la cámara no se prende y la galería sigue igual', async ({ page }, testInfo) => {
  223 |     test.setTimeout(120_000);
  224 | 
  225 |     await page.goto(`/evento/galeria/${ID_PREPARADA}`, { waitUntil: 'domcontentloaded' });
  226 |     await page.waitForTimeout(3000);
  227 | 
  228 |     const boton = page.getByRole('button', { name: /Encontrame a mí/i });
  229 |     await expect(boton).toBeVisible();
  230 |     await boton.click();
  231 | 
  232 |     // Debe mostrar el cartel de permiso claro
  233 |     await expect(
  234 |       page.getByText(/Vamos a mirar tu cara en este teléfono para buscar tus fotos\. No se guarda ni se manda a ningún lado\./i),
  235 |     ).toBeVisible();
  236 | 
  237 |     // Si cancela, el modal se cierra y la galería sigue igual
  238 |     await page.getByRole('button', { name: /Cancelar/i }).click();
  239 |     await expect(
  240 |       page.getByText(/Vamos a mirar tu cara en este teléfono/i),
  241 |     ).toHaveCount(0);
  242 |   });
  243 | 
  244 |   test('la selfie no sale del teléfono ni se manda a la red', async ({ page }, testInfo) => {
  245 |     test.setTimeout(120_000);
  246 | 
  247 |     await enchufarCamara(page);
  248 | 
  249 |     // Monitoreamos toda llamada de red para verificar que NUNCA viaje una imagen
  250 |     const llamadasConImagenes: string[] = [];
  251 |     page.on('request', (req) => {
  252 |       const url = req.url();
  253 |       const postData = req.postData() || '';
  254 |       if (
  255 |         postData.includes('data:image') ||
  256 |         postData.includes('base64') ||
  257 |         /upload|selfie|face-api|tensor|ai-vision/i.test(url)
  258 |       ) {
  259 |         llamadasConImagenes.push(`${req.method()} ${url}`);
  260 |       }
  261 |     });
  262 | 
  263 |     await page.goto(`/evento/galeria/${ID_PREPARADA}`, { waitUntil: 'domcontentloaded' });
  264 |     await page.waitForTimeout(3000);
  265 | 
  266 |     // Abrir "Encontrame a mí"
  267 |     await page.getByRole('button', { name: /Encontrame a mí/i }).click();
  268 | 
  269 |     // Aceptar permiso
  270 |     await page.getByRole('button', { name: /Entendido, buscar mis fotos/i }).click();
  271 | 
  272 |     // Esperar a que tome los cuadros y cierre el modal
  273 |     await page.waitForTimeout(4000);
  274 | 
  275 |     // LA REGLA MÁS IMPORTANTE: Que no se dispare ninguna llamada al servidor con la imagen
  276 |     expect(llamadasConImagenes, 'la selfie no se envió a ningún servidor externo ni local').toHaveLength(0);
  277 | 
  278 |     // Debe mostrar la vista de resultados o el mensaje de "no encontramos".
  279 |     // Los dos titulos conviven en la pantalla, asi que hay que contar cuantos se
  280 |     // ven y no preguntar por "el" titulo: preguntando de a uno, Playwright corta
  281 |     // por ambiguedad (paso el 4 de septiembre de 2026).
  282 |     const titulos = page.getByRole('heading', {
  283 |       name: /Resultados de tu búsqueda|No encontramos fotos tuyas todavía/i,
  284 |     });
  285 |     let visibles = 0;
  286 |     for (let i = 0; i < (await titulos.count()); i += 1) {
  287 |       if (await titulos.nth(i).isVisible()) visibles += 1;
  288 |     }
> 289 |     expect(visibles, 'muestra la pantalla de resultados, armada en el propio teléfono').toBeGreaterThan(0);
      |                                                                                         ^ Error: muestra la pantalla de resultados, armada en el propio teléfono
  290 |   });
  291 | });
  292 | 
```