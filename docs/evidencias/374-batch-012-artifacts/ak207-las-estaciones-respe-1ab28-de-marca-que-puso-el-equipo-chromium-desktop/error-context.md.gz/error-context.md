# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: ak207-las-estaciones-respetan-los-ajustes.spec.ts >> cada estación muestra en la pantalla de compartir el texto de marca que puso el equipo
- Location: tests\e2e\ak207-las-estaciones-respetan-los-ajustes.spec.ts:128:5

# Error details

```
Error: Bogue: no llego a la pantalla de compartir en 90 segundos

expect(received).toBe(expected) // Object.is equality

Expected: ""
Received: "Bogue: no llego a la pantalla de compartir en 90 segundos"
```

# Test source

```ts
  68  |     const armar = () => {
  69  |       const lienzo = document.createElement('canvas');
  70  |       lienzo.width = 720;
  71  |       lienzo.height = 1280;
  72  |       lienzo.getContext('2d')?.fillRect(0, 0, lienzo.width, lienzo.height);
  73  |       return lienzo.captureStream(30);
  74  |     };
  75  |     Object.defineProperty(navigator, 'mediaDevices', {
  76  |       configurable: true,
  77  |       value: {
  78  |         getUserMedia: async () => armar(),
  79  |         enumerateDevices: async () => [{ deviceId: 'cam', kind: 'videoinput', label: 'Camara', groupId: 'g' }],
  80  |         addEventListener: () => {},
  81  |         removeEventListener: () => {},
  82  |       },
  83  |     });
  84  |   });
  85  | }
  86  | 
  87  | const ESTACIONES = [
  88  |   { nombre: 'Plataforma 360', ruta: 'plataforma-360', modulo: 'plataforma360' },
  89  |   { nombre: 'Bogue', ruta: 'bogue', modulo: 'bogue' },
  90  |   // TOUCHPIX QUEDA AFUERA, Y NO ES QUE ESTE MAL LA ESTACION.
  91  |   // Su texto de marca vive en la ventanita del QR (page.tsx:794), que se abre
  92  |   // con "Compartir" despues de sacar la foto. Pero el boton de disparar es un
  93  |   // circulo con un dibujo y SIN NOMBRE, asi que no hay forma de tocarlo desde
  94  |   // una prueba. Se intento tres veces.
  95  |   // Ponerle el nombre esta pedido en docs/ordenes/20, bloque 9.c. Cuando lo
  96  |   // tenga, se vuelve a poner aca y se comprueba de verdad.
  97  |   // Mientras tanto figura como NO VERIFICADO en docs/LO-AUDITADO.md, no como hecho.
  98  | ];
  99  | 
  100 | /**
  101 |  * Lleva la estación hasta la pantalla de compartir y devuelve lo que dice.
  102 |  *
  103 |  * El texto de marca NO se dibuja al abrir: aparece junto al QR, recién después de
  104 |  * la captura. Por eso hay que sacar la foto de verdad, con paciencia: la 360 graba
  105 |  * un video y Bogue arma un loop.
  106 |  */
  107 | async function llegarACompartir(page: Page): Promise<string> {
  108 |   const disparar = page
  109 |     .getByRole('button', { name: /sacar|empezar|comenzar|iniciar|grabar|foto|video/i })
  110 |     .and(page.locator('button:not([disabled])'))
  111 |     .first();
  112 |   if ((await disparar.count()) === 0) return '';
  113 |   await disparar.click().catch(() => {});
  114 | 
  115 |   // Se espera a que aparezca el QR, que es la señal de que llegó a compartir.
  116 |   const limite = Date.now() + 90_000;
  117 |   let texto = '';
  118 |   while (Date.now() < limite) {
  119 |     await page.waitForTimeout(3_000);
  120 |     texto = ((await page.locator('body').innerText().catch(() => '')) || '')
  121 |       .replace(/\s+/g, ' ')
  122 |       .trim();
  123 |     if (texto.includes(MARCA) || /QR/i.test(texto)) break;
  124 |   }
  125 |   return texto;
  126 | }
  127 | 
  128 | test('cada estación muestra en la pantalla de compartir el texto de marca que puso el equipo', async ({ page }, testInfo) => {
  129 |   test.setTimeout(600_000);
  130 |   test.skip(testInfo.project.name !== 'chromium-desktop', 'Alcanza con un navegador.');
  131 |   await enchufarCamara(page);
  132 | 
  133 |   const noLoRespetan: string[] = [];
  134 | 
  135 |   for (const estacion of ESTACIONES) {
  136 |     const acceso = crearPermisoDeEstacion(ID, estacion.modulo);
  137 |     await page.goto(`/evento/${estacion.ruta}/${ID}?access=${acceso}`, { waitUntil: 'domcontentloaded' });
  138 |     await page.waitForTimeout(4_000);
  139 | 
  140 |     let texto = await llegarACompartir(page);
  141 | 
  142 |     // Touchpix no muestra la marca al capturar: la tiene en la ventanita del QR,
  143 |     // que se abre con el boton "Compartir". Hay que tocarlo.
  144 |     if (!texto.includes(MARCA)) {
  145 |       const compartir = page.getByRole('button', { name: /compartir/i }).first();
  146 |       if ((await compartir.count()) > 0) {
  147 |         await compartir.click().catch(() => {});
  148 |         await page.waitForTimeout(3_000);
  149 |         texto = ((await page.locator('body').innerText().catch(() => '')) || '')
  150 |           .replace(/\s+/g, ' ')
  151 |           .trim();
  152 |       }
  153 |     }
  154 | 
  155 |     if (!texto) {
  156 |       noLoRespetan.push(`${estacion.nombre}: no hay boton para sacar la captura`);
  157 |     } else if (!texto.includes(MARCA)) {
  158 |       // Se separan las dos fallas posibles: no llegar, o llegar y no respetar.
  159 |       const llego = /QR/i.test(texto);
  160 |       noLoRespetan.push(
  161 |         llego
  162 |           ? `${estacion.nombre}: llego a la pantalla de compartir y NO muestra el texto de marca configurado`
  163 |           : `${estacion.nombre}: no llego a la pantalla de compartir en 90 segundos`,
  164 |       );
  165 |     }
  166 |   }
  167 | 
> 168 |   expect(noLoRespetan.join('\n'), noLoRespetan.join('\n')).toBe('');
      |                                                            ^ Error: Bogue: no llego a la pantalla de compartir en 90 segundos
  169 | });
  170 | 
  171 | test('el buzón respeta la cuenta regresiva que puso el equipo', async ({ page }, testInfo) => {
  172 |   test.setTimeout(180_000);
  173 |   test.skip(testInfo.project.name !== 'chromium-desktop', 'Alcanza con un navegador.');
  174 |   await enchufarCamara(page);
  175 | 
  176 |   const acceso = crearPermisoDeEstacion(ID, 'capsulaTiempo');
  177 |   const respuesta = await page.goto(`/evento/buzon/${ID}?access=${acceso}`, {
  178 |     waitUntil: 'domcontentloaded',
  179 |   });
  180 |   expect(respuesta?.status(), 'el buzón abre').toBeLessThan(400);
  181 |   await page.waitForTimeout(3_000);
  182 | 
  183 |   const texto = ((await page.locator('body').innerText().catch(() => '')) || '').trim();
  184 |   // No se le pide más que estar sano: el buzón graba mensajes, no saca tandas.
  185 |   expect(texto, 'el buzón no muestra texto técnico').not.toMatch(
  186 |     /undefined|firestore|is not a valid|Algo sali[oó] mal/i,
  187 |   );
  188 |   expect(texto.length, 'el buzón muestra su pantalla').toBeGreaterThan(50);
  189 | });
  190 | 
```