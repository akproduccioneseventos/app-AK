# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: ak207-layout-baseline.spec.ts >> huella de maquetación >> las pantallas de referencia mantienen su geometría
- Location: tests\e2e\ak207-layout-baseline.spec.ts:128:7

# Error details

```
Error: La maquetación cambió:
  /presupuestos/nuevo · h1W: era 212, ahora 216

expect(received).toEqual(expected) // deep equality

- Expected  - 1
+ Received  + 3

- Array []
+ Array [
+   "/presupuestos/nuevo · h1W: era 212, ahora 216",
+ ]
```

# Page snapshot

```yaml
- generic [active] [ref=e1]:
  - generic [ref=e2]:
    - generic [ref=e6]:
      - link "Logo de la Empresa" [ref=e8] [cursor=pointer]:
        - /url: /admin
        - img "Logo de la Empresa" [ref=e10]
      - generic [ref=e11]:
        - list [ref=e12]:
          - listitem [ref=e13]:
            - link "Centro de Control" [ref=e14] [cursor=pointer]:
              - /url: /admin
              - img [ref=e15]
              - generic [ref=e20]: Centro de Control
        - generic [ref=e21]:
          - generic [ref=e22]:
            - generic [ref=e23]: Mi Día
            - generic [ref=e24]: ☀️
          - list [ref=e26]:
            - listitem [ref=e27]:
              - link "Mi Día" [ref=e28] [cursor=pointer]:
                - /url: /mi-dia
                - img [ref=e29]
                - generic [ref=e35]: Mi Día
        - generic [ref=e36]:
          - generic [ref=e37]:
            - generic [ref=e38]: Fiestas
            - generic [ref=e39]: 🎉
          - list [ref=e41]:
            - listitem [ref=e42]:
              - link "Eventos Activos" [ref=e43] [cursor=pointer]:
                - /url: /eventos
                - img [ref=e44]
                - generic [ref=e50]: Eventos Activos
            - listitem [ref=e51]:
              - link "Calendario" [ref=e52] [cursor=pointer]:
                - /url: /calendario
                - img [ref=e53]
                - generic [ref=e55]: Calendario
            - listitem [ref=e56]:
              - link "Muro Social" [ref=e57] [cursor=pointer]:
                - /url: /empresa/red-social-eventos
                - img [ref=e58]
                - generic [ref=e61]: Muro Social
            - listitem [ref=e62]:
              - link "Incidentes" [ref=e63] [cursor=pointer]:
                - /url: /incidentes
                - img [ref=e64]
                - generic [ref=e66]: Incidentes
            - listitem [ref=e67]:
              - link "Guias de Armado" [ref=e68] [cursor=pointer]:
                - /url: /playbooks
                - img [ref=e69]
                - generic [ref=e72]: Guias de Armado
            - listitem [ref=e73]:
              - link "Alergias y Dietas" [ref=e74] [cursor=pointer]:
                - /url: /fiestas/nueva/alergias
                - img [ref=e75]
                - generic [ref=e84]: Alergias y Dietas
            - listitem [ref=e85]:
              - link "Portal de Proveedores" [ref=e86] [cursor=pointer]:
                - /url: /fiestas/nueva/proveedores-portal
                - img [ref=e87]
                - generic [ref=e92]: Portal de Proveedores
            - listitem [ref=e93]:
              - link "Personal en dos fiestas" [ref=e94] [cursor=pointer]:
                - /url: /recursos-multi-evento
                - img [ref=e95]
                - generic [ref=e99]: Personal en dos fiestas
        - generic [ref=e100]:
          - generic [ref=e101]:
            - generic [ref=e102]: La Empresa
            - generic [ref=e103]: 🏢
          - list [ref=e105]:
            - listitem [ref=e106]:
              - link "Gestión de Empresa" [ref=e107] [cursor=pointer]:
                - /url: /empresa
                - img [ref=e108]
                - generic [ref=e112]: Gestión de Empresa
            - generic [ref=e115]: Vender
            - listitem [ref=e116]:
              - link "Prospectos" [ref=e117] [cursor=pointer]:
                - /url: /contabilidad/crm
                - img [ref=e118]
                - generic [ref=e120]: Prospectos
            - listitem [ref=e121]:
              - link "Presupuestos" [ref=e122] [cursor=pointer]:
                - /url: /presupuestos/nuevo
                - img [ref=e123]
                - generic [ref=e126]: Presupuestos
            - listitem [ref=e127]:
              - link "Clientes" [ref=e128] [cursor=pointer]:
                - /url: /customers
                - img [ref=e129]
                - generic [ref=e134]: Clientes
            - listitem [ref=e135]:
              - link "Simulador IA" [ref=e136] [cursor=pointer]:
                - /url: /simulador-ak
                - img [ref=e137]
                - generic [ref=e140]: Simulador IA
            - generic [ref=e143]: Plata
            - listitem [ref=e144]:
              - link "Pagos Rápidos" [ref=e145] [cursor=pointer]:
                - /url: /pagos-rapidos
                - img [ref=e146]
                - generic [ref=e149]: Pagos Rápidos
            - listitem [ref=e150]:
              - link "Panel Contable" [ref=e151] [cursor=pointer]:
                - /url: /empresa/contabilidad
                - img [ref=e152]
                - generic [ref=e154]: Panel Contable
            - listitem [ref=e155]:
              - link "Facturas" [ref=e156] [cursor=pointer]:
                - /url: /invoices
                - img [ref=e157]
                - generic [ref=e160]: Facturas
            - listitem [ref=e161]:
              - link "Cambios a Aprobar" [ref=e162] [cursor=pointer]:
                - /url: /aprobaciones
                - img [ref=e163]
                - generic [ref=e166]: Cambios a Aprobar
            - listitem [ref=e167]:
              - link "Métricas del Negocio" [ref=e168] [cursor=pointer]:
                - /url: /empresa/dashboard
                - img [ref=e169]
                - generic [ref=e172]: Métricas del Negocio
            - generic [ref=e175]: Recursos
            - listitem [ref=e176]:
              - link "Comida / Menús" [ref=e177] [cursor=pointer]:
                - /url: /empresa/menus
                - img [ref=e178]
                - generic [ref=e180]: Comida / Menús
            - listitem [ref=e181]:
              - link "Lista de Compras" [ref=e182] [cursor=pointer]:
                - /url: /compras
                - img [ref=e183]
                - generic [ref=e187]: Lista de Compras
            - listitem [ref=e188]:
              - link "Salones" [ref=e189] [cursor=pointer]:
                - /url: /empresa/salones
                - img [ref=e190]
                - generic [ref=e193]: Salones
            - listitem [ref=e194]:
              - link "Catálogo de Servicios" [ref=e195] [cursor=pointer]:
                - /url: /empresa/servicios
                - img [ref=e196]
                - generic [ref=e200]: Catálogo de Servicios
            - listitem [ref=e201]:
              - link "Proveedores" [ref=e202] [cursor=pointer]:
                - /url: /proveedores
                - img [ref=e203]
                - generic [ref=e207]: Proveedores
            - listitem [ref=e208]:
              - link "Empleados" [ref=e209] [cursor=pointer]:
                - /url: /empleados
                - img [ref=e210]
                - generic [ref=e213]: Empleados
            - generic [ref=e216]: Marketing
            - listitem [ref=e217]:
              - link "Marketing y Difusión" [ref=e218] [cursor=pointer]:
                - /url: /empresa/marketing
                - img [ref=e219]
                - generic [ref=e223]: Marketing y Difusión
            - listitem [ref=e224]:
              - link "Redes Sociales" [ref=e225] [cursor=pointer]:
                - /url: /empresa/redes-sociales
                - img [ref=e226]
                - generic [ref=e229]: Redes Sociales
            - listitem [ref=e230]:
              - link "WhatsApp del Día" [ref=e231] [cursor=pointer]:
                - /url: /contabilidad/crm/outbox
                - img [ref=e232]
                - generic [ref=e235]: WhatsApp del Día
            - listitem [ref=e236]:
              - link "Rendimiento Anuncios" [ref=e237] [cursor=pointer]:
                - /url: /contabilidad/crm/marketing-ads
                - img [ref=e238]
                - generic [ref=e241]: Rendimiento Anuncios
            - listitem [ref=e242]:
              - link "Presentación LED" [ref=e243] [cursor=pointer]:
                - /url: /empresa/presentacion-led/configuracion
                - img [ref=e244]
                - generic [ref=e247]: Presentación LED
        - generic [ref=e248]:
          - generic [ref=e249]:
            - generic [ref=e250]: Configuración
            - generic [ref=e251]: ⚙️
          - list [ref=e253]:
            - listitem [ref=e254]:
              - link "Ajustes Generales" [ref=e255] [cursor=pointer]:
                - /url: /settings
                - img [ref=e256]
                - generic [ref=e259]: Ajustes Generales
            - listitem [ref=e260]:
              - link "Tareas Automáticas" [ref=e261] [cursor=pointer]:
                - /url: /settings/tareas-automaticas
                - img [ref=e262]
                - generic [ref=e264]: Tareas Automáticas
            - listitem [ref=e265]:
              - link "Conexiones" [ref=e266] [cursor=pointer]:
                - /url: /settings/sincronizaciones
                - img [ref=e267]
                - generic [ref=e270]: Conexiones
            - listitem [ref=e271]:
              - link "WhatsApp" [ref=e272] [cursor=pointer]:
                - /url: /settings/whatsapp
                - img [ref=e273]
                - generic [ref=e275]: WhatsApp
            - listitem [ref=e276]:
              - link "Cláusulas de Contrato" [ref=e277] [cursor=pointer]:
                - /url: /settings/contratos/clausulas
                - img [ref=e278]
                - generic [ref=e282]: Cláusulas de Contrato
            - listitem [ref=e283]:
              - link "Seguridad" [ref=e284] [cursor=pointer]:
                - /url: /settings/account
                - img [ref=e285]
                - generic [ref=e288]: Seguridad
            - listitem [ref=e289]:
              - link "Promociones" [ref=e290] [cursor=pointer]:
                - /url: /settings/promos
                - img [ref=e291]
                - generic [ref=e294]: Promociones
            - listitem [ref=e295]:
              - link "Asistente IA" [ref=e296] [cursor=pointer]:
                - /url: /settings/ai-assistant
                - img [ref=e297]
                - generic [ref=e300]: Asistente IA
            - listitem [ref=e301]:
              - link "Mapa Tecnológico" [ref=e302] [cursor=pointer]:
                - /url: /settings/mapa-tecnologico-ak
                - img [ref=e303]
                - generic [ref=e306]: Mapa Tecnológico
            - listitem [ref=e307]:
              - link "Laboratorio Experimental" [ref=e308] [cursor=pointer]:
                - /url: /settings/feature-flags
                - img [ref=e309]
                - generic [ref=e312]: Laboratorio Experimental
      - list [ref=e314]:
        - listitem [ref=e315]:
          - link "Alertas" [ref=e316] [cursor=pointer]:
            - /url: /alertas
            - img [ref=e317]
            - generic [ref=e320]: Alertas
    - main [ref=e321]:
      - generic [ref=e322]:
        - generic [ref=e323]:
          - heading "AK Producciones" [level=1] [ref=e325]
          - generic [ref=e326]:
            - link "Ingreso/Egreso Rápido" [ref=e327] [cursor=pointer]:
              - /url: /pagos-rapidos
              - button "Ingreso/Egreso Rápido" [ref=e328]:
                - img
                - generic [ref=e329]: Ingreso/Egreso Rápido
            - button "Abrir notificaciones" [ref=e330] [cursor=pointer]:
              - img
              - generic [ref=e331]: Abrir notificaciones
            - button "Logo de la Empresa" [ref=e332] [cursor=pointer]:
              - img "Logo de la Empresa" [ref=e334]
        - main [ref=e335]:
          - main [ref=e337]:
            - generic [ref=e338]:
              - generic [ref=e339]:
                - link "Volver a contabilidad" [ref=e340] [cursor=pointer]:
                  - /url: /contabilidad
                  - img
                  - text: Volver a contabilidad
                - generic [ref=e341]: Comercial 360
              - generic [ref=e342]:
                - generic [ref=e344]:
                  - generic [ref=e345]:
                    - img [ref=e346]
                    - text: Presentacion comercial conectada con CRM, presupuesto y LED
                  - heading "Portal Comercial LED AK" [level=1] [ref=e349]
                  - paragraph [ref=e350]: "Esta pantalla hace visible el trabajo posterior a la PR #445: presentacion comercial, simulador, descuento visual, seguimiento, galeria comercial y Portal LED."
                  - generic [ref=e351]:
                    - link "Abrir Portal LED" [ref=e352] [cursor=pointer]:
                      - /url: /presentacion-led
                      - img
                      - text: Abrir Portal LED
                    - link "Ver galeria LED" [ref=e353] [cursor=pointer]:
                      - /url: /galeria-led
                      - img
                      - text: Ver galeria LED
                    - link "Ir al CRM" [ref=e354] [cursor=pointer]:
                      - /url: /contabilidad/crm
                      - img
                      - text: Ir al CRM
                - generic [ref=e355]:
                  - generic [ref=e357]:
                    - generic [ref=e358]: Ejemplo de Cierre Comercial
                    - generic [ref=e359]: EJEMPLO ILUSTRATIVO
                  - generic [ref=e360]:
                    - generic [ref=e361]:
                      - generic [ref=e362]:
                        - generic [ref=e363]: Simulación de Referencia
                        - generic [ref=e364]: No es precio real
                      - paragraph [ref=e365]: Total final de prueba
                      - paragraph [ref=e366]: $ 680.000
                      - paragraph [ref=e367]: "Ahorro mostrado en simulación: $ 165.000"
                    - paragraph [ref=e368]: "* Este bloque es una demostración del motor comercial para capacitaciones internas. No representa la cotización de ningún cliente real."
              - generic [ref=e369]:
                - generic [ref=e371]:
                  - img [ref=e372]
                  - paragraph [ref=e374]: Secciones LED
                  - paragraph [ref=e375]: "10"
                - generic [ref=e377]:
                  - img [ref=e378]
                  - paragraph [ref=e382]: Temperatura lead
                  - paragraph [ref=e383]: urgente
                - generic [ref=e385]:
                  - img [ref=e386]
                  - paragraph [ref=e388]: Tareas seguimiento
                  - paragraph [ref=e389]: "3"
                - generic [ref=e391]:
                  - img [ref=e392]
                  - paragraph [ref=e394]: Reglas visuales
                  - paragraph [ref=e395]: "6"
              - generic [ref=e396]:
                - generic [ref=e397]:
                  - generic [ref=e399]: Camino comercial visible
                  - generic [ref=e400]:
                    - generic [ref=e401]:
                      - generic [ref=e402]:
                        - paragraph [ref=e403]: 1. Portada comercial AK
                        - generic [ref=e404]: hero
                      - paragraph [ref=e405]: Marca, foto/video fuerte, tipo de fiesta y promesa principal.
                      - paragraph [ref=e406]: "Poco texto, imagen grande y una frase fuerte: organizamos todo para que disfrutes como invitado."
                    - generic [ref=e407]:
                      - generic [ref=e408]:
                        - paragraph [ref=e409]: 2. Confianza y trayectoria
                        - generic [ref=e410]: cards
                      - paragraph [ref=e411]: Experiencia, eventos, clientes, Club Uruguay y equipo AK.
                      - paragraph [ref=e412]: Mostrar prueba visual y social antes de hablar de precios.
                    - generic [ref=e413]:
                      - generic [ref=e414]:
                        - paragraph [ref=e415]: 3. Problema y solucion
                        - generic [ref=e416]: split
                      - paragraph [ref=e417]: Organizar separado genera estres; AK centraliza y coordina.
                      - paragraph [ref=e418]: Izquierda dolor del cliente, derecha solucion AK.
                    - generic [ref=e419]:
                      - generic [ref=e420]:
                        - paragraph [ref=e421]: 4. Tecnologia AK
                        - generic [ref=e422]: cards
                      - paragraph [ref=e423]: Portal cliente, invitado, invitacion, RSVP, red social, muro, album y seguimiento.
                      - paragraph [ref=e424]: Explicar beneficios en tarjetas grandes, no tecnicismos, antes de entrar al precio.
                    - generic [ref=e425]:
                      - generic [ref=e426]:
                        - paragraph [ref=e427]: 4.5. Zona tecnologica para fiestas
                        - generic [ref=e428]: cards
                      - paragraph [ref=e429]: Zona digital adolescente, fotocabina, 360, Vogue, espejo, barra tactil, totems y modo audiorritmico.
                      - paragraph [ref=e430]: "Venderlo como paquetes activables: incluido, opcional o apagado segun lo contratado."
                    - generic [ref=e431]:
                      - generic [ref=e432]:
                        - paragraph [ref=e433]: 5. Servicios por experiencia
                        - generic [ref=e434]: cards
                      - paragraph [ref=e435]: Salon, gastronomia, decoracion, musica, foto, video, personal y extras.
                      - paragraph [ref=e436]: Cada servicio debe tener foto, beneficio y boton para marcar interes.
                    - generic [ref=e437]:
                      - generic [ref=e438]:
                        - paragraph [ref=e439]: 6. Menus con fotos
                        - generic [ref=e440]: gallery
                      - paragraph [ref=e441]: Entradas, platos, ninos, adolescentes, postres y opciones por presupuesto.
                      - paragraph [ref=e442]: La comida se vende con imagen grande y descripcion corta.
                    - generic [ref=e443]:
                      - generic [ref=e444]:
                        - paragraph [ref=e445]: 7. Galeria comercial
                        - generic [ref=e446]: gallery
                      - paragraph [ref=e447]: Fotos por tipo de fiesta, servicio y subservicio.
                      - paragraph [ref=e448]: Filtrar por tipo de fiesta antes de mostrar fotos.
                    - generic [ref=e449]:
                      - generic [ref=e450]:
                        - paragraph [ref=e451]: 8. Seleccion de entrevista
                        - generic [ref=e452]: summary
                      - paragraph [ref=e453]: Lo que interesa, lo pendiente, lo incluido y lo marcado como regalo.
                      - paragraph [ref=e454]: Mantener una bandeja lateral visible con lo seleccionado.
                    - generic [ref=e455]:
                      - generic [ref=e456]:
                        - paragraph [ref=e457]: 9. Cierre comercial
                        - generic [ref=e458]: closing
                      - paragraph [ref=e459]: Resumen, valor comercial, bonificacion visual, regalos, sena y proximos pasos.
                      - paragraph [ref=e460]: "Cerrar con proximos pasos claros: presupuesto, entrevista, sena y contrato."
                - generic [ref=e461]:
                  - generic [ref=e462]:
                    - generic [ref=e464]: Descuento visual sin tocar precio real
                    - generic [ref=e465]:
                      - generic [ref=e466]:
                        - generic [ref=e467]: Valor comercial de servicios
                        - strong [ref=e468]: $ 800.000
                      - generic [ref=e469]:
                        - generic [ref=e470]: Bonificacion comercial 15%
                        - strong [ref=e471]: "-$ 120.000"
                      - generic [ref=e472]:
                        - generic [ref=e473]: Regalos incluidos
                        - strong [ref=e474]: $ 45.000
                      - generic [ref=e475]:
                        - generic [ref=e476]: Total final a contratar
                        - strong [ref=e477]: $ 680.000
                  - generic [ref=e478]:
                    - generic [ref=e480]: Seguimiento automatico sugerido
                    - generic [ref=e481]:
                      - generic [ref=e482]:
                        - generic [ref=e483]:
                          - paragraph [ref=e484]: Responder WhatsApp y proponer entrevista hoy
                          - generic [ref=e485]: ahora
                        - paragraph [ref=e486]: Cliente AK, gracias por usar el simulador de AK Producciones. Ya tenemos datos de Fiesta de 15. El simulador te dejó una referencia de UYU 680.000. Además viste cómo AK conecta portal, invitación, invitados, muro social y seguimiento para que la fiesta no sea solo una lista de servicios. El siguiente paso es coordinar una entrevista gratis para revisar servicios, menú, fecha y dejar el presupuesto bien ajustado.
                      - generic [ref=e487]:
                        - generic [ref=e488]:
                          - paragraph [ref=e489]: Actualizar etapa y etiquetas en CRM
                          - generic [ref=e490]: hoy
                        - paragraph [ref=e491]: "Origen comercial: portal_led | Tipo de fiesta: Fiesta de 15 | Invitados: 120 | Referencia: UYU 680.000"
                      - generic [ref=e492]:
                        - generic [ref=e493]:
                          - paragraph [ref=e494]: Llamar si no responde WhatsApp
                          - generic [ref=e495]: hoy
                        - paragraph [ref=e496]: Lead con intencion alta. Intentar contacto directo si no responde.
              - generic [ref=e497]:
                - generic [ref=e498]:
                  - generic [ref=e500]: Portal LED
                  - generic [ref=e501]:
                    - generic [ref=e502]:
                      - img [ref=e503]
                      - paragraph [ref=e506]: "1. Portada comercial AK: Poco texto, imagen grande y una frase fuerte: organizamos todo para que disfrutes como invitado."
                    - generic [ref=e507]:
                      - img [ref=e508]
                      - paragraph [ref=e511]: "2. Confianza y trayectoria: Mostrar prueba visual y social antes de hablar de precios."
                    - generic [ref=e512]:
                      - img [ref=e513]
                      - paragraph [ref=e516]: "3. Problema y solucion: Izquierda dolor del cliente, derecha solucion AK."
                    - generic [ref=e517]:
                      - img [ref=e518]
                      - paragraph [ref=e521]: "4. Tecnologia AK: Explicar beneficios en tarjetas grandes, no tecnicismos, antes de entrar al precio."
                    - generic [ref=e522]:
                      - img [ref=e523]
                      - paragraph [ref=e526]: "4.5. Zona tecnologica para fiestas: Venderlo como paquetes activables: incluido, opcional o apagado segun lo contratado."
                    - generic [ref=e527]:
                      - img [ref=e528]
                      - paragraph [ref=e531]: "5. Servicios por experiencia: Cada servicio debe tener foto, beneficio y boton para marcar interes."
                - generic [ref=e532]:
                  - generic [ref=e534]: Simulador
                  - generic [ref=e535]:
                    - generic [ref=e536]:
                      - img [ref=e537]
                      - paragraph [ref=e540]: Guardar origen comercial del lead.
                    - generic [ref=e541]:
                      - img [ref=e542]
                      - paragraph [ref=e545]: Marcar si vio la presentacion de valor AK antes del precio.
                    - generic [ref=e546]:
                      - img [ref=e547]
                      - paragraph [ref=e550]: Guardar presupuesto como referencia pendiente de verificacion.
                    - generic [ref=e551]:
                      - img [ref=e552]
                      - paragraph [ref=e555]: Crear tarea de seguimiento si no agenda entrevista.
                    - generic [ref=e556]:
                      - img [ref=e557]
                      - paragraph [ref=e560]: Preparar mensaje WhatsApp con entrevista gratis como siguiente paso.
                    - generic [ref=e561]:
                      - img [ref=e562]
                      - paragraph [ref=e565]: Separar clientes que solo calcularon de los que ya vieron tecnologia AK.
                    - generic [ref=e566]:
                      - img [ref=e567]
                      - paragraph [ref=e570]: Priorizar cierre de fecha cuando hay entrevista pedida o evento cercano.
                - generic [ref=e571]:
                  - generic [ref=e573]: Galeria y CRM
                  - generic [ref=e574]:
                    - generic [ref=e575]:
                      - img [ref=e576]
                      - paragraph [ref=e579]: Cargar cada foto o video con tipo de fiesta, servicio y subservicio.
                    - generic [ref=e580]:
                      - img [ref=e581]
                      - paragraph [ref=e584]: Marcar destacadas para Portal LED y landings.
                    - generic [ref=e585]:
                      - img [ref=e586]
                      - paragraph [ref=e589]: Usar superficies para decidir si aparece en Portal LED, web, landing, redes o presupuesto.
                    - generic [ref=e590]:
                      - img [ref=e591]
                      - paragraph [ref=e594]: Cada presupuesto de simulador debe crear o actualizar un lead en CRM.
                    - generic [ref=e595]:
                      - img [ref=e596]
                      - paragraph [ref=e599]: Cada lead debe guardar origen, temperatura, tags y proxima accion.
                    - generic [ref=e600]:
                      - img [ref=e601]
                      - paragraph [ref=e604]: WhatsApp debe ser el primer canal si el cliente dejo telefono o hizo clic.
              - generic [ref=e606]:
                - generic [ref=e607]:
                  - heading "Resultado buscado" [level=2] [ref=e608]
                  - paragraph [ref=e609]: Que cada consulta comercial tenga presentacion, presupuesto, seguimiento y material visual conectados.
                - link "Abrir simulador" [ref=e610] [cursor=pointer]:
                  - /url: /simulador-de-presupuesto
                  - img
                  - text: Abrir simulador
    - navigation "Navegacion del modulo" [ref=e611]:
      - button "Volver" [ref=e612] [cursor=pointer]:
        - img
      - button "Ir al panel principal" [ref=e613] [cursor=pointer]:
        - img
    - button "Abrir Asistente IA AK" [ref=e614] [cursor=pointer]:
      - img [ref=e615]
  - generic [ref=e619]:
    - button "Mover el asistente" [ref=e620]:
      - img [ref=e621]
    - button "Martin Contabilidad, pagos y contratos" [ref=e628] [cursor=pointer]:
      - img [ref=e631]
      - generic [ref=e634]:
        - generic [ref=e635]: Martin
        - generic [ref=e636]: Contabilidad, pagos y contratos
    - link "Personalizar asistentes" [ref=e637] [cursor=pointer]:
      - /url: /settings/asistentes-contextuales
      - img
    - link "Ver sincronizaciones" [ref=e638] [cursor=pointer]:
      - /url: /settings/sincronizaciones
      - img
    - button "Minimizar el asistente" [ref=e639] [cursor=pointer]:
      - img
  - region "Notifications (F8)":
    - list
  - alert [ref=e640]
```

# Test source

```ts
  130 | 
  131 |     await context.addInitScript(() => {
  132 |       window.localStorage.setItem('ak_session', 'true');
  133 |       window.sessionStorage.setItem('ak_session', 'true');
  134 |     });
  135 |     await context.addCookies([
  136 |       { name: 'ak_session', value: createSessionToken(), url: baseURL!, httpOnly: true, sameSite: 'Lax' },
  137 |     ]);
  138 | 
  139 |     // La geometria depende del tamano de pantalla, asi que cada perfil de
  140 |     // Playwright (escritorio y celular) guarda su propia referencia.
  141 |     const perfil = test.info().project.name;
  142 |     const clave = (ruta: string) => `${perfil} ${ruta}`;
  143 | 
  144 |     const referencia = leerReferencia();
  145 |     const actual: Record<string, Huella> = {};
  146 |     const referenciasFaltantes: Record<string, Huella> = {};
  147 |     const desvios: string[] = [];
  148 |     /** Fallas que valen aunque la referencia diga que "siempre fue asi". */
  149 |     const absolutos: string[] = [];
  150 | 
  151 |     for (const { ruta } of RUTAS) {
  152 |       const response = await page.goto(ruta, { waitUntil: 'domcontentloaded' });
  153 |       expect(response?.status(), `${ruta} devolvio una respuesta invalida`).toBeLessThan(400);
  154 |       expect(new URL(page.url()).pathname, `${ruta} redirigio inesperadamente`).toBe(ruta);
  155 |       await page.waitForLoadState('networkidle', { timeout: 5_000 }).catch(() => {});
  156 |       if (ruta === '/presentacion-led') {
  157 |         await expect(page.getByText(/Cargando presentaci/i)).toBeHidden({ timeout: 45_000 });
  158 |       }
  159 |       // Las pantallas del panel traen datos del servidor antes de dibujar el
  160 |       // titulo. Con el servidor despertandose, 2,5 segundos no alcanzaban y la
  161 |       // prueba avisaba "la ruta no existe o no carga" con la pantalla sana.
  162 |       await page.locator('h1, main, header').first().waitFor({ state: 'visible', timeout: 60_000 }).catch(() => {});
  163 |       /**
  164 |        * ANTES DE MEDIR, ESPERAR A QUE LAS LETRAS ESTEN CARGADAS.
  165 |        *
  166 |        * **Esto dio una falsa alarma el 9 de septiembre de 2026.** La pantalla de la
  167 |        * presentacion acuso ocho pixeles de corrimiento en el titular; abierta sola,
  168 |        * estaba perfecta. Con la maquina cargada, la tipografia termina de cargar
  169 |        * DESPUES de la medicion, y el titular se acomoda unos pixeles: se estaba
  170 |        * midiendo la pagina a medio vestir.
  171 |        *
  172 |        * Esperar a las letras no afloja el control: lo hace medir lo que el usuario
  173 |        * ve de verdad, en vez de una foto sacada antes de tiempo.
  174 |        */
  175 |       await page.evaluate(() => (document as any).fonts?.ready).catch(() => {});
  176 |       await page.waitForTimeout(2500);
  177 |       const huella = await medirHuella(page);
  178 |       actual[clave(ruta)] = huella;
  179 | 
  180 |       // Reglas absolutas: no dependen de la referencia. Sin esto, la referencia
  181 |       // congelaba defectos como si fueran lo normal (paso de verdad: el catalogo
  182 |       // se salia 54px en celular y la prueba lo daba por bueno porque "no habia
  183 |       // cambiado").
  184 |       if (huella.desborde > 2) {
  185 |         absolutos.push(`${ruta} · se sale ${huella.desborde}px a lo ancho`);
  186 |       }
  187 |       if (huella.h1W === -1 && huella.mainX === -1) {
  188 |         absolutos.push(`${ruta} · no tiene ni titulo ni contenido: la ruta no existe o no carga`);
  189 |       }
  190 | 
  191 |       const esperado = referencia[clave(ruta)];
  192 |       if (!esperado) {
  193 |         referenciasFaltantes[clave(ruta)] = actual[clave(ruta)];
  194 |         if (!ACTUALIZAR_REFERENCIAS_FALTANTES) desvios.push(`${ruta} · falta referencia para ${perfil}`);
  195 |         continue;
  196 |       }
  197 | 
  198 |       for (const [medida, valor] of Object.entries(actual[clave(ruta)])) {
  199 |         const antes = esperado[medida];
  200 |         if (typeof antes !== 'number') continue;
  201 |         // El desborde es exacto; las medidas geométricas admiten redondeo.
  202 |         const margen = medida === 'desborde' ? 0 : TOLERANCIA;
  203 |         if (Math.abs(valor - antes) > margen) {
  204 |           desvios.push(`${ruta} · ${medida}: era ${antes}, ahora ${valor}`);
  205 |         }
  206 |       }
  207 |     }
  208 | 
  209 |     // Si se activo la actualizacion de referencias faltantes, se persisten en disco
  210 |     if (Object.keys(referenciasFaltantes).length > 0 && ACTUALIZAR_REFERENCIAS_FALTANTES) {
  211 |       const nuevaReferencia = { ...referencia, ...referenciasFaltantes };
  212 |       fs.writeFileSync(REFERENCIA, `${JSON.stringify(nuevaReferencia, null, 2)}\n`);
  213 |       test.info().annotations.push({
  214 |         type: 'referencia',
  215 |         description: `Se agregaron ${Object.keys(referenciasFaltantes).length} referencias faltantes para ${perfil}.`,
  216 |       });
  217 |     }
  218 | 
  219 |     // Primera corrida (o referencia borrada a proposito): se genera la referencia
  220 |     // pero las reglas absolutas se exigen igual, para no grabar un defecto.
  221 |     const faltaEsteperfil = !Object.keys(referencia).some((k) => k.startsWith(`${perfil} `));
  222 |     if (Object.keys(referencia).length === 0 || faltaEsteperfil) {
  223 |       fs.writeFileSync(REFERENCIA, `${JSON.stringify({ ...referencia, ...actual }, null, 2)}\n`);
  224 |       test.info().annotations.push({ type: 'referencia', description: `Huella generada para ${perfil}.` });
  225 |       expect(absolutos, `Pantallas con defectos propios:\n  ${absolutos.join('\n  ')}`).toEqual([]);
  226 |       return;
  227 |     }
  228 | 
  229 |     expect(absolutos, `Pantallas con defectos propios:\n  ${absolutos.join('\n  ')}`).toEqual([]);
> 230 |     expect(desvios, `La maquetación cambió:\n  ${desvios.join('\n  ')}`).toEqual([]);
      |                                                                          ^ Error: La maquetación cambió:
  231 |   });
  232 | });
  233 | 
```