# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: ak207-layout-baseline.spec.ts >> huella de maquetación >> las pantallas de referencia mantienen su geometría
- Location: tests\e2e\ak207-layout-baseline.spec.ts:128:7

# Error details

```
Error: La maquetación cambió:
  /admin · h1W: era 101, ahora 98

expect(received).toEqual(expected) // deep equality

- Expected  - 1
+ Received  + 3

- Array []
+ Array [
+   "/admin · h1W: era 101, ahora 98",
+ ]
```

# Page snapshot

```yaml
- generic [active] [ref=e1]:
  - generic [ref=e2]:
    - main [ref=e3]:
      - generic [ref=e4]:
        - generic [ref=e5]:
          - generic [ref=e6]:
            - button "Abrir menu lateral" [ref=e7] [cursor=pointer]:
              - img
              - generic [ref=e8]: Toggle Sidebar
            - heading "AK Producciones" [level=1] [ref=e9]
          - generic [ref=e10]:
            - link:
              - /url: /pagos-rapidos
            - link [ref=e11] [cursor=pointer]:
              - /url: /pagos-rapidos
              - button [ref=e12]:
                - img
            - button "Abrir notificaciones" [ref=e13] [cursor=pointer]:
              - img
              - generic [ref=e14]: Abrir notificaciones
            - button "Logo de la Empresa" [ref=e15] [cursor=pointer]:
              - img "Logo de la Empresa" [ref=e17]
        - main [ref=e18]:
          - main [ref=e20]:
            - generic [ref=e21]:
              - generic [ref=e22]:
                - link "Volver a contabilidad" [ref=e23] [cursor=pointer]:
                  - /url: /contabilidad
                  - img
                  - text: Volver a contabilidad
                - generic [ref=e24]: Comercial 360
              - generic [ref=e25]:
                - generic [ref=e27]:
                  - generic [ref=e28]:
                    - img [ref=e29]
                    - text: Presentacion comercial conectada con CRM, presupuesto y LED
                  - heading "Portal Comercial LED AK" [level=1] [ref=e32]
                  - paragraph [ref=e33]: "Esta pantalla hace visible el trabajo posterior a la PR #445: presentacion comercial, simulador, descuento visual, seguimiento, galeria comercial y Portal LED."
                  - generic [ref=e34]:
                    - link "Abrir Portal LED" [ref=e35] [cursor=pointer]:
                      - /url: /presentacion-led
                      - img
                      - text: Abrir Portal LED
                    - link "Ver galeria LED" [ref=e36] [cursor=pointer]:
                      - /url: /galeria-led
                      - img
                      - text: Ver galeria LED
                    - link "Ir al CRM" [ref=e37] [cursor=pointer]:
                      - /url: /contabilidad/crm
                      - img
                      - text: Ir al CRM
                - generic [ref=e38]:
                  - generic [ref=e40]:
                    - generic [ref=e41]: Ejemplo de Cierre Comercial
                    - generic [ref=e42]: EJEMPLO ILUSTRATIVO
                  - generic [ref=e43]:
                    - generic [ref=e44]:
                      - generic [ref=e45]:
                        - generic [ref=e46]: Simulación de Referencia
                        - generic [ref=e47]: No es precio real
                      - paragraph [ref=e48]: Total final de prueba
                      - paragraph [ref=e49]: $ 680.000
                      - paragraph [ref=e50]: "Ahorro mostrado en simulación: $ 165.000"
                    - paragraph [ref=e51]: "* Este bloque es una demostración del motor comercial para capacitaciones internas. No representa la cotización de ningún cliente real."
              - generic [ref=e52]:
                - generic [ref=e54]:
                  - img [ref=e55]
                  - paragraph [ref=e57]: Secciones LED
                  - paragraph [ref=e58]: "10"
                - generic [ref=e60]:
                  - img [ref=e61]
                  - paragraph [ref=e65]: Temperatura lead
                  - paragraph [ref=e66]: urgente
                - generic [ref=e68]:
                  - img [ref=e69]
                  - paragraph [ref=e71]: Tareas seguimiento
                  - paragraph [ref=e72]: "3"
                - generic [ref=e74]:
                  - img [ref=e75]
                  - paragraph [ref=e77]: Reglas visuales
                  - paragraph [ref=e78]: "6"
              - generic [ref=e79]:
                - generic [ref=e80]:
                  - generic [ref=e82]: Camino comercial visible
                  - generic [ref=e83]:
                    - generic [ref=e84]:
                      - generic [ref=e85]:
                        - paragraph [ref=e86]: 1. Portada comercial AK
                        - generic [ref=e87]: hero
                      - paragraph [ref=e88]: Marca, foto/video fuerte, tipo de fiesta y promesa principal.
                      - paragraph [ref=e89]: "Poco texto, imagen grande y una frase fuerte: organizamos todo para que disfrutes como invitado."
                    - generic [ref=e90]:
                      - generic [ref=e91]:
                        - paragraph [ref=e92]: 2. Confianza y trayectoria
                        - generic [ref=e93]: cards
                      - paragraph [ref=e94]: Experiencia, eventos, clientes, Club Uruguay y equipo AK.
                      - paragraph [ref=e95]: Mostrar prueba visual y social antes de hablar de precios.
                    - generic [ref=e96]:
                      - generic [ref=e97]:
                        - paragraph [ref=e98]: 3. Problema y solucion
                        - generic [ref=e99]: split
                      - paragraph [ref=e100]: Organizar separado genera estres; AK centraliza y coordina.
                      - paragraph [ref=e101]: Izquierda dolor del cliente, derecha solucion AK.
                    - generic [ref=e102]:
                      - generic [ref=e103]:
                        - paragraph [ref=e104]: 4. Tecnologia AK
                        - generic [ref=e105]: cards
                      - paragraph [ref=e106]: Portal cliente, invitado, invitacion, RSVP, red social, muro, album y seguimiento.
                      - paragraph [ref=e107]: Explicar beneficios en tarjetas grandes, no tecnicismos, antes de entrar al precio.
                    - generic [ref=e108]:
                      - generic [ref=e109]:
                        - paragraph [ref=e110]: 4.5. Zona tecnologica para fiestas
                        - generic [ref=e111]: cards
                      - paragraph [ref=e112]: Zona digital adolescente, fotocabina, 360, Vogue, espejo, barra tactil, totems y modo audiorritmico.
                      - paragraph [ref=e113]: "Venderlo como paquetes activables: incluido, opcional o apagado segun lo contratado."
                    - generic [ref=e114]:
                      - generic [ref=e115]:
                        - paragraph [ref=e116]: 5. Servicios por experiencia
                        - generic [ref=e117]: cards
                      - paragraph [ref=e118]: Salon, gastronomia, decoracion, musica, foto, video, personal y extras.
                      - paragraph [ref=e119]: Cada servicio debe tener foto, beneficio y boton para marcar interes.
                    - generic [ref=e120]:
                      - generic [ref=e121]:
                        - paragraph [ref=e122]: 6. Menus con fotos
                        - generic [ref=e123]: gallery
                      - paragraph [ref=e124]: Entradas, platos, ninos, adolescentes, postres y opciones por presupuesto.
                      - paragraph [ref=e125]: La comida se vende con imagen grande y descripcion corta.
                    - generic [ref=e126]:
                      - generic [ref=e127]:
                        - paragraph [ref=e128]: 7. Galeria comercial
                        - generic [ref=e129]: gallery
                      - paragraph [ref=e130]: Fotos por tipo de fiesta, servicio y subservicio.
                      - paragraph [ref=e131]: Filtrar por tipo de fiesta antes de mostrar fotos.
                    - generic [ref=e132]:
                      - generic [ref=e133]:
                        - paragraph [ref=e134]: 8. Seleccion de entrevista
                        - generic [ref=e135]: summary
                      - paragraph [ref=e136]: Lo que interesa, lo pendiente, lo incluido y lo marcado como regalo.
                      - paragraph [ref=e137]: Mantener una bandeja lateral visible con lo seleccionado.
                    - generic [ref=e138]:
                      - generic [ref=e139]:
                        - paragraph [ref=e140]: 9. Cierre comercial
                        - generic [ref=e141]: closing
                      - paragraph [ref=e142]: Resumen, valor comercial, bonificacion visual, regalos, sena y proximos pasos.
                      - paragraph [ref=e143]: "Cerrar con proximos pasos claros: presupuesto, entrevista, sena y contrato."
                - generic [ref=e144]:
                  - generic [ref=e145]:
                    - generic [ref=e147]: Descuento visual sin tocar precio real
                    - generic [ref=e148]:
                      - generic [ref=e149]:
                        - generic [ref=e150]: Valor comercial de servicios
                        - strong [ref=e151]: $ 800.000
                      - generic [ref=e152]:
                        - generic [ref=e153]: Bonificacion comercial 15%
                        - strong [ref=e154]: "-$ 120.000"
                      - generic [ref=e155]:
                        - generic [ref=e156]: Regalos incluidos
                        - strong [ref=e157]: $ 45.000
                      - generic [ref=e158]:
                        - generic [ref=e159]: Total final a contratar
                        - strong [ref=e160]: $ 680.000
                  - generic [ref=e161]:
                    - generic [ref=e163]: Seguimiento automatico sugerido
                    - generic [ref=e164]:
                      - generic [ref=e165]:
                        - generic [ref=e166]:
                          - paragraph [ref=e167]: Responder WhatsApp y proponer entrevista hoy
                          - generic [ref=e168]: ahora
                        - paragraph [ref=e169]: Cliente AK, gracias por usar el simulador de AK Producciones. Ya tenemos datos de Fiesta de 15. El simulador te dejó una referencia de UYU 680.000. Además viste cómo AK conecta portal, invitación, invitados, muro social y seguimiento para que la fiesta no sea solo una lista de servicios. El siguiente paso es coordinar una entrevista gratis para revisar servicios, menú, fecha y dejar el presupuesto bien ajustado.
                      - generic [ref=e170]:
                        - generic [ref=e171]:
                          - paragraph [ref=e172]: Actualizar etapa y etiquetas en CRM
                          - generic [ref=e173]: hoy
                        - paragraph [ref=e174]: "Origen comercial: portal_led | Tipo de fiesta: Fiesta de 15 | Invitados: 120 | Referencia: UYU 680.000"
                      - generic [ref=e175]:
                        - generic [ref=e176]:
                          - paragraph [ref=e177]: Llamar si no responde WhatsApp
                          - generic [ref=e178]: hoy
                        - paragraph [ref=e179]: Lead con intencion alta. Intentar contacto directo si no responde.
              - generic [ref=e180]:
                - generic [ref=e181]:
                  - generic [ref=e183]: Portal LED
                  - generic [ref=e184]:
                    - generic [ref=e185]:
                      - img [ref=e186]
                      - paragraph [ref=e189]: "1. Portada comercial AK: Poco texto, imagen grande y una frase fuerte: organizamos todo para que disfrutes como invitado."
                    - generic [ref=e190]:
                      - img [ref=e191]
                      - paragraph [ref=e194]: "2. Confianza y trayectoria: Mostrar prueba visual y social antes de hablar de precios."
                    - generic [ref=e195]:
                      - img [ref=e196]
                      - paragraph [ref=e199]: "3. Problema y solucion: Izquierda dolor del cliente, derecha solucion AK."
                    - generic [ref=e200]:
                      - img [ref=e201]
                      - paragraph [ref=e204]: "4. Tecnologia AK: Explicar beneficios en tarjetas grandes, no tecnicismos, antes de entrar al precio."
                    - generic [ref=e205]:
                      - img [ref=e206]
                      - paragraph [ref=e209]: "4.5. Zona tecnologica para fiestas: Venderlo como paquetes activables: incluido, opcional o apagado segun lo contratado."
                    - generic [ref=e210]:
                      - img [ref=e211]
                      - paragraph [ref=e214]: "5. Servicios por experiencia: Cada servicio debe tener foto, beneficio y boton para marcar interes."
                - generic [ref=e215]:
                  - generic [ref=e217]: Simulador
                  - generic [ref=e218]:
                    - generic [ref=e219]:
                      - img [ref=e220]
                      - paragraph [ref=e223]: Guardar origen comercial del lead.
                    - generic [ref=e224]:
                      - img [ref=e225]
                      - paragraph [ref=e228]: Marcar si vio la presentacion de valor AK antes del precio.
                    - generic [ref=e229]:
                      - img [ref=e230]
                      - paragraph [ref=e233]: Guardar presupuesto como referencia pendiente de verificacion.
                    - generic [ref=e234]:
                      - img [ref=e235]
                      - paragraph [ref=e238]: Crear tarea de seguimiento si no agenda entrevista.
                    - generic [ref=e239]:
                      - img [ref=e240]
                      - paragraph [ref=e243]: Preparar mensaje WhatsApp con entrevista gratis como siguiente paso.
                    - generic [ref=e244]:
                      - img [ref=e245]
                      - paragraph [ref=e248]: Separar clientes que solo calcularon de los que ya vieron tecnologia AK.
                    - generic [ref=e249]:
                      - img [ref=e250]
                      - paragraph [ref=e253]: Priorizar cierre de fecha cuando hay entrevista pedida o evento cercano.
                - generic [ref=e254]:
                  - generic [ref=e256]: Galeria y CRM
                  - generic [ref=e257]:
                    - generic [ref=e258]:
                      - img [ref=e259]
                      - paragraph [ref=e262]: Cargar cada foto o video con tipo de fiesta, servicio y subservicio.
                    - generic [ref=e263]:
                      - img [ref=e264]
                      - paragraph [ref=e267]: Marcar destacadas para Portal LED y landings.
                    - generic [ref=e268]:
                      - img [ref=e269]
                      - paragraph [ref=e272]: Usar superficies para decidir si aparece en Portal LED, web, landing, redes o presupuesto.
                    - generic [ref=e273]:
                      - img [ref=e274]
                      - paragraph [ref=e277]: Cada presupuesto de simulador debe crear o actualizar un lead en CRM.
                    - generic [ref=e278]:
                      - img [ref=e279]
                      - paragraph [ref=e282]: Cada lead debe guardar origen, temperatura, tags y proxima accion.
                    - generic [ref=e283]:
                      - img [ref=e284]
                      - paragraph [ref=e287]: WhatsApp debe ser el primer canal si el cliente dejo telefono o hizo clic.
              - generic [ref=e289]:
                - generic [ref=e290]:
                  - heading "Resultado buscado" [level=2] [ref=e291]
                  - paragraph [ref=e292]: Que cada consulta comercial tenga presentacion, presupuesto, seguimiento y material visual conectados.
                - link "Abrir simulador" [ref=e293] [cursor=pointer]:
                  - /url: /simulador-de-presupuesto
                  - img
                  - text: Abrir simulador
    - navigation "Navegacion del modulo" [ref=e294]:
      - button "Volver" [ref=e295] [cursor=pointer]:
        - img
      - button "Ir al panel principal" [ref=e296] [cursor=pointer]:
        - img
    - button "Abrir Asistente IA AK" [ref=e297] [cursor=pointer]:
      - img [ref=e298]
  - region "Notifications (F8)":
    - list
  - alert [ref=e301]
```

# Test source

```ts
  130 | 
  131 |     await context.addInitScript(() => {
  132 |       window.localStorage.setItem('ak_session', 'true');
  133 |       window.sessionStorage.setItem('ak_session', 'true');
  134 |     });
  135 |     await context.addCookies([
  136 |       { name: 'ak_session', value: createSessionToken(), url: baseURL!, httpOnly: true, sameSite: 'Lax' },
  137 |     ]);
  138 | 
  139 |     // La geometria depende del tamano de pantalla, asi que cada perfil de
  140 |     // Playwright (escritorio y celular) guarda su propia referencia.
  141 |     const perfil = test.info().project.name;
  142 |     const clave = (ruta: string) => `${perfil} ${ruta}`;
  143 | 
  144 |     const referencia = leerReferencia();
  145 |     const actual: Record<string, Huella> = {};
  146 |     const referenciasFaltantes: Record<string, Huella> = {};
  147 |     const desvios: string[] = [];
  148 |     /** Fallas que valen aunque la referencia diga que "siempre fue asi". */
  149 |     const absolutos: string[] = [];
  150 | 
  151 |     for (const { ruta } of RUTAS) {
  152 |       const response = await page.goto(ruta, { waitUntil: 'domcontentloaded' });
  153 |       expect(response?.status(), `${ruta} devolvio una respuesta invalida`).toBeLessThan(400);
  154 |       expect(new URL(page.url()).pathname, `${ruta} redirigio inesperadamente`).toBe(ruta);
  155 |       await page.waitForLoadState('networkidle', { timeout: 5_000 }).catch(() => {});
  156 |       if (ruta === '/presentacion-led') {
  157 |         await expect(page.getByText(/Cargando presentaci/i)).toBeHidden({ timeout: 45_000 });
  158 |       }
  159 |       // Las pantallas del panel traen datos del servidor antes de dibujar el
  160 |       // titulo. Con el servidor despertandose, 2,5 segundos no alcanzaban y la
  161 |       // prueba avisaba "la ruta no existe o no carga" con la pantalla sana.
  162 |       await page.locator('h1, main, header').first().waitFor({ state: 'visible', timeout: 60_000 }).catch(() => {});
  163 |       /**
  164 |        * ANTES DE MEDIR, ESPERAR A QUE LAS LETRAS ESTEN CARGADAS.
  165 |        *
  166 |        * **Esto dio una falsa alarma el 9 de septiembre de 2026.** La pantalla de la
  167 |        * presentacion acuso ocho pixeles de corrimiento en el titular; abierta sola,
  168 |        * estaba perfecta. Con la maquina cargada, la tipografia termina de cargar
  169 |        * DESPUES de la medicion, y el titular se acomoda unos pixeles: se estaba
  170 |        * midiendo la pagina a medio vestir.
  171 |        *
  172 |        * Esperar a las letras no afloja el control: lo hace medir lo que el usuario
  173 |        * ve de verdad, en vez de una foto sacada antes de tiempo.
  174 |        */
  175 |       await page.evaluate(() => (document as any).fonts?.ready).catch(() => {});
  176 |       await page.waitForTimeout(2500);
  177 |       const huella = await medirHuella(page);
  178 |       actual[clave(ruta)] = huella;
  179 | 
  180 |       // Reglas absolutas: no dependen de la referencia. Sin esto, la referencia
  181 |       // congelaba defectos como si fueran lo normal (paso de verdad: el catalogo
  182 |       // se salia 54px en celular y la prueba lo daba por bueno porque "no habia
  183 |       // cambiado").
  184 |       if (huella.desborde > 2) {
  185 |         absolutos.push(`${ruta} · se sale ${huella.desborde}px a lo ancho`);
  186 |       }
  187 |       if (huella.h1W === -1 && huella.mainX === -1) {
  188 |         absolutos.push(`${ruta} · no tiene ni titulo ni contenido: la ruta no existe o no carga`);
  189 |       }
  190 | 
  191 |       const esperado = referencia[clave(ruta)];
  192 |       if (!esperado) {
  193 |         referenciasFaltantes[clave(ruta)] = actual[clave(ruta)];
  194 |         if (!ACTUALIZAR_REFERENCIAS_FALTANTES) desvios.push(`${ruta} · falta referencia para ${perfil}`);
  195 |         continue;
  196 |       }
  197 | 
  198 |       for (const [medida, valor] of Object.entries(actual[clave(ruta)])) {
  199 |         const antes = esperado[medida];
  200 |         if (typeof antes !== 'number') continue;
  201 |         // El desborde es exacto; las medidas geométricas admiten redondeo.
  202 |         const margen = medida === 'desborde' ? 0 : TOLERANCIA;
  203 |         if (Math.abs(valor - antes) > margen) {
  204 |           desvios.push(`${ruta} · ${medida}: era ${antes}, ahora ${valor}`);
  205 |         }
  206 |       }
  207 |     }
  208 | 
  209 |     // Si se activo la actualizacion de referencias faltantes, se persisten en disco
  210 |     if (Object.keys(referenciasFaltantes).length > 0 && ACTUALIZAR_REFERENCIAS_FALTANTES) {
  211 |       const nuevaReferencia = { ...referencia, ...referenciasFaltantes };
  212 |       fs.writeFileSync(REFERENCIA, `${JSON.stringify(nuevaReferencia, null, 2)}\n`);
  213 |       test.info().annotations.push({
  214 |         type: 'referencia',
  215 |         description: `Se agregaron ${Object.keys(referenciasFaltantes).length} referencias faltantes para ${perfil}.`,
  216 |       });
  217 |     }
  218 | 
  219 |     // Primera corrida (o referencia borrada a proposito): se genera la referencia
  220 |     // pero las reglas absolutas se exigen igual, para no grabar un defecto.
  221 |     const faltaEsteperfil = !Object.keys(referencia).some((k) => k.startsWith(`${perfil} `));
  222 |     if (Object.keys(referencia).length === 0 || faltaEsteperfil) {
  223 |       fs.writeFileSync(REFERENCIA, `${JSON.stringify({ ...referencia, ...actual }, null, 2)}\n`);
  224 |       test.info().annotations.push({ type: 'referencia', description: `Huella generada para ${perfil}.` });
  225 |       expect(absolutos, `Pantallas con defectos propios:\n  ${absolutos.join('\n  ')}`).toEqual([]);
  226 |       return;
  227 |     }
  228 | 
  229 |     expect(absolutos, `Pantallas con defectos propios:\n  ${absolutos.join('\n  ')}`).toEqual([]);
> 230 |     expect(desvios, `La maquetación cambió:\n  ${desvios.join('\n  ')}`).toEqual([]);
      |                                                                          ^ Error: La maquetación cambió:
  231 |   });
  232 | });
  233 | 
```