# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: ak207-mobile-overflow.spec.ts >> sin desborde horizontal en celular >> rutas internas del staff
- Location: tests\e2e\ak207-mobile-overflow.spec.ts:55:7

# Error details

```
Test timeout of 300000ms exceeded.
```

```
Error: page.goto: Test timeout of 300000ms exceeded.
Call log:
  - navigating to "http://127.0.0.1:3300/fiestas/nueva/gestion-costos-rentabilidad", waiting until "domcontentloaded"

```

# Page snapshot

```yaml
- generic [active] [ref=e1]:
  - img [ref=e3]
  - region "Notifications (F8)":
    - list
```

# Test source

```ts
  1  | import {test as __akAudit207} from '@playwright/test';
  2  | __akAudit207.beforeEach(async({context},info)=>{
  3  |  await context.route('**/*',async r=>{const u=new URL(r.request().url());if(/^https?:$/.test(u.protocol)&&!['127.0.0.1','localhost','[::1]'].includes(u.hostname)){await info.attach('qa-egress-blocked',{contentType:'text/plain',body:u.origin+u.pathname});await r.abort('blockedbyclient');}else await r.continue();});
  4  |  await context.route('https://firebaseinstallations.googleapis.com/**',async r=>{const u=new URL(r.request().url());const body=u.pathname.endsWith('authTokens:generate')?{token:'qa368-fis-only',expiresIn:'604800s'}:{fid:'c'+'a'.repeat(21),refreshToken:'qa368-fis-refresh-only',authToken:{token:'qa368-fis-only',expiresIn:'604800s'}};await r.fulfill({status:200,contentType:'application/json',body:JSON.stringify(body)});});
  5  |  await info.attach('qa-fis-mode',{contentType:'text/plain',body:'LOCAL DOUBLE only; no Firebase provider acceptance'});
  6  | });
  7  | import crypto from 'node:crypto';
  8  | import { expect, test } from '@playwright/test';
  9  | 
  10 | /**
  11 |  * Guarda de desborde horizontal en celular.
  12 |  *
  13 |  * Una pantalla "desborda" cuando su contenido es mas ancho que la ventana y
  14 |  * obliga a arrastrar la pagina de costado. Es de los defectos que mas se notan
  15 |  * en un celular y de los que menos se ven revisando codigo, porque aparece solo
  16 |  * al combinar anchos minimos con contenedores que no pueden encogerse.
  17 |  *
  18 |  * Estas rutas ya se verificaron sin desborde; la prueba evita que vuelva.
  19 |  */
  20 | 
  21 | const SESSION_SECRET = 'playwright-session-secret-with-enough-entropy';
  22 | 
  23 | function createSessionToken() {
  24 |   const payload = `v1.${Date.now() + 60 * 60 * 1000}.${crypto.randomUUID()}`;
  25 |   return `${payload}.${crypto.createHmac('sha256', SESSION_SECRET).update(payload).digest('hex')}`;
  26 | }
  27 | 
  28 | const RUTAS_INTERNAS = ['/admin', '/customers', '/presupuestos', '/eventos', '/pagos-rapidos', '/empresa/menus', '/alertas', '/empresa/contabilidad/reportes',
  29 |   '/empresa/menus/tragos', '/fiestas/nueva/reuniones', '/settings/cupones',
  30 |   '/settings/notifications', '/settings/whatsapp-business', '/settings/templates/layouts',
  31 |   '/empresa/red-social-eventos', '/fiestas/nueva/decoracion', '/settings/contenido-publico',
  32 |   // Pantallas que listan mucha gente o muchos ítems: con la fiesta de prueba de
  33 |   // 80 invitados en diez mesas es donde aparecen los desbordes de verdad.
  34 |   '/fiestas/nueva/invitados', '/fiestas/nueva/invitados/layout',
  35 |   '/fiestas/nueva/personal', '/fiestas/nueva/carga-operativa',
  36 |   '/fiestas/nueva/gestion-costos-rentabilidad',
  37 |   '/empresa/insumos', '/empresa/activos-fijos'];
  38 | // El catálogo se muestra en persona, con el cliente al lado: que se corte el
  39 | // botón de avanzar es de lo peor que puede pasar. Va con los cinco tipos.
  40 | const RUTAS_PUBLICAS = ['/', '/simulador-de-presupuesto', '/presentacion-led',
  41 |   '/catalogo/bodas', '/catalogo/xv-anos', '/catalogo/cumpleanos',
  42 |   '/catalogo/corporativos', '/catalogo/aniversarios'];
  43 | 
  44 | /** Margen de 2px: los navegadores redondean subpixeles al medir. */
  45 | const TOLERANCIA = 2;
  46 | 
  47 | async function medirDesborde(page: import('@playwright/test').Page) {
  48 |   return page.evaluate(() => {
  49 |     const doc = document.documentElement;
  50 |     return doc.scrollWidth - doc.clientWidth;
  51 |   });
  52 | }
  53 | 
  54 | test.describe('sin desborde horizontal en celular', () => {
  55 |   test('rutas internas del staff', async ({ page, context, baseURL }) => {
  56 |     test.setTimeout(300_000);
  57 |     await context.addInitScript(() => {
  58 |       window.localStorage.setItem('ak_session', 'true');
  59 |       window.sessionStorage.setItem('ak_session', 'true');
  60 |     });
  61 |     await context.addCookies([
  62 |       { name: 'ak_session', value: createSessionToken(), url: baseURL!, httpOnly: true, sameSite: 'Lax' },
  63 |     ]);
  64 | 
  65 |     for (const ruta of RUTAS_INTERNAS) {
> 66 |       const response = await page.goto(ruta, { waitUntil: 'domcontentloaded' });
     |                                   ^ Error: page.goto: Test timeout of 300000ms exceeded.
  67 |       expect(response?.status(), `${ruta} devolvio una respuesta invalida`).toBeLessThan(400);
  68 |       expect(new URL(page.url()).pathname, `${ruta} redirigio inesperadamente`).toBe(ruta);
  69 |       // Se mide el estado ya asentado: mientras cargan datos, algunas pantallas
  70 |       // muestran anchos provisorios que no reflejan lo que termina viendo el usuario.
  71 |       await page.waitForLoadState('networkidle', { timeout: 5_000 }).catch(() => {});
  72 |       await page.waitForTimeout(4000);
  73 |       const desborde = await medirDesborde(page);
  74 |       expect(desborde, `${ruta} desborda ${desborde}px a lo ancho en celular`).toBeLessThanOrEqual(TOLERANCIA);
  75 |     }
  76 |   });
  77 | 
  78 |   test('rutas publicas', async ({ page }) => {
  79 |     test.setTimeout(180_000);
  80 |     for (const ruta of RUTAS_PUBLICAS) {
  81 |       const response = await page.goto(ruta, { waitUntil: 'domcontentloaded' });
  82 |       expect(response?.status(), `${ruta} devolvio una respuesta invalida`).toBeLessThan(400);
  83 |       expect(new URL(page.url()).pathname, `${ruta} redirigio inesperadamente`).toBe(ruta);
  84 |       // Se mide el estado ya asentado: mientras cargan datos, algunas pantallas
  85 |       // muestran anchos provisorios que no reflejan lo que termina viendo el usuario.
  86 |       await page.waitForLoadState('networkidle', { timeout: 5_000 }).catch(() => {});
  87 |       await page.waitForTimeout(4000);
  88 |       const desborde = await medirDesborde(page);
  89 |       expect(desborde, `${ruta} desborda ${desborde}px a lo ancho en celular`).toBeLessThanOrEqual(TOLERANCIA);
  90 |     }
  91 |   });
  92 | });
  93 | 
```