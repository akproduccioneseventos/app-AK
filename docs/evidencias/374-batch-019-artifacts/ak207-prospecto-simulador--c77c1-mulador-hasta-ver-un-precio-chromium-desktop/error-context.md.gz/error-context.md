# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: ak207-prospecto-simulador.spec.ts >> recorrido del prospecto >> llega desde el simulador hasta ver un precio
- Location: tests\e2e\ak207-prospecto-simulador.spec.ts:34:7

# Error details

```
Error: El prospecto llegó al final pero no tiene cómo cerrar

expect(locator).toBeVisible() failed

Locator: getByRole('button', { name: /WhatsApp|Generar presupuesto/i }).first()
Expected: visible
Timeout: 20000ms
Error: element(s) not found

Call log:
  - El prospecto llegó al final pero no tiene cómo cerrar with timeout 20000ms
  - waiting for getByRole('button', { name: /WhatsApp|Generar presupuesto/i }).first()

```

```yaml
- img "AK Producciones"
- text: Armá tu presupuesto Paso 5 de 5 · Edición
- progressbar
- heading "Personalización de tu presupuesto" [level=2]
- paragraph: ¡Llegamos a la etapa final! Ajustá la fecha y los invitados, quitá opcionales de tu paquete o agregá extras a tu gusto. El total se recalcula al instante.
- heading "Información General del Evento" [level=3]:
  - img
  - text: Información General del Evento
- text: Fecha del evento
- button "15 de noviembre de 2026":
  - img
  - text: 15 de noviembre de 2026
- text: Invitados Adultos
- spinbutton: "80"
- text: Niños y Adolescentes
- spinbutton
- heading "Servicios contratados en tu propuesta" [level=3]:
  - img
  - text: Servicios contratados en tu propuesta
- img
- text: Personal 2 activos Mozo Personal • $ 11.960
- button "Retirar servicio":
  - img
- text: Mozo de cocina Personal • $ 11.960
- button "Retirar servicio":
  - img
- img
- text: Servicio de bebidas 1 activos Barra de tragos Servicio de bebidas • $ 31.920
- button "Retirar servicio":
  - img
- img
- text: Servicio de comida 3 activos Mantelería completa Servicio de comida • $ 6.320
- button "Retirar servicio":
  - img
- text: Mobiliario completo Servicio de comida • $ 6.000
- button "Retirar servicio":
  - img
- text: Vajilla Completa Servicio de comida • $ 6.320
- button "Retirar servicio":
  - img
- img
- text: Servicio de decoración 2 activos Cuadro de firmas Servicio de decoración • $ 2.990
- button "Retirar servicio":
  - img
- text: Servicio de Decoración Servicio de decoración • $ 14.990
- button "Retirar servicio":
  - img
- img
- text: Servicio de discoteca 1 activos Servicio de Discoteca Servicio de discoteca • $ 14.900
- button "Retirar servicio":
  - img
- img
- text: Servicio de entretenimiento 1 activos Fotocabina Servicio de entretenimiento • $ 2.990
- button "Retirar servicio":
  - img
- img
- text: Servicio de fotografía 2 activos Fotografía de exteriores Servicio de fotografía • $ 3.990
- button "Retirar servicio":
  - img
- text: Fotografía de la fiesta Servicio de fotografía • $ 9.990
- button "Retirar servicio":
  - img
- img
- text: Servicio de repostería 2 activos Mesa dulce con fuente de chocolate Servicio de repostería • $ 9.520
- button "Retirar servicio":
  - img
- text: Torta Principal Servicio de repostería • $ 8.720
- button "Retirar servicio":
  - img
- img
- text: Regalos Incluidos 6 activos Invitaciones digitales Regalo incluido Organizamos de la fiesta Regalo incluido Mesa de café Regalo incluido Album digital Regalo incluido Video de vida Regalo incluido Pantalla gigante y proyector Regalo incluido
- heading "Personalizá tu fiesta con más servicios" [level=4]:
  - img
  - text: Personalizá tu fiesta con más servicios
- img
- heading "🔥 ¡Subí tu evento al Plan Paquete premium!" [level=4]
- paragraph: "Llevá tu fiesta al siguiente nivel. Agregá estos servicios clave incluidos en el paquete Paquete premium y asegurá una experiencia inolvidable para todos tus invitados:"
- button "⚡ Pasarme al Plan Paquete premium"
- text: Refrescos +$ 11.600
- button "Sumar +"
- text: Banner Gigantografía +$ 2.990
- button "Sumar +"
- text: Candy Bar Temático +$ 8.800
- button "Sumar +"
- text: Lluvia de burbujas +$ 1.500
- button "Sumar +"
- text: Fuegos fríos (2 disparos) +$ 3.000
- button "Sumar +"
- text: Filmación de la fiesta +$ 9.990
- button "Sumar +"
- img
- 'textbox "Buscá servicios adicionales por nombre (ej: cabina, plataforma, barra, cascada)..."'
- heading "¿Querés comparar con otros paquetes?" [level=4]
- text: Alternativa
- heading "Paquete basico" [level=5]
- paragraph: $ 64.821
- paragraph: "- $ 705 por persona"
- button "Cambiar a Paquete basico"
- text: Alternativa
- heading "Paquete premium" [level=5]
- paragraph: $ 149.557
- paragraph: + $ 355 por persona
- button "Cambiar a Paquete premium"
- strong: Precios 2026
- text: — El total mostrado corresponde al precio vigente.
- button "Ver Preguntas Frecuentes (FAQ)":
  - img
  - text: Ver Preguntas Frecuentes (FAQ)
- button "Anterior"
- text: 🎁 ¡Ahorrás $ 22.900 en regalos incluidos!
- button "Ver Resumen y Propuesta"
- paragraph: "Total vigente:"
- paragraph: $ 121.184
- paragraph: $ 1.515 p/p
- region "Notifications (F8)":
  - list
- alert
```

# Test source

```ts
  16  |  *
  17  |  * La prueba llega hasta ver el precio, y **no** genera el presupuesto: ese paso
  18  |  * crea un prospecto de verdad y ensuciaría los datos del negocio con gente que
  19  |  * no existe.
  20  |  */
  21  | 
  22  | const NOMBRE = 'Prospecto de prueba';
  23  | 
  24  | // El simulador registra el avance paso a paso, así que el recorrido crea un
  25  | // prospecto de verdad. Se borra al terminar: el CRM es del negocio, no de las
  26  | // pruebas.
  27  | test.afterAll(() => {
  28  |   borrarProspectosDePrueba();
  29  |   borrarPresupuestosDePrueba();
  30  | });
  31  | const TELEFONO = '099 123 456';
  32  | 
  33  | test.describe('recorrido del prospecto', () => {
  34  |   test('llega desde el simulador hasta ver un precio', async ({ page }) => {
  35  |     test.setTimeout(300_000);
  36  | 
  37  |     const erroresJs: string[] = [];
  38  |     page.on('pageerror', (e) => erroresJs.push(e.message));
  39  | 
  40  |     await page.goto('/simulador-de-presupuesto', { waitUntil: 'domcontentloaded' });
  41  | 
  42  |     // Paso 1: la portada. Se busca por el texto que ve una persona, no por una
  43  |     // marca interna: si el botón cambia de nombre, la prueba tiene que avisar.
  44  |     const empezar = page.getByRole('button', { name: /Comenzar mi presupuesto|Cotizar/i }).first();
  45  |     await expect(empezar, 'No aparece el botón para empezar a cotizar').toBeVisible({ timeout: 45_000 });
  46  |     await empezar.click();
  47  | 
  48  |     // La portada del simulador tiene su propio botón para arrancar el paso a paso.
  49  |     const arrancar = page.getByRole('button', { name: /Cotizar mi fiesta/i }).first();
  50  |     await expect(arrancar, 'No aparece el botón que arranca el paso a paso').toBeVisible({ timeout: 45_000 });
  51  |     await arrancar.click();
  52  | 
  53  |     // Paso 2: sus datos.
  54  |     await expect(page.locator('#simulator-name')).toBeVisible({ timeout: 45_000 });
  55  |     await page.locator('#simulator-name').fill(NOMBRE);
  56  |     await page.locator('#simulator-phone').fill(TELEFONO);
  57  | 
  58  |     // Duración y salón: dos decisiones que cambian el precio.
  59  |     await page.getByText('Mas de 4 horas').first().click();
  60  |     await page.getByText('Tengo salón o locación propia').first().click();
  61  | 
  62  |     // Cantidad de gente.
  63  |     const adultos = page.locator('input[type="number"]').first();
  64  |     await adultos.fill('80');
  65  | 
  66  |     // La fecha: se abre el calendario y se toma un día disponible del mes que viene.
  67  |     const calendario = page.getByRole('button', { name: /fecha|Elegí|Seleccion/i }).first();
  68  |     if (await calendario.isVisible().catch(() => false)) {
  69  |       await calendario.click();
  70  |       const siguiente = page.getByRole('button', { name: /next month|mes siguiente/i }).first();
  71  |       if (await siguiente.isVisible().catch(() => false)) await siguiente.click();
  72  |       // react-day-picker 9: el dia es un boton dentro de la grilla, con nombre
  73  |       // accesible largo ("viernes, 15 de ..."), no una celda llamada "15".
  74  |       const dia = page.getByRole('grid').getByRole('button', { name: /\b15\b/, disabled: false }).first();
  75  |       if (await dia.isVisible().catch(() => false)) await dia.click();
  76  |     }
  77  | 
  78  |     // Avanzar hasta el final del recorrido. Cada "Continuar" tiene que llevar a
  79  |     // algún lado: si uno se traba, la venta se corta ahí.
  80  |     for (let paso = 0; paso < 4; paso += 1) {
  81  |       const continuar = page.getByRole('button', { name: 'Continuar' }).first();
  82  |       if (!(await continuar.isVisible().catch(() => false))) break;
  83  |       await expect(continuar, `El botón "Continuar" quedó bloqueado en el paso ${paso + 2}`).toBeEnabled({ timeout: 20_000 });
  84  |       await continuar.click();
  85  |       await page.waitForTimeout(2500);
  86  |     }
  87  | 
  88  |     // Sobre el final aparece el cartel que ofrece subir de paquete. Es parte de
  89  |     // la venta: una persona lo lee y decide. Acá se elige quedarse con lo que
  90  |     // venía armando, que es lo que hace la mayoría.
  91  |     const mantener = page.getByRole('button', { name: /Mantener mi selección actual/i }).first();
  92  |     if (await mantener.isVisible().catch(() => false)) {
  93  |       await mantener.click();
  94  |       await page.waitForTimeout(1500);
  95  |     }
  96  | 
  97  |     // Lo que importa: el prospecto tiene que ver un precio, no un cero ni un
  98  |     // texto roto.
  99  |     const textoFinal = await page.locator('body').innerText();
  100 |     const montos = textoFinal.match(/\$\s?[\d.]{4,}/g) ?? [];
  101 |     expect(montos.length, `No apareció ningún precio en el recorrido:\n${textoFinal.slice(0, 400)}`).toBeGreaterThan(0);
  102 |     expect(textoFinal).not.toMatch(/NaN|Infinity|\[object Object\]/);
  103 | 
  104 |     // El último paso no dice "Continuar" sino "Ver Resumen y Propuesta": ahí es
  105 |     // donde aparece la propuesta con el precio congelado y el botón para
  106 |     // escribirle a AK. Sin este clic, el recorrido se cortaba una pantalla antes.
  107 |     const verResumen = page.getByRole('button', { name: /Ver Resumen y Propuesta/i }).first();
  108 |     if (await verResumen.isVisible().catch(() => false)) {
  109 |       await expect(verResumen, 'El botón que abre la propuesta final quedó bloqueado').toBeEnabled({ timeout: 20_000 });
  110 |       await verResumen.click();
  111 |       await page.waitForTimeout(2500);
  112 |     }
  113 | 
  114 |     // Y tiene que poder cerrar: o generar el presupuesto o escribirle a AK.
  115 |     const cierre = page.getByRole('button', { name: /WhatsApp|Generar presupuesto/i }).first();
> 116 |     await expect(cierre, 'El prospecto llegó al final pero no tiene cómo cerrar').toBeVisible({ timeout: 20_000 });
      |                                                                                   ^ Error: El prospecto llegó al final pero no tiene cómo cerrar
  117 | 
  118 |     expect(erroresJs, `El simulador tuvo fallas de JavaScript:\n${erroresJs.join('\n')}`).toEqual([]);
  119 |   });
  120 | 
  121 |   test('el catálogo lleva al simulador con el tipo de fiesta elegido', async ({ page }) => {
  122 |     test.setTimeout(180_000);
  123 | 
  124 |     // Es lo que se hace sentado con el cliente: se le muestra el catálogo y de
  125 |     // ahí se pasa a cotizar.
  126 |     await page.goto('/catalogo/bodas', { waitUntil: 'domcontentloaded' });
  127 |     await expect(page.getByRole('button', { name: /Siguiente/i }).first()).toBeVisible({ timeout: 45_000 });
  128 | 
  129 |     const textoCatalogo = await page.locator('body').innerText();
  130 |     expect(textoCatalogo).not.toMatch(/NaN|Infinity|\[object Object\]/);
  131 |     expect(textoCatalogo.length, 'El catálogo quedó vacío').toBeGreaterThan(200);
  132 |   });
  133 | });
  134 | 
```