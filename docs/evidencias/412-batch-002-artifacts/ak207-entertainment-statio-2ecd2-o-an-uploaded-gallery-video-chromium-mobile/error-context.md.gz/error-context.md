# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: ak207-entertainment-stations.spec.ts >> time capsule bakes the configured frame into an uploaded gallery video
- Location: tests\e2e\ak207-entertainment-stations.spec.ts:196:5

# Error details

```
Error: expect(locator).toBeVisible() failed

Locator: getByText('Video Cargado')
Expected: visible
Timeout: 45000ms
Error: element(s) not found

Call log:
  - Expect "toBeVisible" with timeout 45000ms
  - waiting for getByText('Video Cargado')

```

```yaml
- banner:
  - button:
    - img
  - heading "Evento Entretenimiento E2E" [level=1]:
    - img
    - text: Evento Entretenimiento E2E
  - paragraph: Evento Entretenimiento E2E
  - button "Silenciar voz":
    - img
- main:
  - button "Volver al menú":
    - img
    - text: Volver al menú
  - heading "Subir Video" [level=3]
  - paragraph: Selecciona un video de tu galería
  - button "Seleccionar Video Máximo 15 segundos de duración":
    - img
    - paragraph: Seleccionar Video
    - paragraph: Máximo 15 segundos de duración
  - paragraph:
    - text: Tus datos quedan sólo para esta fiesta (Ley 18.331).
    - link "Privacidad":
      - /url: /privacidad
- contentinfo:
  - paragraph: Experiencia por AK Producciones
- button "Cambiar de estación":
  - img
- region "Notifications (F8)":
  - list
- alert
```

# Test source

```ts
  150 | 
  151 |   await page.getByRole('button', { name: /Grabar Video/i }).click();
  152 |   const frameCanvas = page.locator('canvas').first();
  153 |   await expect(frameCanvas).toBeVisible();
  154 |   await expect.poll(async () => frameCanvas.evaluate((element) => {
  155 |     const canvas = element as HTMLCanvasElement;
  156 |     const drawing = canvas.getContext('2d');
  157 |     if (!drawing || canvas.width !== 640 || canvas.height !== 480) return 0;
  158 |     const pixels = drawing.getImageData(0, 0, 40, canvas.height).data;
  159 |     let floralPixels = 0;
  160 |     for (let index = 0; index < pixels.length; index += 4) {
  161 |       const red = pixels[index];
  162 |       const green = pixels[index + 1];
  163 |       const blue = pixels[index + 2];
  164 |       if (green > 170 && green > red * 1.25 && blue > 100) floralPixels += 1;
  165 |     }
  166 |     return floralPixels;
  167 |   })).toBeGreaterThan(20);
  168 | 
  169 |   await page.getByRole('button', { name: /Comenzar a Grabar/i }).click();
  170 |   const stopButton = page.getByRole('button', { name: /Detener Grabación/i });
  171 |   await expect(stopButton).toBeVisible();
  172 |   await page.waitForTimeout(1_000);
  173 |   await stopButton.click();
  174 |   // La etiqueta se llama "Video Grabado", no "Video Analogico". Se verifico en
  175 |   // `src/app/evento/buzon/[fiestaId]/page.tsx`: el paso de revision existe y
  176 |   // funciona, solo cambio el texto. La prueba habia quedado con el nombre viejo.
  177 |   await expect(page.getByText('Video Grabado')).toBeVisible();
  178 |   const reviewVideo = page.locator('video[src^="blob:"]').first();
  179 |   await expect(reviewVideo).toBeVisible();
  180 |   await expect.poll(async () => reviewVideo.evaluate(async (element) => {
  181 |     const source = (element as HTMLVideoElement).src;
  182 |     return (await (await fetch(source)).blob()).size;
  183 |   })).toBeGreaterThan(0);
  184 | 
  185 |   await page.getByRole('button', { name: /Grabar de nuevo/i }).click();
  186 |   await expect(page.getByRole('button', { name: /Comenzar a Grabar/i })).toBeVisible();
  187 |   await page.getByRole('button', { name: /Volver al menú/i }).click();
  188 |   await expect.poll(() => page.evaluate(() => {
  189 |     const testWindow = window as typeof window & { __buzonTestStreams?: MediaStream[] };
  190 |     return (testWindow.__buzonTestStreams || []).every(
  191 |       (mediaStream) => mediaStream.getTracks().every((track) => track.readyState === 'ended'),
  192 |     );
  193 |   })).toBe(true);
  194 | });
  195 | 
  196 | test('time capsule bakes the configured frame into an uploaded gallery video', async ({ context, page }, testInfo) => {
  197 |   
  198 |   const baseURL = testInfo.project.use.baseURL as string;
  199 |   await addAppSession(context, baseURL);
  200 | 
  201 |   const response = await page.goto(`/evento/buzon/${FIESTA_ID}`, { waitUntil: 'domcontentloaded' });
  202 |   expect(response?.status()).toBeLessThan(400);
  203 |   await page.getByRole('button', { name: /Subir video/i }).click();
  204 |   const input = page.locator('input[type="file"][accept="video/*"]');
  205 |   await input.evaluate(async (element) => {
  206 |     const canvas = document.createElement('canvas');
  207 |     canvas.width = 320;
  208 |     canvas.height = 240;
  209 |     const drawing = canvas.getContext('2d');
  210 |     if (drawing) {
  211 |       drawing.fillStyle = '#1e3a5f';
  212 |       drawing.fillRect(0, 0, canvas.width, canvas.height);
  213 |     }
  214 |     const stream = canvas.captureStream(20);
  215 |     const candidates = ['video/mp4', 'video/webm;codecs=vp9', 'video/webm'];
  216 |     const mimeType = candidates.find((candidate) => MediaRecorder.isTypeSupported(candidate)) || '';
  217 |     const recorder = mimeType ? new MediaRecorder(stream, { mimeType }) : new MediaRecorder(stream);
  218 |     const chunks: Blob[] = [];
  219 |     recorder.ondataavailable = (event) => {
  220 |       if (event.data.size > 0) chunks.push(event.data);
  221 |     };
  222 |     const stopped = new Promise<void>((resolve) => {
  223 |       recorder.onstop = () => resolve();
  224 |     });
  225 |     recorder.start(100);
  226 |     let frame = 0;
  227 |     const drawingInterval = window.setInterval(() => {
  228 |       if (!drawing) return;
  229 |       drawing.fillStyle = frame % 2 === 0 ? '#1e3a5f' : '#315b82';
  230 |       drawing.fillRect(0, 0, canvas.width, canvas.height);
  231 |       drawing.fillStyle = '#ffffff';
  232 |       drawing.fillRect((frame * 8) % canvas.width, 80, 40, 40);
  233 |       frame += 1;
  234 |     }, 50);
  235 |     await new Promise((resolve) => setTimeout(resolve, 1_500));
  236 |     window.clearInterval(drawingInterval);
  237 |     recorder.stop();
  238 |     await stopped;
  239 |     stream.getTracks().forEach((track) => track.stop());
  240 | 
  241 |     const outputType = recorder.mimeType || mimeType || 'video/webm';
  242 |     const extension = outputType.includes('mp4') ? 'mp4' : 'webm';
  243 |     const transfer = new DataTransfer();
  244 |     transfer.items.add(new File(chunks, `gallery-test.${extension}`, { type: outputType }));
  245 |     const fileInput = element as HTMLInputElement;
  246 |     fileInput.files = transfer.files;
  247 |     fileInput.dispatchEvent(new Event('change', { bubbles: true }));
  248 |   });
  249 | 
> 250 |   await expect(page.getByText('Video Cargado')).toBeVisible();
      |                                                 ^ Error: expect(locator).toBeVisible() failed
  251 |   const reviewVideo = page.locator('video[src^="blob:"]').first();
  252 |   await expect(reviewVideo).toBeVisible();
  253 |   await expect.poll(async () => reviewVideo.evaluate(async (element) => {
  254 |     const video = element as HTMLVideoElement;
  255 |     video.muted = true;
  256 |     await video.play();
  257 |     await new Promise((resolve) => setTimeout(resolve, 250));
  258 |     const canvas = document.createElement('canvas');
  259 |     canvas.width = 640;
  260 |     canvas.height = 480;
  261 |     const drawing = canvas.getContext('2d');
  262 |     if (!drawing) return 0;
  263 |     drawing.drawImage(video, 0, 0, canvas.width, canvas.height);
  264 |     const pixels = drawing.getImageData(0, 0, 40, canvas.height).data;
  265 |     let floralPixels = 0;
  266 |     for (let index = 0; index < pixels.length; index += 4) {
  267 |       const red = pixels[index];
  268 |       const green = pixels[index + 1];
  269 |       const blue = pixels[index + 2];
  270 |       if (green > 170 && green > red * 1.25 && blue > 100) floralPixels += 1;
  271 |     }
  272 |     return floralPixels;
  273 |   })).toBeGreaterThan(20);
  274 | });
  275 | 
  276 | test('AI mirror keeps one coherent touch selector on desktop and mobile', async ({ context, page }, testInfo) => {
  277 |   const baseURL = testInfo.project.use.baseURL as string;
  278 |   await addAppSession(context, baseURL);
  279 |   await page.addInitScript(() => {
  280 |     const getUserMedia = async () => {
  281 |       const canvas = document.createElement('canvas');
  282 |       canvas.width = 720;
  283 |       canvas.height = 1280;
  284 |       canvas.getContext('2d')?.fillRect(0, 0, canvas.width, canvas.height);
  285 |       return canvas.captureStream(30);
  286 |     };
  287 |     Object.defineProperty(navigator, 'mediaDevices', {
  288 |       configurable: true,
  289 |       value: { getUserMedia },
  290 |     });
  291 |   });
  292 | 
  293 |   const response = await page.goto(
  294 |     `/evento/espejo-magico/${FIESTA_ID}?mode=ia`,
  295 |     { waitUntil: 'domcontentloaded' },
  296 |   );
  297 |   expect(response?.status()).toBeLessThan(400);
  298 |   await expect(page.getByText('1. Elegí tu Estilo IA')).toBeVisible();
  299 |   await expect(page.getByRole('checkbox')).toHaveCount(1);
  300 | 
  301 |   const captureButton = page.getByRole('button', { name: 'Crear avatar IA' });
  302 |   await expect(captureButton).toBeDisabled();
  303 |   await page.getByRole('button', { name: 'Cine & Accion' }).click();
  304 |   await expect(page.getByTestId('selected-ai-style')).toHaveText('Afiche de Cine');
  305 |   await expect(
  306 |     page.getByRole('button', { name: 'Afiche de Cine' }),
  307 |   ).toHaveAttribute('aria-pressed', 'true');
  308 | 
  309 |   await page.getByRole('checkbox').check();
  310 |   await expect(captureButton).toBeEnabled();
  311 |   expect(
  312 |     await page.evaluate(
  313 |       () => document.documentElement.scrollWidth <= window.innerWidth + 1,
  314 |     ),
  315 |   ).toBe(true);
  316 | });
  317 | 
  318 | 
```