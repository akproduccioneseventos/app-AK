# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: ak207-entertainment-stations.spec.ts >> time capsule exposes every media mode and records the configured frame
- Location: tests\e2e\ak207-entertainment-stations.spec.ts:118:5

# Error details

```
Test timeout of 90000ms exceeded.
```

```
Error: locator.click: Test timeout of 90000ms exceeded.
Call log:
  - waiting for getByRole('button', { name: /Detener Grabación/i })
    - locator resolved to <button class="w-full py-3.5 bg-destructive hover:bg-destructive/90 text-destructive-foreground rounded-lg font-black text-sm uppercase tracking-wider flex items-center justify-center gap-2 transition-transform active:scale-95">…</button>
  - attempting click action
    - waiting for element to be visible, enabled and stable
  - element was detached from the DOM, retrying

```

# Test source

```ts
  73  |     `/evento/fotocabina/${FIESTA_ID}?role=operator`,
  74  |     `/evento/plataforma-360/${FIESTA_ID}?role=operator`,
  75  |     `/evento/bogue/${FIESTA_ID}?role=operator`,
  76  |     `/evento/espejo-magico/${FIESTA_ID}?mode=foto&role=operator`,
  77  |     `/evento/espejo-magico/${FIESTA_ID}?mode=firma&role=operator`,
  78  |     `/evento/touchpix/${FIESTA_ID}?role=operator`,
  79  |   ];
  80  | 
  81  |   for (const route of routes) {
  82  |     const response = await page.goto(route, { waitUntil: 'domcontentloaded' });
  83  |     expect(response?.status(), route).toBeLessThan(400);
  84  |     await expect(page.locator('body'), route).not.toContainText(/acceso de estacion no autorizado|no se pudo abrir esta estacion/i);
  85  |     await expect(page.locator('button:visible').first(), route).toBeVisible();
  86  |   }
  87  | });
  88  | 
  89  | test('photobooth display receives a browser camera stream', async ({ context, page }, testInfo) => {
  90  |   const baseURL = testInfo.project.use.baseURL as string;
  91  |   await addAppSession(context, baseURL);
  92  |   await page.addInitScript(() => {
  93  |     const getUserMedia = async () => {
  94  |       const canvas = document.createElement('canvas');
  95  |       canvas.width = 720;
  96  |       canvas.height = 1280;
  97  |       const drawing = canvas.getContext('2d');
  98  |       drawing?.fillRect(0, 0, canvas.width, canvas.height);
  99  |       return canvas.captureStream(30);
  100 |     };
  101 |     Object.defineProperty(navigator, 'mediaDevices', {
  102 |       configurable: true,
  103 |       value: { getUserMedia },
  104 |     });
  105 |   });
  106 | 
  107 |   const response = await page.goto(`/evento/fotocabina/${FIESTA_ID}`, { waitUntil: 'domcontentloaded' });
  108 |   expect(response?.status()).toBeLessThan(400);
  109 |   await expect(page.locator('body')).not.toContainText(/acceso de estacion no autorizado|no se pudo abrir esta estacion/i);
  110 |   // El invitado tiene que VERSE. Puede ser en el `<video>` directo o en el
  111 |   // lienzo de la vista previa: desde que la fotocabina cambia el fondo en vivo,
  112 |   // el video queda oculto a proposito y lo que se muestra es el lienzo con el
  113 |   // fondo ya aplicado. Lo que importa es que se vea la camara, no en cual de
  114 |   // los dos elementos.
  115 |   await expect(page.locator('video:visible, canvas:visible').first()).toBeVisible();
  116 | });
  117 | 
  118 | test('time capsule exposes every media mode and records the configured frame', async ({ context, page }, testInfo) => {
  119 |   
  120 |   const baseURL = testInfo.project.use.baseURL as string;
  121 |   await addAppSession(context, baseURL);
  122 |   await page.addInitScript(() => {
  123 |     const getUserMedia = async () => {
  124 |       const canvas = document.createElement('canvas');
  125 |       canvas.width = 640;
  126 |       canvas.height = 480;
  127 |       const drawing = canvas.getContext('2d');
  128 |       if (drawing) {
  129 |         drawing.fillStyle = '#1e3a5f';
  130 |         drawing.fillRect(0, 0, canvas.width, canvas.height);
  131 |       }
  132 |       const stream = canvas.captureStream(20);
  133 |       const testWindow = window as typeof window & { __buzonTestStreams?: MediaStream[] };
  134 |       testWindow.__buzonTestStreams = [...(testWindow.__buzonTestStreams || []), stream];
  135 |       return stream;
  136 |     };
  137 |     Object.defineProperty(navigator, 'mediaDevices', {
  138 |       configurable: true,
  139 |       value: { getUserMedia },
  140 |     });
  141 |   });
  142 | 
  143 |   const response = await page.goto(`/evento/buzon/${FIESTA_ID}`, { waitUntil: 'domcontentloaded' });
  144 |   expect(response?.status()).toBeLessThan(400);
  145 |   await expect(page.getByRole('button', { name: /Grabar Video/i })).toBeVisible();
  146 |   await expect(page.getByRole('button', { name: /Mensaje de Audio/i })).toBeVisible();
  147 |   await expect(page.getByRole('button', { name: /Subir video/i })).toBeVisible();
  148 |   await expect(page.getByRole('button', { name: /Subir audio/i })).toBeVisible();
  149 |   await expect(page.getByRole('button', { name: /Cabina telefónica retro/i })).toBeVisible();
  150 | 
  151 |   await page.getByRole('button', { name: /Grabar Video/i }).click();
  152 |   const frameCanvas = page.locator('canvas').first();
  153 |   await expect(frameCanvas).toBeVisible();
  154 |   await expect.poll(async () => frameCanvas.evaluate((element) => {
  155 |     const canvas = element as HTMLCanvasElement;
  156 |     const drawing = canvas.getContext('2d');
  157 |     if (!drawing || canvas.width !== 640 || canvas.height !== 480) return 0;
  158 |     const pixels = drawing.getImageData(0, 0, 40, canvas.height).data;
  159 |     let floralPixels = 0;
  160 |     for (let index = 0; index < pixels.length; index += 4) {
  161 |       const red = pixels[index];
  162 |       const green = pixels[index + 1];
  163 |       const blue = pixels[index + 2];
  164 |       if (green > 170 && green > red * 1.25 && blue > 100) floralPixels += 1;
  165 |     }
  166 |     return floralPixels;
  167 |   })).toBeGreaterThan(20);
  168 | 
  169 |   await page.getByRole('button', { name: /Comenzar a Grabar/i }).click();
  170 |   const stopButton = page.getByRole('button', { name: /Detener Grabación/i });
  171 |   await expect(stopButton).toBeVisible();
  172 |   await page.waitForTimeout(1_000);
> 173 |   await stopButton.click();
      |                    ^ Error: locator.click: Test timeout of 90000ms exceeded.
  174 |   // La etiqueta se llama "Video Grabado", no "Video Analogico". Se verifico en
  175 |   // `src/app/evento/buzon/[fiestaId]/page.tsx`: el paso de revision existe y
  176 |   // funciona, solo cambio el texto. La prueba habia quedado con el nombre viejo.
  177 |   await expect(page.getByText('Video Grabado')).toBeVisible();
  178 |   const reviewVideo = page.locator('video[src^="blob:"]').first();
  179 |   await expect(reviewVideo).toBeVisible();
  180 |   await expect.poll(async () => reviewVideo.evaluate(async (element) => {
  181 |     const source = (element as HTMLVideoElement).src;
  182 |     return (await (await fetch(source)).blob()).size;
  183 |   })).toBeGreaterThan(0);
  184 | 
  185 |   await page.getByRole('button', { name: /Grabar de nuevo/i }).click();
  186 |   await expect(page.getByRole('button', { name: /Comenzar a Grabar/i })).toBeVisible();
  187 |   await page.getByRole('button', { name: /Volver al menú/i }).click();
  188 |   await expect.poll(() => page.evaluate(() => {
  189 |     const testWindow = window as typeof window & { __buzonTestStreams?: MediaStream[] };
  190 |     return (testWindow.__buzonTestStreams || []).every(
  191 |       (mediaStream) => mediaStream.getTracks().every((track) => track.readyState === 'ended'),
  192 |     );
  193 |   })).toBe(true);
  194 | });
  195 | 
  196 | test('time capsule bakes the configured frame into an uploaded gallery video', async ({ context, page }, testInfo) => {
  197 |   
  198 |   const baseURL = testInfo.project.use.baseURL as string;
  199 |   await addAppSession(context, baseURL);
  200 | 
  201 |   const response = await page.goto(`/evento/buzon/${FIESTA_ID}`, { waitUntil: 'domcontentloaded' });
  202 |   expect(response?.status()).toBeLessThan(400);
  203 |   await page.getByRole('button', { name: /Subir video/i }).click();
  204 |   const input = page.locator('input[type="file"][accept="video/*"]');
  205 |   await input.evaluate(async (element) => {
  206 |     const canvas = document.createElement('canvas');
  207 |     canvas.width = 320;
  208 |     canvas.height = 240;
  209 |     const drawing = canvas.getContext('2d');
  210 |     if (drawing) {
  211 |       drawing.fillStyle = '#1e3a5f';
  212 |       drawing.fillRect(0, 0, canvas.width, canvas.height);
  213 |     }
  214 |     const stream = canvas.captureStream(20);
  215 |     const candidates = ['video/mp4', 'video/webm;codecs=vp9', 'video/webm'];
  216 |     const mimeType = candidates.find((candidate) => MediaRecorder.isTypeSupported(candidate)) || '';
  217 |     const recorder = mimeType ? new MediaRecorder(stream, { mimeType }) : new MediaRecorder(stream);
  218 |     const chunks: Blob[] = [];
  219 |     recorder.ondataavailable = (event) => {
  220 |       if (event.data.size > 0) chunks.push(event.data);
  221 |     };
  222 |     const stopped = new Promise<void>((resolve) => {
  223 |       recorder.onstop = () => resolve();
  224 |     });
  225 |     recorder.start(100);
  226 |     let frame = 0;
  227 |     const drawingInterval = window.setInterval(() => {
  228 |       if (!drawing) return;
  229 |       drawing.fillStyle = frame % 2 === 0 ? '#1e3a5f' : '#315b82';
  230 |       drawing.fillRect(0, 0, canvas.width, canvas.height);
  231 |       drawing.fillStyle = '#ffffff';
  232 |       drawing.fillRect((frame * 8) % canvas.width, 80, 40, 40);
  233 |       frame += 1;
  234 |     }, 50);
  235 |     await new Promise((resolve) => setTimeout(resolve, 1_500));
  236 |     window.clearInterval(drawingInterval);
  237 |     recorder.stop();
  238 |     await stopped;
  239 |     stream.getTracks().forEach((track) => track.stop());
  240 | 
  241 |     const outputType = recorder.mimeType || mimeType || 'video/webm';
  242 |     const extension = outputType.includes('mp4') ? 'mp4' : 'webm';
  243 |     const transfer = new DataTransfer();
  244 |     transfer.items.add(new File(chunks, `gallery-test.${extension}`, { type: outputType }));
  245 |     const fileInput = element as HTMLInputElement;
  246 |     fileInput.files = transfer.files;
  247 |     fileInput.dispatchEvent(new Event('change', { bubbles: true }));
  248 |   });
  249 | 
  250 |   await expect(page.getByText('Video Cargado')).toBeVisible();
  251 |   const reviewVideo = page.locator('video[src^="blob:"]').first();
  252 |   await expect(reviewVideo).toBeVisible();
  253 |   await expect.poll(async () => reviewVideo.evaluate(async (element) => {
  254 |     const video = element as HTMLVideoElement;
  255 |     video.muted = true;
  256 |     await video.play();
  257 |     await new Promise((resolve) => setTimeout(resolve, 250));
  258 |     const canvas = document.createElement('canvas');
  259 |     canvas.width = 640;
  260 |     canvas.height = 480;
  261 |     const drawing = canvas.getContext('2d');
  262 |     if (!drawing) return 0;
  263 |     drawing.drawImage(video, 0, 0, canvas.width, canvas.height);
  264 |     const pixels = drawing.getImageData(0, 0, 40, canvas.height).data;
  265 |     let floralPixels = 0;
  266 |     for (let index = 0; index < pixels.length; index += 4) {
  267 |       const red = pixels[index];
  268 |       const green = pixels[index + 1];
  269 |       const blue = pixels[index + 2];
  270 |       if (green > 170 && green > red * 1.25 && blue > 100) floralPixels += 1;
  271 |     }
  272 |     return floralPixels;
  273 |   })).toBeGreaterThan(20);
```