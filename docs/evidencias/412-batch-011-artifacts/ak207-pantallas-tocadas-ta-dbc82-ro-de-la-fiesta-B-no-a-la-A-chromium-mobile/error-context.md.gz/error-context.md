# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: ak207-pantallas-tocadas-tanda-12-10.spec.ts >> /fiestas/nueva/centro?fiestaId=B lleva al Centro de la fiesta B, no a la A
- Location: tests\e2e\ak207-pantallas-tocadas-tanda-12-10.spec.ts:75:7

# Error details

```
TimeoutError: page.waitForURL: Timeout 60000ms exceeded.
=========================== logs ===========================
waiting for navigation until "load"
  navigated to "http://127.0.0.1:3300/fiestas/nueva/centro?fiestaId=e2e_tanda_b_1792870366514"
============================================================
```

# Test source

```ts
  1   | import {test as __akAudit207} from '@playwright/test';
  2   | __akAudit207.beforeEach(async({context},info)=>{
  3   |  await context.route('**/*',async r=>{const u=new URL(r.request().url());if(/^https?:$/.test(u.protocol)&&!['127.0.0.1','localhost','[::1]'].includes(u.hostname)){await info.attach('qa-egress-blocked',{contentType:'text/plain',body:u.origin+u.pathname});await r.abort('blockedbyclient');}else await r.continue();});
  4   |  await context.route('https://firebaseinstallations.googleapis.com/**',async r=>{const u=new URL(r.request().url());const body=u.pathname.endsWith('authTokens:generate')?{token:'qa368-fis-only',expiresIn:'604800s'}:{fid:'c'+'a'.repeat(21),refreshToken:'qa368-fis-refresh-only',authToken:{token:'qa368-fis-only',expiresIn:'604800s'}};await r.fulfill({status:200,contentType:'application/json',body:JSON.stringify(body)});});
  5   |  await info.attach('qa-fis-mode',{contentType:'text/plain',body:'LOCAL DOUBLE only; no Firebase provider acceptance'});
  6   | });
  7   | import fs from 'node:fs';
  8   | import path from 'node:path';
  9   | import { expect, test, type Page } from '@playwright/test';
  10  | import { borrarFiesta, crearFiestaDeEstaNoche, guardarFiesta, ponerSesionDelEquipo } from './helpers/fiesta-de-prueba';
  11  | 
  12  | /**
  13  |  * Pantallas tocadas en la tanda del 12 de octubre de 2026.
  14  |  *
  15  |  * Comprueba RESULTADOS:
  16  |  *  - los atajos al Centro de Fiesta y "Servicios contratados" abren la fiesta PEDIDA
  17  |  *    (?fiestaId=B) y no la "actual" (A);
  18  |  *  - "Nueva incidencia" arranca vacía después de guardar una;
  19  |  *  - las pantallas de la torre de control muestran su contenido real y, si la lectura
  20  |  *    falla, avisan en vez de decir "todo tranquilo".
  21  |  *
  22  |  * Las pantallas que prueba este archivo son:
  23  |  *   /fiestas/nueva/centro-total
  24  |  *   /fiestas/nueva/centro
  25  |  *   /fiestas/nueva/mission-control
  26  |  *   /fiestas/nueva/servicios-contratados
  27  |  *   /incidentes
  28  |  *   /control-tower/automatizaciones
  29  |  *   /control-tower/comercial
  30  |  *   /control-tower/post-fiesta
  31  |  *   /control-tower/preparacion
  32  |  */
  33  | 
  34  | const SUFIJO = Date.now();
  35  | const ID_A = `e2e_tanda_a_${SUFIJO}`;
  36  | const ID_B = `e2e_tanda_b_${SUFIJO}`;
  37  | const NOMBRE_A = `Fiesta Alfa ${SUFIJO}`;
  38  | const NOMBRE_B = `Fiesta Beta ${SUFIJO}`;
  39  | 
  40  | const ARCHIVOS_INCIDENTES = [
  41  |   path.join(process.cwd(), 'data', 'incidentes.json'),
  42  |   path.join(process.cwd(), 'src', 'data', 'incidentes.json'),
  43  | ];
  44  | const respaldoIncidentes = new Map<string, string | null>();
  45  | 
  46  | test.beforeAll(() => {
  47  |   for (const [id, nombre] of [[ID_A, NOMBRE_A], [ID_B, NOMBRE_B]] as const) {
  48  |     const f = crearFiestaDeEstaNoche({ id });
  49  |     f.configuracion.nombreEvento = nombre;
  50  |     guardarFiesta(f);
  51  |   }
  52  |   for (const a of ARCHIVOS_INCIDENTES) {
  53  |     respaldoIncidentes.set(a, fs.existsSync(a) ? fs.readFileSync(a, 'utf8') : null);
  54  |   }
  55  | });
  56  | 
  57  | test.afterAll(() => {
  58  |   borrarFiesta(ID_A);
  59  |   borrarFiesta(ID_B);
  60  |   for (const [a, contenido] of respaldoIncidentes) {
  61  |     if (contenido === null) {
  62  |       if (fs.existsSync(a)) fs.unlinkSync(a);
  63  |     } else {
  64  |       fs.writeFileSync(a, contenido);
  65  |     }
  66  |   }
  67  | });
  68  | 
  69  | test.beforeEach(async ({ context, baseURL }, testInfo) => {
  70  |   
  71  |   await ponerSesionDelEquipo(context, baseURL);
  72  | });
  73  | 
  74  | for (const ruta of ['centro-total', 'centro', 'mission-control']) {
  75  |   test(`/fiestas/nueva/${ruta}?fiestaId=B lleva al Centro de la fiesta B, no a la A`, async ({ page }) => {
  76  |     test.setTimeout(120_000);
  77  |     await page.goto(`/fiestas/nueva/${ruta}?fiestaId=${ID_B}`, { waitUntil: 'domcontentloaded' });
> 78  |     await page.waitForURL(new RegExp(`/fiestas/${ID_B}/centro`), { timeout: 60_000 });
      |                ^ TimeoutError: page.waitForURL: Timeout 60000ms exceeded.
  79  |     expect(page.url()).toContain(`/fiestas/${ID_B}/centro`);
  80  |     expect(page.url()).not.toContain(ID_A);
  81  |   });
  82  | }
  83  | 
  84  | test('/fiestas/nueva/servicios-contratados?fiestaId=B muestra los datos de B', async ({ page }) => {
  85  |   test.setTimeout(120_000);
  86  |   const erroresJs: string[] = [];
  87  |   page.on('pageerror', (e) => erroresJs.push(e.message));
  88  |   await page.goto(`/fiestas/nueva/servicios-contratados?fiestaId=${ID_B}`, { waitUntil: 'domcontentloaded' });
  89  |   await expect(page.getByRole('heading', { name: 'Servicios Contratados' })).toBeVisible({ timeout: 60_000 });
  90  |   await expect(page.getByText(NOMBRE_B).first()).toBeVisible({ timeout: 30_000 });
  91  |   await expect(page.getByText(NOMBRE_A)).toHaveCount(0);
  92  |   expect(erroresJs).toEqual([]);
  93  | });
  94  | 
  95  | test('/incidentes: después de guardar una incidencia, "Nueva incidencia" abre con el título vacío', async ({ page }) => {
  96  |   test.setTimeout(120_000);
  97  |   const titulo = `Incidencia de prueba ${SUFIJO}`;
  98  |   await page.goto('/incidentes', { waitUntil: 'domcontentloaded' });
  99  |   await expect(page.getByRole('heading', { name: 'Gestión de Incidentes' })).toBeVisible({ timeout: 60_000 });
  100 | 
  101 |   await page.getByRole('button', { name: /Nueva Incidencia/i }).click();
  102 |   const dialogo = page.getByRole('dialog');
  103 |   await dialogo.getByPlaceholder('Título del incidente').fill(titulo);
  104 |   await dialogo.getByPlaceholder('Nombre del responsable').fill('Responsable de prueba');
  105 |   await dialogo.getByPlaceholder('Describí el incidente...').fill('Texto de prueba');
  106 |   await dialogo.getByRole('button', { name: /Registrar Incidente/i }).click();
  107 | 
  108 |   await expect(page.getByText('Incidente creado', { exact: true })).toBeVisible({ timeout: 30_000 });
  109 |   await expect(page.getByRole('dialog')).toHaveCount(0);
  110 | 
  111 |   await page.getByRole('button', { name: /Nueva Incidencia/i }).click();
  112 |   const dialogo2 = page.getByRole('dialog');
  113 |   await expect(dialogo2.getByPlaceholder('Título del incidente')).toHaveValue('');
  114 |   await expect(dialogo2.getByPlaceholder('Describí el incidente...')).toHaveValue('');
  115 | });
  116 | 
  117 | const TORRE: Array<{ ruta: string; titulo: RegExp }> = [
  118 |   { ruta: '/control-tower/automatizaciones', titulo: /Automatizaciones inteligentes AK/ },
  119 |   { ruta: '/control-tower/comercial', titulo: /Seguimientos comerciales/ },
  120 |   { ruta: '/control-tower/post-fiesta', titulo: /Cierre, testimonios y marketing/ },
  121 |   { ruta: '/control-tower/preparacion', titulo: /Preparación de fiestas/ },
  122 | ];
  123 | 
  124 | for (const { ruta, titulo } of TORRE) {
  125 |   test(`${ruta} muestra su contenido real y sin errores de página`, async ({ page }) => {
  126 |     test.setTimeout(120_000);
  127 |     const erroresJs: string[] = [];
  128 |     page.on('pageerror', (e) => erroresJs.push(e.message));
  129 |     await page.goto(ruta, { waitUntil: 'domcontentloaded' });
  130 |     await expect(page.getByRole('heading', { name: titulo })).toBeVisible({ timeout: 60_000 });
  131 |     await page.waitForLoadState('networkidle', { timeout: 20_000 }).catch(() => {});
  132 |     expect(page.url()).toContain(ruta);
  133 |     expect(erroresJs).toEqual([]);
  134 |   });
  135 | }
  136 | 
  137 | async function cortarLecturas(page: Page) {
  138 |   // La primera acción es la del portero (AuthGuard): se deja pasar; se cortan las demás.
  139 |   let idDelPortero: string | null = null;
  140 |   await page.route('**/*', async (r) => {
  141 |     const req = r.request();
  142 |     const id = req.method() === 'POST' ? req.headers()['next-action'] : undefined;
  143 |     if (id) {
  144 |       if (idDelPortero === null) idDelPortero = id;
  145 |       if (id !== idDelPortero) {
  146 |         await r.abort('internetdisconnected');
  147 |         return;
  148 |       }
  149 |     }
  150 |     await r.continue();
  151 |   });
  152 | }
  153 | 
  154 | test('/control-tower/comercial con la lectura caída avisa y NO dice "Todo tranquilo"', async ({ page }) => {
  155 |   test.setTimeout(120_000);
  156 |   await cortarLecturas(page);
  157 |   await page.goto('/control-tower/comercial', { waitUntil: 'domcontentloaded' });
  158 |   await expect(page.getByRole('heading', { name: /Seguimientos comerciales/ })).toBeVisible({ timeout: 60_000 });
  159 |   await expect(page.getByRole('alert').first()).toBeVisible({ timeout: 30_000 });
  160 |   await page.waitForTimeout(3_000);
  161 |   await expect(page.getByText(/Todo tranquilo/)).toHaveCount(0);
  162 | });
  163 | 
```