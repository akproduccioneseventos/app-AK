# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: ak207-90-lo-que-va-atras-dice-donde-quedo.spec.ts >> Orden 90 — Bloque 2: la pantalla dice la verdad según dónde quedó la captura >> Fotocabina con subida rechazada: muestra el error y NO dice que se sube sola
- Location: tests\e2e\ak207-90-lo-que-va-atras-dice-donde-quedo.spec.ts:134:7

# Error details

```
Error: expect(locator).toBeVisible() failed

Locator: getByRole('button', { name: /publicar en el muro/i })
Expected: visible
Timeout: 25000ms
Error: element(s) not found

Call log:
  - Expect "toBeVisible" with timeout 25000ms
  - waiting for getByRole('button', { name: /publicar en el muro/i })

```

```yaml
- button "Volver":
  - img
- heading "Fotocabina AK" [level=1]
- paragraph: Fiesta de esta noche
- paragraph: Foto 3 de 3
- paragraph: "Última: la mejor sonrisa."
- button "Cambiar de estación":
  - img
- region "Notifications (F8)":
  - list
- alert
```

# Test source

```ts
  62  | 
  63  | (fiesta as any).others.entretenimiento.modules.plataforma360 = {
  64  |   countdownSeconds: 2,
  65  |   recordingDurationSeconds: 2,
  66  | };
  67  | 
  68  | test.beforeAll(() => guardarFiesta(fiesta));
  69  | test.afterAll(() => borrarFiesta(fiesta.id));
  70  | 
  71  | async function esperarCamaraLista(page: any) {
  72  |   for (let intento = 0; intento < 15; intento++) {
  73  |     const hayCamara = await page.evaluate(() => {
  74  |       const v = document.querySelector('video');
  75  |       return Boolean(v && (v as HTMLVideoElement).srcObject);
  76  |     });
  77  |     if (hayCamara) {
  78  |       await page.waitForTimeout(500);
  79  |       return;
  80  |     }
  81  |     await page.waitForTimeout(1_000);
  82  |   }
  83  | }
  84  | 
  85  | function simularRechazoAction(texto: string, mensajeError: string) {
  86  |   let resultado = texto;
  87  |   if (resultado.includes('"error"')) {
  88  |     resultado = resultado.replace(/"error"\s*:\s*"[^"]*"/g, `"error":"${mensajeError}"`);
  89  |   } else {
  90  |     resultado = resultado.replace(/"success"\s*:\s*(true|false)/, `"success":false,"error":"${mensajeError}"`);
  91  |   }
  92  |   return resultado.replace(/"success"\s*:\s*true/g, '"success":false');
  93  | }
  94  | 
  95  | test.describe('Orden 90 — Bloque 2: la pantalla dice la verdad según dónde quedó la captura', () => {
  96  |   test('Fotocabina con corte de red: dice guardada en el equipo y NUNCA subida ni galería', async ({ context, page }, testInfo) => {
  97  |     test.setTimeout(90_000);
  98  |     const baseURL = testInfo.project.use.baseURL as string;
  99  |     await ponerSesionDelEquipo(context, baseURL);
  100 |     await enchufarCamaraFalsa(page);
  101 | 
  102 |     await page.route('**/evento/fotocabina/**', async (route) => {
  103 |       const req = route.request();
  104 |       const contentType = req.headers()['content-type'] || '';
  105 |       if (req.method() === 'POST' && contentType.includes('multipart/form-data')) {
  106 |         await route.abort('internetdisconnected');
  107 |         return;
  108 |       }
  109 |       await route.continue();
  110 |     });
  111 | 
  112 |     const permiso = crearPermisoDeEstacion(fiesta.id, 'fotocabina');
  113 |     await page.goto(`/evento/fotocabina/${fiesta.id}?access=${permiso}`, { waitUntil: 'domcontentloaded' });
  114 |     await esperarCamaraLista(page);
  115 | 
  116 |     const btnCaptura = page.locator('[data-testid="boton-sacar-foto"]').or(page.getByRole('button', { name: /preparar foto|sacar/i })).first();
  117 |     await expect(btnCaptura).toBeVisible({ timeout: 25_000 });
  118 |     await btnCaptura.click();
  119 | 
  120 |     // Esperar a que pase la captura y aparezca la vista previa con el botón para publicar
  121 |     const btnPublicar = page.getByRole('button', { name: /publicar en el muro/i });
  122 |     await expect(btnPublicar).toBeVisible({ timeout: 25_000 });
  123 |     await btnPublicar.click();
  124 | 
  125 |     // Debe mostrar que quedó guardada en el equipo
  126 |     const avisoEquipo = page.getByText(/guardada en este equipo|quedó guardada/i).first();
  127 |     await expect(avisoEquipo).toBeVisible({ timeout: 35_000 });
  128 | 
  129 |     // Y NUNCA debe decir "subida" ni "en la galería"
  130 |     const textoPagina = (await page.locator('body').innerText()).toLowerCase();
  131 |     expect(textoPagina).not.toMatch(/ya se subió|ya está subida|en la galería de la fiesta|tu recuerdo esta listo/i);
  132 |   });
  133 | 
  134 |   test('Fotocabina con subida rechazada: muestra el error y NO dice que se sube sola', async ({ context, page }, testInfo) => {
  135 |     test.setTimeout(90_000);
  136 |     const baseURL = testInfo.project.use.baseURL as string;
  137 |     await ponerSesionDelEquipo(context, baseURL);
  138 |     await enchufarCamaraFalsa(page);
  139 | 
  140 |     await page.route('**/evento/fotocabina/**', async (route) => {
  141 |       const req = route.request();
  142 |       const contentType = req.headers()['content-type'] || '';
  143 |       if (req.method() === 'POST' && contentType.includes('multipart/form-data')) {
  144 |         const respuesta = await route.fetch();
  145 |         const texto = await respuesta.text();
  146 |         const nuevoTexto = simularRechazoAction(texto, 'Contenido inapropiado');
  147 |         await route.fulfill({ response: respuesta, body: nuevoTexto });
  148 |         return;
  149 |       }
  150 |       await route.continue();
  151 |     });
  152 | 
  153 |     const permiso = crearPermisoDeEstacion(fiesta.id, 'fotocabina');
  154 |     await page.goto(`/evento/fotocabina/${fiesta.id}?access=${permiso}`, { waitUntil: 'domcontentloaded' });
  155 |     await esperarCamaraLista(page);
  156 | 
  157 |     const btnCaptura = page.locator('[data-testid="boton-sacar-foto"]').or(page.getByRole('button', { name: /preparar foto|sacar/i })).first();
  158 |     await expect(btnCaptura).toBeVisible({ timeout: 25_000 });
  159 |     await btnCaptura.click();
  160 | 
  161 |     const btnPublicar = page.getByRole('button', { name: /publicar en el muro/i });
> 162 |     await expect(btnPublicar).toBeVisible({ timeout: 25_000 });
      |                               ^ Error: expect(locator).toBeVisible() failed
  163 |     await btnPublicar.click();
  164 | 
  165 |     // Debe informar el error de rechazo
  166 |     const avisoError = page.getByText(/no se pudo publicar|contenido inapropiado/i).first();
  167 |     await expect(avisoError).toBeVisible({ timeout: 35_000 });
  168 | 
  169 |     // Y NO debe decir que se sube sola ni que quedó guardada
  170 |     const textoPagina = (await page.locator('body').innerText()).toLowerCase();
  171 |     expect(textoPagina).not.toMatch(/se sube sola|se subirá cuando vuelva la señal|guardada en este equipo/i);
  172 |   });
  173 | 
  174 |   test('Plataforma 360 con corte de red: dice guardado en el equipo y NUNCA subido ni galería', async ({ context, page }, testInfo) => {
  175 |     test.setTimeout(90_000);
  176 |     const baseURL = testInfo.project.use.baseURL as string;
  177 |     await ponerSesionDelEquipo(context, baseURL);
  178 |     await enchufarCamaraFalsa(page);
  179 | 
  180 |     await page.route('**/evento/plataforma-360/**', async (route) => {
  181 |       const req = route.request();
  182 |       const contentType = req.headers()['content-type'] || '';
  183 |       if (req.method() === 'POST' && contentType.includes('multipart/form-data')) {
  184 |         await route.abort('internetdisconnected');
  185 |         return;
  186 |       }
  187 |       await route.continue();
  188 |     });
  189 | 
  190 |     const permiso = crearPermisoDeEstacion(fiesta.id, 'plataforma360');
  191 |     await page.goto(`/evento/plataforma-360/${fiesta.id}?access=${permiso}`, { waitUntil: 'domcontentloaded' });
  192 | 
  193 |     const btnGrabar = page.getByRole('button', { name: /grabar video/i }).first();
  194 |     await expect(btnGrabar).toBeVisible({ timeout: 20_000 });
  195 |     await btnGrabar.click();
  196 | 
  197 |     // Debe mostrar que quedó guardado en el equipo
  198 |     const avisoEquipo = page.getByText(/video guardado en este equipo|quedó guardado/i).first();
  199 |     await expect(avisoEquipo).toBeVisible({ timeout: 45_000 });
  200 | 
  201 |     // Y NUNCA debe decir subido ni en la galería
  202 |     const textoPagina = (await page.locator('body').innerText()).toLowerCase();
  203 |     expect(textoPagina).not.toMatch(/tu video ya está subido|en la galería/i);
  204 |   });
  205 | 
  206 |   test('Plataforma 360 con subida rechazada: muestra el error y NO dice que se sube sola', async ({ context, page }, testInfo) => {
  207 |     test.setTimeout(90_000);
  208 |     const baseURL = testInfo.project.use.baseURL as string;
  209 |     await ponerSesionDelEquipo(context, baseURL);
  210 |     await enchufarCamaraFalsa(page);
  211 | 
  212 |     await page.route('**/evento/plataforma-360/**', async (route) => {
  213 |       const req = route.request();
  214 |       const contentType = req.headers()['content-type'] || '';
  215 |       if (req.method() === 'POST' && contentType.includes('multipart/form-data')) {
  216 |         const respuesta = await route.fetch();
  217 |         const texto = await respuesta.text();
  218 |         const nuevoTexto = simularRechazoAction(texto, 'Contenido inapropiado');
  219 |         await route.fulfill({ response: respuesta, body: nuevoTexto });
  220 |         return;
  221 |       }
  222 |       await route.continue();
  223 |     });
  224 | 
  225 |     const permiso = crearPermisoDeEstacion(fiesta.id, 'plataforma360');
  226 |     await page.goto(`/evento/plataforma-360/${fiesta.id}?access=${permiso}`, { waitUntil: 'domcontentloaded' });
  227 | 
  228 |     const btnGrabar = page.getByRole('button', { name: /grabar video/i }).first();
  229 |     await expect(btnGrabar).toBeVisible({ timeout: 20_000 });
  230 |     await btnGrabar.click();
  231 | 
  232 |     // Debe mostrar el rechazo
  233 |     const avisoError = page.getByText(/contenido inapropiado|no se pudo publicar/i).first();
  234 |     await expect(avisoError).toBeVisible({ timeout: 45_000 });
  235 | 
  236 |     // Y NO debe decir que se sube sola ni que quedó guardado en esta pantalla
  237 |     const textoPagina = (await page.locator('body').innerText()).toLowerCase();
  238 |     expect(textoPagina).not.toMatch(/se sube sola|se subirá cuando vuelva la señal|quedó guardado en esta pantalla/i);
  239 |   });
  240 | });
  241 | 
```