# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: ak207-prospecto-simulador.spec.ts >> recorrido del prospecto >> llega desde el simulador hasta ver un precio
- Location: tests\e2e\ak207-prospecto-simulador.spec.ts:56:7

# Error details

```
Error: El prospecto llegó al final pero no tiene cómo cerrar

expect(locator).toBeVisible() failed

Locator: getByRole('button', { name: /WhatsApp|Generar presupuesto/i }).first()
Expected: visible
Timeout: 20000ms
Error: element(s) not found

Call log:
  - El prospecto llegó al final pero no tiene cómo cerrar with timeout 20000ms
  - waiting for getByRole('button', { name: /WhatsApp|Generar presupuesto/i }).first()

```

```yaml
- img "AK Producciones"
- text: Armá tu presupuesto Paso 5 de 5 · Edición
- progressbar
- heading "Personalización de tu presupuesto" [level=2]
- paragraph: ¡Llegamos a la etapa final! Ajustá la fecha y los invitados, quitá opcionales de tu paquete o agregá extras a tu gusto. El total se recalcula al instante.
- heading "Información General del Evento" [level=3]:
  - img
  - text: Información General del Evento
- text: Fecha del evento
- button "15 de noviembre de 2026":
  - img
  - text: 15 de noviembre de 2026
- text: Invitados Adultos
- spinbutton: "80"
- text: Niños y Adolescentes
- spinbutton
- heading "Servicios contratados en tu propuesta" [level=3]:
  - img
  - text: Servicios contratados en tu propuesta
- img
- text: Personal 2 activos Mozo Personal • $ 11.960
- button "Retirar servicio":
  - img
- text: Mozo de cocina Personal • $ 11.960
- button "Retirar servicio":
  - img
- img
- text: Servicio de bebidas 1 activos Barra de tragos Servicio de bebidas • $ 31.920
- button "Retirar servicio":
  - img
- img
- text: Servicio de comida 3 activos Mantelería completa Servicio de comida • $ 6.320
- button "Retirar servicio":
  - img
- text: Mobiliario completo Servicio de comida • $ 6.000
- button "Retirar servicio":
  - img
- text: Vajilla Completa Servicio de comida • $ 6.320
- button "Retirar servicio":
  - img
- img
- text: Servicio de decoración 2 activos Cuadro de firmas Servicio de decoración • $ 2.990
- button "Retirar servicio":
  - img
- text: Servicio de Decoración Servicio de decoración • $ 14.990
- button "Retirar servicio":
  - img
- img
- text: Servicio de discoteca 1 activos Servicio de Discoteca Servicio de discoteca • $ 14.900
- button "Retirar servicio":
  - img
- img
- text: Servicio de entretenimiento 1 activos Fotocabina Servicio de entretenimiento • $ 2.990
- button "Retirar servicio":
  - img
- img
- text: Servicio de fotografía 2 activos Fotografía de exteriores Servicio de fotografía • $ 3.990
- button "Retirar servicio":
  - img
- text: Fotografía de la fiesta Servicio de fotografía • $ 9.990
- button "Retirar servicio":
  - img
- img
- text: Servicio de repostería 2 activos Mesa dulce con fuente de chocolate Servicio de repostería • $ 9.520
- button "Retirar servicio":
  - img
- text: Torta Principal Servicio de repostería • $ 8.720
- button "Retirar servicio":
  - img
- img
- text: Regalos Incluidos 6 activos Invitaciones digitales Regalo incluido Organizamos de la fiesta Regalo incluido Mesa de café Regalo incluido Album digital Regalo incluido Video de vida Regalo incluido Pantalla gigante y proyector Regalo incluido
- heading "Personalizá tu fiesta con más servicios" [level=4]:
  - img
  - text: Personalizá tu fiesta con más servicios
- img
- heading "🔥 ¡Subí tu evento al Plan Paquete premium!" [level=4]
- paragraph: "Llevá tu fiesta al siguiente nivel. Agregá estos servicios clave incluidos en el paquete Paquete premium y asegurá una experiencia inolvidable para todos tus invitados:"
- button "⚡ Pasarme al Plan Paquete premium"
- text: Refrescos +$ 11.600
- button "Sumar +"
- text: Banner Gigantografía +$ 2.990
- button "Sumar +"
- text: Candy Bar Temático +$ 8.800
- button "Sumar +"
- text: Lluvia de burbujas +$ 1.500
- button "Sumar +"
- text: Fuegos fríos (2 disparos) +$ 3.000
- button "Sumar +"
- text: Filmación de la fiesta +$ 9.990
- button "Sumar +"
- img
- 'textbox "Buscá servicios adicionales por nombre (ej: cabina, plataforma, barra, cascada)..."'
- heading "¿Querés comparar con otros paquetes?" [level=4]
- text: Alternativa
- heading "Paquete basico" [level=5]
- paragraph: $ 64.821
- paragraph: "- $ 705 por persona"
- button "Cambiar a Paquete basico"
- text: Alternativa
- heading "Paquete premium" [level=5]
- paragraph: $ 149.557
- paragraph: + $ 355 por persona
- button "Cambiar a Paquete premium"
- strong: Precios 2026
- text: — El total mostrado corresponde al precio vigente.
- button "Ver Preguntas Frecuentes (FAQ)":
  - img
  - text: Ver Preguntas Frecuentes (FAQ)
- button "Anterior"
- text: 🎁 ¡Ahorrás $ 22.900 en regalos incluidos!
- button "Ver Resumen y Propuesta"
- paragraph: "Total vigente:"
- paragraph: $ 121.184
- paragraph: $ 1.515 p/p
- region "Notifications (F8)":
  - list
- alert
```

# Test source

```ts
  38  |  *
  39  |  * La prueba llega hasta ver el precio, y **no** genera el presupuesto: ese paso
  40  |  * crea un prospecto de verdad y ensuciaría los datos del negocio con gente que
  41  |  * no existe.
  42  |  */
  43  | 
  44  | const NOMBRE = 'Prospecto de prueba';
  45  | 
  46  | // El simulador registra el avance paso a paso, así que el recorrido crea un
  47  | // prospecto de verdad. Se borra al terminar: el CRM es del negocio, no de las
  48  | // pruebas.
  49  | test.afterAll(() => {
  50  |   borrarProspectosDePrueba();
  51  |   borrarPresupuestosDePrueba();
  52  | });
  53  | const TELEFONO = '099 123 456';
  54  | 
  55  | test.describe('recorrido del prospecto', () => {
  56  |   test('llega desde el simulador hasta ver un precio', async ({ page }) => {
  57  |     test.setTimeout(300_000);
  58  | 
  59  |     const erroresJs: string[] = [];
  60  |     page.on('pageerror', (e) => erroresJs.push(e.message));
  61  | 
  62  |     await page.goto('/simulador-de-presupuesto', { waitUntil: 'domcontentloaded' });
  63  | 
  64  |     // Paso 1: la portada. Se busca por el texto que ve una persona, no por una
  65  |     // marca interna: si el botón cambia de nombre, la prueba tiene que avisar.
  66  |     const empezar = page.getByRole('button', { name: /Comenzar mi presupuesto|Cotizar/i }).first();
  67  |     await expect(empezar, 'No aparece el botón para empezar a cotizar').toBeVisible({ timeout: 45_000 });
  68  |     await empezar.click();
  69  | 
  70  |     // La portada del simulador tiene su propio botón para arrancar el paso a paso.
  71  |     const arrancar = page.getByRole('button', { name: /Cotizar mi fiesta/i }).first();
  72  |     await expect(arrancar, 'No aparece el botón que arranca el paso a paso').toBeVisible({ timeout: 45_000 });
  73  |     await arrancar.click();
  74  | 
  75  |     // Paso 2: sus datos.
  76  |     await expect(page.locator('#simulator-name')).toBeVisible({ timeout: 45_000 });
  77  |     await page.locator('#simulator-name').fill(NOMBRE);
  78  |     await page.locator('#simulator-phone').fill(TELEFONO);
  79  | 
  80  |     // Duración y salón: dos decisiones que cambian el precio.
  81  |     await page.getByText('Mas de 4 horas').first().click();
  82  |     await page.getByText('Tengo salón o locación propia').first().click();
  83  | 
  84  |     // Cantidad de gente.
  85  |     const adultos = page.locator('input[type="number"]').first();
  86  |     await adultos.fill('80');
  87  | 
  88  |     // La fecha: se abre el calendario y se toma un día disponible del mes que viene.
  89  |     const calendario = page.getByRole('button', { name: /fecha|Elegí|Seleccion/i }).first();
  90  |     if (await calendario.isVisible().catch(() => false)) {
  91  |       await calendario.click();
  92  |       const siguiente = page.getByRole('button', { name: /next month|mes siguiente/i }).first();
  93  |       if (await siguiente.isVisible().catch(() => false)) await siguiente.click();
  94  |       // react-day-picker 9: el dia es un boton dentro de la grilla, con nombre
  95  |       // accesible largo ("viernes, 15 de ..."), no una celda llamada "15".
  96  |       const dia = page.getByRole('grid').getByRole('button', { name: /\b15\b/, disabled: false }).first();
  97  |       if (await dia.isVisible().catch(() => false)) await dia.click();
  98  |     }
  99  | 
  100 |     // Avanzar hasta el final del recorrido. Cada "Continuar" tiene que llevar a
  101 |     // algún lado: si uno se traba, la venta se corta ahí.
  102 |     for (let paso = 0; paso < 4; paso += 1) {
  103 |       const continuar = page.getByRole('button', { name: 'Continuar' }).first();
  104 |       if (!(await continuar.isVisible().catch(() => false))) break;
  105 |       await expect(continuar, `El botón "Continuar" quedó bloqueado en el paso ${paso + 2}`).toBeEnabled({ timeout: 20_000 });
  106 |       await continuar.click();
  107 |       await page.waitForTimeout(2500);
  108 |     }
  109 | 
  110 |     // Sobre el final aparece el cartel que ofrece subir de paquete. Es parte de
  111 |     // la venta: una persona lo lee y decide. Acá se elige quedarse con lo que
  112 |     // venía armando, que es lo que hace la mayoría.
  113 |     const mantener = page.getByRole('button', { name: /Mantener mi selección actual/i }).first();
  114 |     if (await mantener.isVisible().catch(() => false)) {
  115 |       await mantener.click();
  116 |       await page.waitForTimeout(1500);
  117 |     }
  118 | 
  119 |     // Lo que importa: el prospecto tiene que ver un precio, no un cero ni un
  120 |     // texto roto.
  121 |     const textoFinal = await page.locator('body').innerText();
  122 |     const montos = textoFinal.match(/\$\s?[\d.]{4,}/g) ?? [];
  123 |     expect(montos.length, `No apareció ningún precio en el recorrido:\n${textoFinal.slice(0, 400)}`).toBeGreaterThan(0);
  124 |     expect(textoFinal).not.toMatch(/NaN|Infinity|\[object Object\]/);
  125 | 
  126 |     // El último paso no dice "Continuar" sino "Ver Resumen y Propuesta": ahí es
  127 |     // donde aparece la propuesta con el precio congelado y el botón para
  128 |     // escribirle a AK. Sin este clic, el recorrido se cortaba una pantalla antes.
  129 |     const verResumen = page.getByRole('button', { name: /Ver Resumen y Propuesta/i }).first();
  130 |     if (await verResumen.isVisible().catch(() => false)) {
  131 |       await expect(verResumen, 'El botón que abre la propuesta final quedó bloqueado').toBeEnabled({ timeout: 20_000 });
  132 |       await verResumen.click();
  133 |       await page.waitForTimeout(2500);
  134 |     }
  135 | 
  136 |     // Y tiene que poder cerrar: o generar el presupuesto o escribirle a AK.
  137 |     const cierre = page.getByRole('button', { name: /WhatsApp|Generar presupuesto/i }).first();
> 138 |     await expect(cierre, 'El prospecto llegó al final pero no tiene cómo cerrar').toBeVisible({ timeout: 20_000 });
      |                                                                                   ^ Error: El prospecto llegó al final pero no tiene cómo cerrar
  139 | 
  140 |     expect(erroresJs, `El simulador tuvo fallas de JavaScript:\n${erroresJs.join('\n')}`).toEqual([]);
  141 |   });
  142 | 
  143 |   test('el catálogo lleva al simulador con el tipo de fiesta elegido', async ({ page }) => {
  144 |     test.setTimeout(180_000);
  145 | 
  146 |     // Es lo que se hace sentado con el cliente: se le muestra el catálogo y de
  147 |     // ahí se pasa a cotizar.
  148 |     await page.goto('/catalogo/bodas', { waitUntil: 'domcontentloaded' });
  149 |     await expect(page.getByRole('button', { name: /Siguiente/i }).first()).toBeVisible({ timeout: 45_000 });
  150 | 
  151 |     const textoCatalogo = await page.locator('body').innerText();
  152 |     expect(textoCatalogo).not.toMatch(/NaN|Infinity|\[object Object\]/);
  153 |     expect(textoCatalogo.length, 'El catálogo quedó vacío').toBeGreaterThan(200);
  154 |   });
  155 | });
  156 | 
```