# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: ak207-layout-baseline.spec.ts >> huella de maquetación >> las pantallas de referencia mantienen su geometría
- Location: tests\e2e\ak207-layout-baseline.spec.ts:128:7

# Error details

```
Error: La maquetación cambió:
  /admin · colores: era 2034977308, ahora 1190975077
  /presupuestos/nuevo · h1W: era 212, ahora 216
  /presupuestos/nuevo · colores: era 2034977308, ahora 1190975077

expect(received).toEqual(expected) // deep equality

- Expected  - 1
+ Received  + 5

- Array []
+ Array [
+   "/admin · colores: era 2034977308, ahora 1190975077",
+   "/presupuestos/nuevo · h1W: era 212, ahora 216",
+   "/presupuestos/nuevo · colores: era 2034977308, ahora 1190975077",
+ ]
```

# Page snapshot

```yaml
- generic [active] [ref=e1]:
  - generic [ref=e2]:
    - generic [ref=e6]:
      - link "Logo de la Empresa" [ref=e8] [cursor=pointer]:
        - /url: /admin
        - img "Logo de la Empresa" [ref=e10]
      - generic [ref=e11]:
        - list [ref=e12]:
          - listitem [ref=e13]:
            - link "Centro de Control" [ref=e14] [cursor=pointer]:
              - /url: /admin
              - img [ref=e15]
              - generic [ref=e20]: Centro de Control
        - generic [ref=e21]:
          - generic [ref=e22]:
            - generic [ref=e23]: Mi Día
            - generic [ref=e24]: ☀️
          - list [ref=e26]:
            - listitem [ref=e27]:
              - link "Mi Día" [ref=e28] [cursor=pointer]:
                - /url: /mi-dia
                - img [ref=e29]
                - generic [ref=e35]: Mi Día
        - generic [ref=e36]:
          - generic [ref=e37]:
            - generic [ref=e38]: Fiestas
            - generic [ref=e39]: 🎉
          - list [ref=e41]:
            - listitem [ref=e42]:
              - link "Eventos Activos" [ref=e43] [cursor=pointer]:
                - /url: /eventos
                - img [ref=e44]
                - generic [ref=e50]: Eventos Activos
            - listitem [ref=e51]:
              - link "Calendario" [ref=e52] [cursor=pointer]:
                - /url: /calendario
                - img [ref=e53]
                - generic [ref=e55]: Calendario
            - listitem [ref=e56]:
              - link "Muro Social" [ref=e57] [cursor=pointer]:
                - /url: /empresa/red-social-eventos
                - img [ref=e58]
                - generic [ref=e61]: Muro Social
            - listitem [ref=e62]:
              - link "Incidentes" [ref=e63] [cursor=pointer]:
                - /url: /incidentes
                - img [ref=e64]
                - generic [ref=e66]: Incidentes
            - listitem [ref=e67]:
              - link "Guias de Armado" [ref=e68] [cursor=pointer]:
                - /url: /playbooks
                - img [ref=e69]
                - generic [ref=e72]: Guias de Armado
            - listitem [ref=e73]:
              - link "Alergias y Dietas" [ref=e74] [cursor=pointer]:
                - /url: /fiestas/nueva/alergias
                - img [ref=e75]
                - generic [ref=e84]: Alergias y Dietas
            - listitem [ref=e85]:
              - link "Portal de Proveedores" [ref=e86] [cursor=pointer]:
                - /url: /fiestas/nueva/proveedores-portal
                - img [ref=e87]
                - generic [ref=e92]: Portal de Proveedores
            - listitem [ref=e93]:
              - link "Personal en dos fiestas" [ref=e94] [cursor=pointer]:
                - /url: /recursos-multi-evento
                - img [ref=e95]
                - generic [ref=e99]: Personal en dos fiestas
        - generic [ref=e100]:
          - generic [ref=e101]:
            - generic [ref=e102]: La Empresa
            - generic [ref=e103]: 🏢
          - list [ref=e105]:
            - listitem [ref=e106]:
              - link "Gestión de Empresa" [ref=e107] [cursor=pointer]:
                - /url: /empresa
                - img [ref=e108]
                - generic [ref=e112]: Gestión de Empresa
            - generic [ref=e115]: Vender
            - listitem [ref=e116]:
              - link "Prospectos" [ref=e117] [cursor=pointer]:
                - /url: /contabilidad/crm
                - img [ref=e118]
                - generic [ref=e120]: Prospectos
            - listitem [ref=e121]:
              - link "Presupuestos" [ref=e122] [cursor=pointer]:
                - /url: /presupuestos/nuevo
                - img [ref=e123]
                - generic [ref=e126]: Presupuestos
            - listitem [ref=e127]:
              - link "Clientes" [ref=e128] [cursor=pointer]:
                - /url: /customers
                - img [ref=e129]
                - generic [ref=e134]: Clientes
            - listitem [ref=e135]:
              - link "Simulador IA" [ref=e136] [cursor=pointer]:
                - /url: /simulador-ak
                - img [ref=e137]
                - generic [ref=e140]: Simulador IA
            - generic [ref=e143]: Plata
            - listitem [ref=e144]:
              - link "Pagos Rápidos" [ref=e145] [cursor=pointer]:
                - /url: /pagos-rapidos
                - img [ref=e146]
                - generic [ref=e149]: Pagos Rápidos
            - listitem [ref=e150]:
              - link "Panel Contable" [ref=e151] [cursor=pointer]:
                - /url: /empresa/contabilidad
                - img [ref=e152]
                - generic [ref=e154]: Panel Contable
            - listitem [ref=e155]:
              - link "Facturas" [ref=e156] [cursor=pointer]:
                - /url: /invoices
                - img [ref=e157]
                - generic [ref=e160]: Facturas
            - listitem [ref=e161]:
              - link "Cambios a Aprobar" [ref=e162] [cursor=pointer]:
                - /url: /aprobaciones
                - img [ref=e163]
                - generic [ref=e166]: Cambios a Aprobar
            - listitem [ref=e167]:
              - link "Métricas del Negocio" [ref=e168] [cursor=pointer]:
                - /url: /empresa/dashboard
                - img [ref=e169]
                - generic [ref=e172]: Métricas del Negocio
            - generic [ref=e175]: Recursos
            - listitem [ref=e176]:
              - link "Comida / Menús" [ref=e177] [cursor=pointer]:
                - /url: /empresa/menus
                - img [ref=e178]
                - generic [ref=e180]: Comida / Menús
            - listitem [ref=e181]:
              - link "Lista de Compras" [ref=e182] [cursor=pointer]:
                - /url: /compras
                - img [ref=e183]
                - generic [ref=e187]: Lista de Compras
            - listitem [ref=e188]:
              - link "Salones" [ref=e189] [cursor=pointer]:
                - /url: /empresa/salones
                - img [ref=e190]
                - generic [ref=e193]: Salones
            - listitem [ref=e194]:
              - link "Catálogo de Servicios" [ref=e195] [cursor=pointer]:
                - /url: /empresa/servicios
                - img [ref=e196]
                - generic [ref=e200]: Catálogo de Servicios
            - listitem [ref=e201]:
              - link "Proveedores" [ref=e202] [cursor=pointer]:
                - /url: /proveedores
                - img [ref=e203]
                - generic [ref=e207]: Proveedores
            - listitem [ref=e208]:
              - link "Empleados" [ref=e209] [cursor=pointer]:
                - /url: /empleados
                - img [ref=e210]
                - generic [ref=e213]: Empleados
            - generic [ref=e216]: Marketing
            - listitem [ref=e217]:
              - link "Marketing y Redes" [ref=e218] [cursor=pointer]:
                - /url: /marketing
                - img [ref=e219]
                - generic [ref=e223]: Marketing y Redes
            - listitem [ref=e224]:
              - link "WhatsApp del Día" [ref=e225] [cursor=pointer]:
                - /url: /contabilidad/crm/outbox
                - img [ref=e226]
                - generic [ref=e229]: WhatsApp del Día
            - listitem [ref=e230]:
              - link "Presentación LED" [ref=e231] [cursor=pointer]:
                - /url: /empresa/presentacion-led/configuracion
                - img [ref=e232]
                - generic [ref=e235]: Presentación LED
        - generic [ref=e236]:
          - generic [ref=e237]:
            - generic [ref=e238]: Configuración
            - generic [ref=e239]: ⚙️
          - list [ref=e241]:
            - listitem [ref=e242]:
              - link "Ajustes Generales" [ref=e243] [cursor=pointer]:
                - /url: /settings
                - img [ref=e244]
                - generic [ref=e247]: Ajustes Generales
            - listitem [ref=e248]:
              - link "Tareas Automáticas" [ref=e249] [cursor=pointer]:
                - /url: /settings/tareas-automaticas
                - img [ref=e250]
                - generic [ref=e252]: Tareas Automáticas
            - listitem [ref=e253]:
              - link "Conexiones" [ref=e254] [cursor=pointer]:
                - /url: /settings/sincronizaciones
                - img [ref=e255]
                - generic [ref=e258]: Conexiones
            - listitem [ref=e259]:
              - link "WhatsApp" [ref=e260] [cursor=pointer]:
                - /url: /settings/whatsapp
                - img [ref=e261]
                - generic [ref=e263]: WhatsApp
            - listitem [ref=e264]:
              - link "Cláusulas de Contrato" [ref=e265] [cursor=pointer]:
                - /url: /settings/contratos/clausulas
                - img [ref=e266]
                - generic [ref=e270]: Cláusulas de Contrato
            - listitem [ref=e271]:
              - link "Seguridad" [ref=e272] [cursor=pointer]:
                - /url: /settings/account
                - img [ref=e273]
                - generic [ref=e276]: Seguridad
            - listitem [ref=e277]:
              - link "Promociones" [ref=e278] [cursor=pointer]:
                - /url: /settings/promos
                - img [ref=e279]
                - generic [ref=e282]: Promociones
            - listitem [ref=e283]:
              - link "Asistente IA" [ref=e284] [cursor=pointer]:
                - /url: /settings/ai-assistant
                - img [ref=e285]
                - generic [ref=e288]: Asistente IA
            - listitem [ref=e289]:
              - link "Mapa Tecnológico" [ref=e290] [cursor=pointer]:
                - /url: /settings/mapa-tecnologico-ak
                - img [ref=e291]
                - generic [ref=e294]: Mapa Tecnológico
            - listitem [ref=e295]:
              - link "Laboratorio Experimental" [ref=e296] [cursor=pointer]:
                - /url: /settings/feature-flags
                - img [ref=e297]
                - generic [ref=e300]: Laboratorio Experimental
      - list [ref=e302]:
        - listitem [ref=e303]:
          - link "Alertas" [ref=e304] [cursor=pointer]:
            - /url: /alertas
            - img [ref=e305]
            - generic [ref=e308]: Alertas
    - main [ref=e309]:
      - generic [ref=e310]:
        - generic [ref=e311]:
          - generic [ref=e312]:
            - img [ref=e314]
            - heading "Central de Presupuestos" [level=1] [ref=e317]
          - generic [ref=e318]:
            - link "Ingreso/Egreso Rápido" [ref=e319] [cursor=pointer]:
              - /url: /pagos-rapidos
              - button "Ingreso/Egreso Rápido" [ref=e320]:
                - img
                - generic [ref=e321]: Ingreso/Egreso Rápido
            - button "Abrir notificaciones" [ref=e322] [cursor=pointer]:
              - img
              - generic [ref=e323]: Abrir notificaciones
            - button "Logo de la Empresa" [ref=e324] [cursor=pointer]:
              - img "Logo de la Empresa" [ref=e326]
        - main [ref=e327]:
          - generic [ref=e328]:
            - generic [ref=e329]:
              - heading "Central de Presupuestos" [level=1] [ref=e330]:
                - img [ref=e331]
                - text: Central de Presupuestos
              - generic [ref=e334]:
                - link "Configurador para la reunión" [ref=e335] [cursor=pointer]:
                  - /url: /empresa/configurador-reunion
                - link "Reporte" [ref=e336] [cursor=pointer]:
                  - /url: /presupuestos/reporte
                - link "Importar desde Texto" [ref=e337] [cursor=pointer]:
                  - /url: /presupuestos/importar
                  - img
                  - text: Importar desde Texto
                - link "Nuevo Presupuesto" [ref=e338] [cursor=pointer]:
                  - /url: /presupuestos/nuevo/crear
                  - img
                  - text: Nuevo Presupuesto
                - button "🗑️ Borrar todos" [disabled]:
                  - img
                  - text: 🗑️ Borrar todos
                - link "Volver" [ref=e339] [cursor=pointer]:
                  - /url: /empresa/contabilidad
            - generic [ref=e340]:
              - generic [ref=e342]:
                - generic [ref=e344]:
                  - generic [ref=e345]: Pendientes (Enviados)
                  - img [ref=e347]
                - generic [ref=e353]: "0"
              - generic [ref=e355]:
                - generic [ref=e357]:
                  - generic [ref=e358]: Borradores
                  - img [ref=e360]
                - generic [ref=e364]: "0"
              - generic [ref=e366]:
                - generic [ref=e368]:
                  - generic [ref=e369]: Aceptados
                  - img [ref=e371]
                - generic [ref=e375]: "0"
              - generic [ref=e377]:
                - generic [ref=e379]:
                  - generic [ref=e380]: Facturados
                  - img [ref=e382]
                - generic [ref=e386]: "0"
              - generic [ref=e388]:
                - generic [ref=e390]:
                  - generic [ref=e391]: Rechazados
                  - img [ref=e393]
                - generic [ref=e398]: "0"
            - generic [ref=e399]:
              - generic [ref=e400]:
                - generic [ref=e401]:
                  - generic [ref=e402]: Presupuestos ordenados
                  - generic [ref=e403]: Separa eventos contratados de prospectos y muestra ambas fechas importantes.
                - generic [ref=e404]:
                  - combobox "Ordenar presupuestos" [ref=e405] [cursor=pointer]:
                    - generic: Orden recomendado
                    - img [ref=e406]
                  - button "Incluir archivados" [ref=e408] [cursor=pointer]
                  - generic [ref=e409]:
                    - img [ref=e410]
                    - textbox "Buscar cliente o Nº..." [ref=e413]
              - generic [ref=e415]:
                - tablist [ref=e416]:
                  - tab "Todos (0)" [selected] [ref=e417] [cursor=pointer]
                  - tab "Borrador" [ref=e418] [cursor=pointer]
                  - tab "Enviado" [ref=e419] [cursor=pointer]
                  - tab "Aceptado" [ref=e420] [cursor=pointer]
                  - tab "Facturado" [ref=e421] [cursor=pointer]
                - tabpanel "Todos (0)" [ref=e422]:
                  - generic [ref=e423]:
                    - img [ref=e424]
                    - paragraph [ref=e427]: No hay presupuestos activos.
                    - paragraph [ref=e428]: Crea uno nuevo o importa un presupuesto para iniciar el seguimiento.
    - navigation "Navegacion del modulo" [ref=e429]:
      - button "Volver" [ref=e430] [cursor=pointer]:
        - img
      - button "Ir al panel principal" [ref=e431] [cursor=pointer]:
        - img
    - button "Abrir Asistente IA AK" [ref=e432] [cursor=pointer]:
      - img [ref=e433]
  - generic [ref=e437]:
    - button "Mover el asistente" [ref=e438]:
      - img [ref=e439]
    - button "Martin Contabilidad, pagos y contratos" [ref=e446] [cursor=pointer]:
      - img [ref=e449]
      - generic [ref=e452]:
        - generic [ref=e453]: Martin
        - generic [ref=e454]: Contabilidad, pagos y contratos
    - link "Personalizar asistentes" [ref=e455] [cursor=pointer]:
      - /url: /settings/asistentes-contextuales
      - img
    - link "Ver sincronizaciones" [ref=e456] [cursor=pointer]:
      - /url: /settings/sincronizaciones
      - img
    - button "Minimizar el asistente" [ref=e457] [cursor=pointer]:
      - img
  - region "Notifications (F8)":
    - list
  - alert [ref=e458]
```

# Test source

```ts
  130 | 
  131 |     await context.addInitScript(() => {
  132 |       window.localStorage.setItem('ak_session', 'true');
  133 |       window.sessionStorage.setItem('ak_session', 'true');
  134 |     });
  135 |     await context.addCookies([
  136 |       { name: 'ak_session', value: createSessionToken(), url: baseURL!, httpOnly: true, sameSite: 'Lax' },
  137 |     ]);
  138 | 
  139 |     // La geometria depende del tamano de pantalla, asi que cada perfil de
  140 |     // Playwright (escritorio y celular) guarda su propia referencia.
  141 |     const perfil = test.info().project.name;
  142 |     const clave = (ruta: string) => `${perfil} ${ruta}`;
  143 | 
  144 |     const referencia = leerReferencia();
  145 |     const actual: Record<string, Huella> = {};
  146 |     const referenciasFaltantes: Record<string, Huella> = {};
  147 |     const desvios: string[] = [];
  148 |     /** Fallas que valen aunque la referencia diga que "siempre fue asi". */
  149 |     const absolutos: string[] = [];
  150 | 
  151 |     for (const { ruta } of RUTAS) {
  152 |       const response = await page.goto(ruta, { waitUntil: 'domcontentloaded' });
  153 |       expect(response?.status(), `${ruta} devolvio una respuesta invalida`).toBeLessThan(400);
  154 |       expect(new URL(page.url()).pathname, `${ruta} redirigio inesperadamente`).toBe(ruta);
  155 |       await page.waitForLoadState('networkidle', { timeout: 5_000 }).catch(() => {});
  156 |       if (ruta === '/presentacion-led') {
  157 |         await expect(page.getByText(/Cargando presentaci/i)).toBeHidden({ timeout: 45_000 });
  158 |       }
  159 |       // Las pantallas del panel traen datos del servidor antes de dibujar el
  160 |       // titulo. Con el servidor despertandose, 2,5 segundos no alcanzaban y la
  161 |       // prueba avisaba "la ruta no existe o no carga" con la pantalla sana.
  162 |       await page.locator('h1, main, header').first().waitFor({ state: 'visible', timeout: 60_000 }).catch(() => {});
  163 |       /**
  164 |        * ANTES DE MEDIR, ESPERAR A QUE LAS LETRAS ESTEN CARGADAS.
  165 |        *
  166 |        * **Esto dio una falsa alarma el 9 de septiembre de 2026.** La pantalla de la
  167 |        * presentacion acuso ocho pixeles de corrimiento en el titular; abierta sola,
  168 |        * estaba perfecta. Con la maquina cargada, la tipografia termina de cargar
  169 |        * DESPUES de la medicion, y el titular se acomoda unos pixeles: se estaba
  170 |        * midiendo la pagina a medio vestir.
  171 |        *
  172 |        * Esperar a las letras no afloja el control: lo hace medir lo que el usuario
  173 |        * ve de verdad, en vez de una foto sacada antes de tiempo.
  174 |        */
  175 |       await page.evaluate(() => Promise.race([(document as any).fonts?.ready,new Promise(resolve=>setTimeout(resolve,15000))])).catch(() => {});
  176 |       await page.waitForTimeout(2500);
  177 |       const huella = await medirHuella(page);
  178 |       actual[clave(ruta)] = huella;
  179 | 
  180 |       // Reglas absolutas: no dependen de la referencia. Sin esto, la referencia
  181 |       // congelaba defectos como si fueran lo normal (paso de verdad: el catalogo
  182 |       // se salia 54px en celular y la prueba lo daba por bueno porque "no habia
  183 |       // cambiado").
  184 |       if (huella.desborde > 2) {
  185 |         absolutos.push(`${ruta} · se sale ${huella.desborde}px a lo ancho`);
  186 |       }
  187 |       if (huella.h1W === -1 && huella.mainX === -1) {
  188 |         absolutos.push(`${ruta} · no tiene ni titulo ni contenido: la ruta no existe o no carga`);
  189 |       }
  190 | 
  191 |       const esperado = referencia[clave(ruta)];
  192 |       if (!esperado) {
  193 |         referenciasFaltantes[clave(ruta)] = actual[clave(ruta)];
  194 |         if (!ACTUALIZAR_REFERENCIAS_FALTANTES) desvios.push(`${ruta} · falta referencia para ${perfil}`);
  195 |         continue;
  196 |       }
  197 | 
  198 |       for (const [medida, valor] of Object.entries(actual[clave(ruta)])) {
  199 |         const antes = esperado[medida];
  200 |         if (typeof antes !== 'number') continue;
  201 |         // El desborde es exacto; las medidas geométricas admiten redondeo.
  202 |         const margen = medida === 'desborde' ? 0 : TOLERANCIA;
  203 |         if (Math.abs(valor - antes) > margen) {
  204 |           desvios.push(`${ruta} · ${medida}: era ${antes}, ahora ${valor}`);
  205 |         }
  206 |       }
  207 |     }
  208 | 
  209 |     // Si se activo la actualizacion de referencias faltantes, se persisten en disco
  210 |     if (Object.keys(referenciasFaltantes).length > 0 && ACTUALIZAR_REFERENCIAS_FALTANTES) {
  211 |       const nuevaReferencia = { ...referencia, ...referenciasFaltantes };
  212 |       fs.writeFileSync(REFERENCIA, `${JSON.stringify(nuevaReferencia, null, 2)}\n`);
  213 |       test.info().annotations.push({
  214 |         type: 'referencia',
  215 |         description: `Se agregaron ${Object.keys(referenciasFaltantes).length} referencias faltantes para ${perfil}.`,
  216 |       });
  217 |     }
  218 | 
  219 |     // Primera corrida (o referencia borrada a proposito): se genera la referencia
  220 |     // pero las reglas absolutas se exigen igual, para no grabar un defecto.
  221 |     const faltaEsteperfil = !Object.keys(referencia).some((k) => k.startsWith(`${perfil} `));
  222 |     if (Object.keys(referencia).length === 0 || faltaEsteperfil) {
  223 |       fs.writeFileSync(REFERENCIA, `${JSON.stringify({ ...referencia, ...actual }, null, 2)}\n`);
  224 |       test.info().annotations.push({ type: 'referencia', description: `Huella generada para ${perfil}.` });
  225 |       expect(absolutos, `Pantallas con defectos propios:\n  ${absolutos.join('\n  ')}`).toEqual([]);
  226 |       return;
  227 |     }
  228 | 
  229 |     expect(absolutos, `Pantallas con defectos propios:\n  ${absolutos.join('\n  ')}`).toEqual([]);
> 230 |     expect(desvios, `La maquetación cambió:\n  ${desvios.join('\n  ')}`).toEqual([]);
      |                                                                          ^ Error: La maquetación cambió:
  231 |   });
  232 | });
  233 | 
```