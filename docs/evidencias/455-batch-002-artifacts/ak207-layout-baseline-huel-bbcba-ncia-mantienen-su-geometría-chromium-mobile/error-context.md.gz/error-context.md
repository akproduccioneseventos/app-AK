# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: ak207-layout-baseline.spec.ts >> huella de maquetación >> las pantallas de referencia mantienen su geometría
- Location: tests\e2e\ak207-layout-baseline.spec.ts:128:7

# Error details

```
Error: La maquetación cambió:
  /admin · h1W: era 101, ahora 98
  /admin · colores: era 1566381053, ahora 90644102
  /presupuestos/nuevo · colores: era 1566381053, ahora 90644102

expect(received).toEqual(expected) // deep equality

- Expected  - 1
+ Received  + 5

- Array []
+ Array [
+   "/admin · h1W: era 101, ahora 98",
+   "/admin · colores: era 1566381053, ahora 90644102",
+   "/presupuestos/nuevo · colores: era 1566381053, ahora 90644102",
+ ]
```

# Page snapshot

```yaml
- generic [active] [ref=e1]:
  - generic [ref=e2]:
    - main [ref=e3]:
      - generic [ref=e4]:
        - generic [ref=e5]:
          - generic [ref=e6]:
            - button "Abrir menu lateral" [ref=e7] [cursor=pointer]:
              - img
              - generic [ref=e8]: Toggle Sidebar
            - img [ref=e10]
            - heading "Central de Presupuestos" [level=1] [ref=e13]
          - generic [ref=e14]:
            - link:
              - /url: /pagos-rapidos
            - link [ref=e15] [cursor=pointer]:
              - /url: /pagos-rapidos
              - button [ref=e16]:
                - img
            - button "Abrir notificaciones" [ref=e17] [cursor=pointer]:
              - img
              - generic [ref=e18]: Abrir notificaciones
            - button "Logo de la Empresa" [ref=e19] [cursor=pointer]:
              - img "Logo de la Empresa" [ref=e21]
        - main [ref=e22]:
          - generic [ref=e23]:
            - generic [ref=e24]:
              - heading "Central de Presupuestos" [level=1] [ref=e25]:
                - img [ref=e26]
                - text: Central de Presupuestos
              - generic [ref=e29]:
                - link "Configurador para la reunión" [ref=e30] [cursor=pointer]:
                  - /url: /empresa/configurador-reunion
                - link "Reporte" [ref=e31] [cursor=pointer]:
                  - /url: /presupuestos/reporte
                - link "Importar desde Texto" [ref=e32] [cursor=pointer]:
                  - /url: /presupuestos/importar
                  - img
                  - text: Importar desde Texto
                - link "Nuevo Presupuesto" [ref=e33] [cursor=pointer]:
                  - /url: /presupuestos/nuevo/crear
                  - img
                  - text: Nuevo Presupuesto
                - button "🗑️ Borrar todos" [disabled]:
                  - img
                  - text: 🗑️ Borrar todos
                - link "Volver" [ref=e34] [cursor=pointer]:
                  - /url: /empresa/contabilidad
            - generic [ref=e35]:
              - generic [ref=e37]:
                - generic [ref=e39]:
                  - generic [ref=e40]: Pendientes (Enviados)
                  - img [ref=e42]
                - generic [ref=e48]: "0"
              - generic [ref=e50]:
                - generic [ref=e52]:
                  - generic [ref=e53]: Borradores
                  - img [ref=e55]
                - generic [ref=e59]: "0"
              - generic [ref=e61]:
                - generic [ref=e63]:
                  - generic [ref=e64]: Aceptados
                  - img [ref=e66]
                - generic [ref=e70]: "0"
              - generic [ref=e72]:
                - generic [ref=e74]:
                  - generic [ref=e75]: Facturados
                  - img [ref=e77]
                - generic [ref=e81]: "0"
              - generic [ref=e83]:
                - generic [ref=e85]:
                  - generic [ref=e86]: Rechazados
                  - img [ref=e88]
                - generic [ref=e93]: "0"
            - generic [ref=e94]:
              - generic [ref=e95]:
                - generic [ref=e96]:
                  - generic [ref=e97]: Presupuestos ordenados
                  - generic [ref=e98]: Separa eventos contratados de prospectos y muestra ambas fechas importantes.
                - generic [ref=e99]:
                  - combobox "Ordenar presupuestos" [ref=e100] [cursor=pointer]:
                    - generic: Orden recomendado
                    - img [ref=e101]
                  - button "Incluir archivados" [ref=e103] [cursor=pointer]
                  - generic [ref=e104]:
                    - img [ref=e105]
                    - textbox "Buscar cliente o Nº..." [ref=e108]
              - generic [ref=e110]:
                - tablist [ref=e111]:
                  - tab "Todos (0)" [selected] [ref=e112] [cursor=pointer]
                  - tab "Borrador" [ref=e113] [cursor=pointer]
                  - tab "Enviado" [ref=e114] [cursor=pointer]
                  - tab "Aceptado" [ref=e115] [cursor=pointer]
                  - tab "Facturado" [ref=e116] [cursor=pointer]
                - tabpanel "Todos (0)" [ref=e117]:
                  - generic [ref=e118]:
                    - img [ref=e119]
                    - paragraph [ref=e122]: No hay presupuestos activos.
                    - paragraph [ref=e123]: Crea uno nuevo o importa un presupuesto para iniciar el seguimiento.
    - navigation "Navegacion del modulo" [ref=e124]:
      - button "Volver" [ref=e125] [cursor=pointer]:
        - img
      - button "Ir al panel principal" [ref=e126] [cursor=pointer]:
        - img
    - button "Abrir Asistente IA AK" [ref=e127] [cursor=pointer]:
      - img [ref=e128]
  - region "Notifications (F8)":
    - list
  - alert [ref=e131]
```

# Test source

```ts
  130 | 
  131 |     await context.addInitScript(() => {
  132 |       window.localStorage.setItem('ak_session', 'true');
  133 |       window.sessionStorage.setItem('ak_session', 'true');
  134 |     });
  135 |     await context.addCookies([
  136 |       { name: 'ak_session', value: createSessionToken(), url: baseURL!, httpOnly: true, sameSite: 'Lax' },
  137 |     ]);
  138 | 
  139 |     // La geometria depende del tamano de pantalla, asi que cada perfil de
  140 |     // Playwright (escritorio y celular) guarda su propia referencia.
  141 |     const perfil = test.info().project.name;
  142 |     const clave = (ruta: string) => `${perfil} ${ruta}`;
  143 | 
  144 |     const referencia = leerReferencia();
  145 |     const actual: Record<string, Huella> = {};
  146 |     const referenciasFaltantes: Record<string, Huella> = {};
  147 |     const desvios: string[] = [];
  148 |     /** Fallas que valen aunque la referencia diga que "siempre fue asi". */
  149 |     const absolutos: string[] = [];
  150 | 
  151 |     for (const { ruta } of RUTAS) {
  152 |       const response = await page.goto(ruta, { waitUntil: 'domcontentloaded' });
  153 |       expect(response?.status(), `${ruta} devolvio una respuesta invalida`).toBeLessThan(400);
  154 |       expect(new URL(page.url()).pathname, `${ruta} redirigio inesperadamente`).toBe(ruta);
  155 |       await page.waitForLoadState('networkidle', { timeout: 5_000 }).catch(() => {});
  156 |       if (ruta === '/presentacion-led') {
  157 |         await expect(page.getByText(/Cargando presentaci/i)).toBeHidden({ timeout: 45_000 });
  158 |       }
  159 |       // Las pantallas del panel traen datos del servidor antes de dibujar el
  160 |       // titulo. Con el servidor despertandose, 2,5 segundos no alcanzaban y la
  161 |       // prueba avisaba "la ruta no existe o no carga" con la pantalla sana.
  162 |       await page.locator('h1, main, header').first().waitFor({ state: 'visible', timeout: 60_000 }).catch(() => {});
  163 |       /**
  164 |        * ANTES DE MEDIR, ESPERAR A QUE LAS LETRAS ESTEN CARGADAS.
  165 |        *
  166 |        * **Esto dio una falsa alarma el 9 de septiembre de 2026.** La pantalla de la
  167 |        * presentacion acuso ocho pixeles de corrimiento en el titular; abierta sola,
  168 |        * estaba perfecta. Con la maquina cargada, la tipografia termina de cargar
  169 |        * DESPUES de la medicion, y el titular se acomoda unos pixeles: se estaba
  170 |        * midiendo la pagina a medio vestir.
  171 |        *
  172 |        * Esperar a las letras no afloja el control: lo hace medir lo que el usuario
  173 |        * ve de verdad, en vez de una foto sacada antes de tiempo.
  174 |        */
  175 |       await page.evaluate(() => Promise.race([(document as any).fonts?.ready,new Promise(resolve=>setTimeout(resolve,15000))])).catch(() => {});
  176 |       await page.waitForTimeout(2500);
  177 |       const huella = await medirHuella(page);
  178 |       actual[clave(ruta)] = huella;
  179 | 
  180 |       // Reglas absolutas: no dependen de la referencia. Sin esto, la referencia
  181 |       // congelaba defectos como si fueran lo normal (paso de verdad: el catalogo
  182 |       // se salia 54px en celular y la prueba lo daba por bueno porque "no habia
  183 |       // cambiado").
  184 |       if (huella.desborde > 2) {
  185 |         absolutos.push(`${ruta} · se sale ${huella.desborde}px a lo ancho`);
  186 |       }
  187 |       if (huella.h1W === -1 && huella.mainX === -1) {
  188 |         absolutos.push(`${ruta} · no tiene ni titulo ni contenido: la ruta no existe o no carga`);
  189 |       }
  190 | 
  191 |       const esperado = referencia[clave(ruta)];
  192 |       if (!esperado) {
  193 |         referenciasFaltantes[clave(ruta)] = actual[clave(ruta)];
  194 |         if (!ACTUALIZAR_REFERENCIAS_FALTANTES) desvios.push(`${ruta} · falta referencia para ${perfil}`);
  195 |         continue;
  196 |       }
  197 | 
  198 |       for (const [medida, valor] of Object.entries(actual[clave(ruta)])) {
  199 |         const antes = esperado[medida];
  200 |         if (typeof antes !== 'number') continue;
  201 |         // El desborde es exacto; las medidas geométricas admiten redondeo.
  202 |         const margen = medida === 'desborde' ? 0 : TOLERANCIA;
  203 |         if (Math.abs(valor - antes) > margen) {
  204 |           desvios.push(`${ruta} · ${medida}: era ${antes}, ahora ${valor}`);
  205 |         }
  206 |       }
  207 |     }
  208 | 
  209 |     // Si se activo la actualizacion de referencias faltantes, se persisten en disco
  210 |     if (Object.keys(referenciasFaltantes).length > 0 && ACTUALIZAR_REFERENCIAS_FALTANTES) {
  211 |       const nuevaReferencia = { ...referencia, ...referenciasFaltantes };
  212 |       fs.writeFileSync(REFERENCIA, `${JSON.stringify(nuevaReferencia, null, 2)}\n`);
  213 |       test.info().annotations.push({
  214 |         type: 'referencia',
  215 |         description: `Se agregaron ${Object.keys(referenciasFaltantes).length} referencias faltantes para ${perfil}.`,
  216 |       });
  217 |     }
  218 | 
  219 |     // Primera corrida (o referencia borrada a proposito): se genera la referencia
  220 |     // pero las reglas absolutas se exigen igual, para no grabar un defecto.
  221 |     const faltaEsteperfil = !Object.keys(referencia).some((k) => k.startsWith(`${perfil} `));
  222 |     if (Object.keys(referencia).length === 0 || faltaEsteperfil) {
  223 |       fs.writeFileSync(REFERENCIA, `${JSON.stringify({ ...referencia, ...actual }, null, 2)}\n`);
  224 |       test.info().annotations.push({ type: 'referencia', description: `Huella generada para ${perfil}.` });
  225 |       expect(absolutos, `Pantallas con defectos propios:\n  ${absolutos.join('\n  ')}`).toEqual([]);
  226 |       return;
  227 |     }
  228 | 
  229 |     expect(absolutos, `Pantallas con defectos propios:\n  ${absolutos.join('\n  ')}`).toEqual([]);
> 230 |     expect(desvios, `La maquetación cambió:\n  ${desvios.join('\n  ')}`).toEqual([]);
      |                                                                          ^ Error: La maquetación cambió:
  231 |   });
  232 | });
  233 | 
```