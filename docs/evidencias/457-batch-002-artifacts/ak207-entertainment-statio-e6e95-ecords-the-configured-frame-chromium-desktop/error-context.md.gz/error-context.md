# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: ak207-entertainment-stations.spec.ts >> time capsule exposes every media mode and records the configured frame
- Location: tests\e2e\ak207-entertainment-stations.spec.ts:142:5

# Error details

```
Error: expect(received).toBeGreaterThan(expected)

Expected: > 0
Received:   0

Call Log:
- Timeout 45000ms exceeded while waiting on the predicate
```

# Test source

```ts
  107 |     expect(response?.status(), route).toBeLessThan(400);
  108 |     await expect(page.locator('body'), route).not.toContainText(/acceso de estacion no autorizado|no se pudo abrir esta estacion/i);
  109 |     await expect(page.locator('button:visible').first(), route).toBeVisible();
  110 |   }
  111 | });
  112 | 
  113 | test('photobooth display receives a browser camera stream', async ({ context, page }, testInfo) => {
  114 |   const baseURL = testInfo.project.use.baseURL as string;
  115 |   await addAppSession(context, baseURL);
  116 |   await page.addInitScript(() => {
  117 |     const getUserMedia = async () => {
  118 |       const canvas = document.createElement('canvas');
  119 |       canvas.width = 720;
  120 |       canvas.height = 1280;
  121 |       const drawing = canvas.getContext('2d');
  122 |       drawing?.fillRect(0, 0, canvas.width, canvas.height);
  123 |       const qa451Canvas=canvas;const qa451Stream=canvas.captureStream(30);const qa451Pump=setInterval(()=>{const c=qa451Canvas.getContext("2d");if(c){c.fillStyle=Date.now()%100<50?"#ffffff":"#eeeeee";c.fillRect(100,100,12,12);}},50);for(const t of qa451Stream.getTracks()){const stop=t.stop.bind(t);t.stop=()=>{clearInterval(qa451Pump);stop();};}return qa451Stream;
  124 |     };
  125 |     Object.defineProperty(navigator, 'mediaDevices', {
  126 |       configurable: true,
  127 |       value: { getUserMedia },
  128 |     });
  129 |   });
  130 | 
  131 |   const response = await page.goto(`/evento/fotocabina/${FIESTA_ID}`, { waitUntil: 'domcontentloaded' });
  132 |   expect(response?.status()).toBeLessThan(400);
  133 |   await expect(page.locator('body')).not.toContainText(/acceso de estacion no autorizado|no se pudo abrir esta estacion/i);
  134 |   // El invitado tiene que VERSE. Puede ser en el `<video>` directo o en el
  135 |   // lienzo de la vista previa: desde que la fotocabina cambia el fondo en vivo,
  136 |   // el video queda oculto a proposito y lo que se muestra es el lienzo con el
  137 |   // fondo ya aplicado. Lo que importa es que se vea la camara, no en cual de
  138 |   // los dos elementos.
  139 |   await expect(page.locator('video:visible, canvas:visible').first()).toBeVisible();
  140 | });
  141 | 
  142 | test('time capsule exposes every media mode and records the configured frame', async ({ context, page }, testInfo) => {
  143 |   test.setTimeout(180000); test.skip(testInfo.project.name !== 'chromium-desktop', 'MediaRecorder coverage only needs Chromium desktop.');
  144 |   const baseURL = testInfo.project.use.baseURL as string;
  145 |   await addAppSession(context, baseURL);
  146 |   await page.addInitScript(() => {
  147 |     const getUserMedia = async () => {
  148 |       const canvas = document.createElement('canvas');
  149 |       canvas.width = 640;
  150 |       canvas.height = 480;
  151 |       const drawing = canvas.getContext('2d');
  152 |       if (drawing) {
  153 |         drawing.fillStyle = '#1e3a5f';
  154 |         drawing.fillRect(0, 0, canvas.width, canvas.height);
  155 |       }
  156 |       const stream = canvas.captureStream(20);const qa451Pump=setInterval(()=>{const c=canvas.getContext("2d");if(c){c.fillStyle=Date.now()%100<50?"#ffffff":"#eeeeee";c.fillRect(100,100,12,12);}},50);for(const t of stream.getTracks()){const stop=t.stop.bind(t);t.stop=()=>{clearInterval(qa451Pump);stop();};}
  157 |       const testWindow = window as typeof window & { __buzonTestStreams?: MediaStream[] };
  158 |       testWindow.__buzonTestStreams = [...(testWindow.__buzonTestStreams || []), stream];
  159 |       return stream;
  160 |     };
  161 |     Object.defineProperty(navigator, 'mediaDevices', {
  162 |       configurable: true,
  163 |       value: { getUserMedia },
  164 |     });
  165 |   });
  166 | 
  167 |   const response = await page.goto(`/evento/buzon/${FIESTA_ID}`, { waitUntil: 'domcontentloaded' });
  168 |   expect(response?.status()).toBeLessThan(400);
  169 |   await expect(page.getByRole('button', { name: /Grabar Video/i })).toBeVisible();
  170 |   await expect(page.getByRole('button', { name: /Mensaje de Audio/i })).toBeVisible();
  171 |   await expect(page.getByRole('button', { name: /Subir video/i })).toBeVisible();
  172 |   await expect(page.getByRole('button', { name: /Subir audio/i })).toBeVisible();
  173 |   await expect(page.getByRole('button', { name: /Cabina telefónica retro/i })).toBeVisible();
  174 | 
  175 |   await page.getByRole('button', { name: /Grabar Video/i }).click();
  176 |   const frameCanvas = page.locator('canvas').first();
  177 |   await expect(frameCanvas).toBeVisible();
  178 |   await expect.poll(async () => frameCanvas.evaluate((element) => {
  179 |     const canvas = element as HTMLCanvasElement;
  180 |     const drawing = canvas.getContext('2d');
  181 |     if (!drawing || canvas.width !== 640 || canvas.height !== 480) return 0;
  182 |     const pixels = drawing.getImageData(0, 0, 40, canvas.height).data;
  183 |     let floralPixels = 0;
  184 |     for (let index = 0; index < pixels.length; index += 4) {
  185 |       const red = pixels[index];
  186 |       const green = pixels[index + 1];
  187 |       const blue = pixels[index + 2];
  188 |       if (green > 170 && green > red * 1.25 && blue > 100) floralPixels += 1;
  189 |     }
  190 |     return floralPixels;
  191 |   })).toBeGreaterThan(20);
  192 | 
  193 |   await page.getByRole('button', { name: /Comenzar a Grabar/i }).click();
  194 |   const stopButton = page.getByRole('button', { name: /Detener Grabación/i });
  195 |   await expect(stopButton).toBeVisible();
  196 |   await page.waitForTimeout(1_000);
  197 |   await stopButton.click();
  198 |   // La etiqueta se llama "Video Grabado", no "Video Analogico". Se verifico en
  199 |   // `src/app/evento/buzon/[fiestaId]/page.tsx`: el paso de revision existe y
  200 |   // funciona, solo cambio el texto. La prueba habia quedado con el nombre viejo.
  201 |   await expect(page.getByText('Video Grabado')).toBeVisible();
  202 |   const reviewVideo = page.locator('video[src^="blob:"]').first();
  203 |   await expect(reviewVideo).toBeVisible();
  204 |   await expect.poll(async () => reviewVideo.evaluate(async (element) => {
  205 |     const source = (element as HTMLVideoElement).src;
  206 |     return (await (await fetch(source)).blob()).size;
> 207 |   })).toBeGreaterThan(0);
      |       ^ Error: expect(received).toBeGreaterThan(expected)
  208 | 
  209 |   await page.getByRole('button', { name: /Grabar de nuevo/i }).click();
  210 |   await expect(page.getByRole('button', { name: /Comenzar a Grabar/i })).toBeVisible();
  211 |   await page.getByRole('button', { name: /Volver al menú/i }).click();
  212 |   await expect.poll(() => page.evaluate(() => {
  213 |     const testWindow = window as typeof window & { __buzonTestStreams?: MediaStream[] };
  214 |     return (testWindow.__buzonTestStreams || []).every(
  215 |       (mediaStream) => mediaStream.getTracks().every((track) => track.readyState === 'ended'),
  216 |     );
  217 |   })).toBe(true);
  218 | });
  219 | 
  220 | test('time capsule bakes the configured frame into an uploaded gallery video', async ({ context, page }, testInfo) => {
  221 |   test.setTimeout(180000); test.skip(testInfo.project.name !== 'chromium-desktop', 'Browser video processing only needs Chromium desktop.');
  222 |   const baseURL = testInfo.project.use.baseURL as string;
  223 |   await addAppSession(context, baseURL);
  224 | 
  225 |   const response = await page.goto(`/evento/buzon/${FIESTA_ID}`, { waitUntil: 'domcontentloaded' });
  226 |   expect(response?.status()).toBeLessThan(400);
  227 |   await page.getByRole('button', { name: /Subir video/i }).click();
  228 |   const input = page.locator('input[type="file"][accept="video/*"]');
  229 |   const qa451Video=await page.evaluate(async()=>{const canvas = document.createElement('canvas');
  230 | canvas.width = 320;
  231 | canvas.height = 240;
  232 | const drawing = canvas.getContext('2d');
  233 | if (drawing) {
  234 |       drawing.fillStyle = '#1e3a5f';
  235 |       drawing.fillRect(0, 0, canvas.width, canvas.height);
  236 |     }
  237 | const stream = canvas.captureStream(20);
  238 | const candidates = ['video/mp4', 'video/webm;codecs=vp9', 'video/webm'];
  239 | const mimeType = candidates.find((candidate) => MediaRecorder.isTypeSupported(candidate)) || '';
  240 | const recorder = mimeType ? new MediaRecorder(stream, { mimeType }) : new MediaRecorder(stream);
  241 | const chunks: Blob[] = [];
  242 | recorder.ondataavailable = (event) => {
  243 |       if (event.data.size > 0) chunks.push(event.data);
  244 |     };
  245 | const stopped = new Promise<void>((resolve) => {
  246 |       recorder.onstop = () => resolve();
  247 |     });
  248 | recorder.start(100);
  249 | let frame = 0;
  250 | const drawingInterval = window.setInterval(() => {
  251 |       if (!drawing) return;
  252 |       drawing.fillStyle = frame % 2 === 0 ? '#1e3a5f' : '#315b82';
  253 |       drawing.fillRect(0, 0, canvas.width, canvas.height);
  254 |       drawing.fillStyle = '#ffffff';
  255 |       drawing.fillRect((frame * 8) % canvas.width, 80, 40, 40);
  256 |       frame += 1;
  257 |     }, 50);
  258 | await new Promise((resolve) => setTimeout(resolve, 1_500));
  259 | window.clearInterval(drawingInterval);
  260 | recorder.stop();
  261 | await stopped;
  262 | stream.getTracks().forEach((track) => track.stop());
  263 | const outputType = recorder.mimeType || mimeType || 'video/webm';
  264 | const extension = outputType.includes('mp4') ? 'mp4' : 'webm';;return{type:outputType,name:`gallery-test.${extension}`,bytes:Array.from(new Uint8Array(await new Blob(chunks,{type:outputType}).arrayBuffer()))};}); await input.setInputFiles({name:qa451Video.name,mimeType:qa451Video.type,buffer:Buffer.from(qa451Video.bytes)});;
  265 | 
  266 |   await expect(page.getByText('Video Cargado')).toBeVisible();
  267 |   const reviewVideo = page.locator('video[src^="blob:"]').first();
  268 |   await expect(reviewVideo).toBeVisible();
  269 |   await expect.poll(async () => reviewVideo.evaluate(async (element) => {
  270 |     const video = element as HTMLVideoElement;
  271 |     video.muted = true;
  272 |     await video.play();
  273 |     await new Promise((resolve) => setTimeout(resolve, 250));
  274 |     const canvas = document.createElement('canvas');
  275 |     canvas.width = 640;
  276 |     canvas.height = 480;
  277 |     const drawing = canvas.getContext('2d');
  278 |     if (!drawing) return 0;
  279 |     drawing.drawImage(video, 0, 0, canvas.width, canvas.height);
  280 |     const pixels = drawing.getImageData(0, 0, 40, canvas.height).data;
  281 |     let floralPixels = 0;
  282 |     for (let index = 0; index < pixels.length; index += 4) {
  283 |       const red = pixels[index];
  284 |       const green = pixels[index + 1];
  285 |       const blue = pixels[index + 2];
  286 |       if (green > 170 && green > red * 1.25 && blue > 100) floralPixels += 1;
  287 |     }
  288 |     return floralPixels;
  289 |   })).toBeGreaterThan(20);
  290 | });
  291 | 
  292 | test('AI mirror keeps one coherent touch selector on desktop and mobile', async ({ context, page }, testInfo) => {
  293 |   const baseURL = testInfo.project.use.baseURL as string;
  294 |   await addAppSession(context, baseURL);
  295 |   await page.addInitScript(() => {
  296 |     const getUserMedia = async () => {
  297 |       const canvas = document.createElement('canvas');
  298 |       canvas.width = 720;
  299 |       canvas.height = 1280;
  300 |       canvas.getContext('2d')?.fillRect(0, 0, canvas.width, canvas.height);
  301 |       const qa451Canvas=canvas;const qa451Stream=canvas.captureStream(30);const qa451Pump=setInterval(()=>{const c=qa451Canvas.getContext("2d");if(c){c.fillStyle=Date.now()%100<50?"#ffffff":"#eeeeee";c.fillRect(100,100,12,12);}},50);for(const t of qa451Stream.getTracks()){const stop=t.stop.bind(t);t.stop=()=>{clearInterval(qa451Pump);stop();};}return qa451Stream;
  302 |     };
  303 |     Object.defineProperty(navigator, 'mediaDevices', {
  304 |       configurable: true,
  305 |       value: { getUserMedia },
  306 |     });
  307 |   });
```