# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: ak207-la-grilla-de-caras.spec.ts >> Orden 36: La grilla de caras >> la selfie no sale del teléfono ni se manda a la red
- Location: tests\e2e\ak207-la-grilla-de-caras.spec.ts:268:7

# Error details

```
Error: muestra la pantalla de resultados, armada en el propio teléfono

expect(received).toBeGreaterThan(expected)

Expected: > 0
Received:   0
```

# Test source

```ts
  213 | 
  214 |     // Deben haber 2 caras (Ana y Beto, el que pasaba por atrás se filtró)
  215 |     const caritas = grilla.locator('button');
  216 |     await expect(caritas).toHaveCount(2);
  217 | 
  218 |     // REGLA 2: NUNCA un nombre al lado de una cara
  219 |     const textoGrilla = await grilla.innerText();
  220 |     expect(textoGrilla.trim()).toBe(''); // Las caritas no tienen texto
  221 | 
  222 |     // Al tocar una cara se filtran sus fotos y aparece "Descargar todas"
  223 |     await caritas.first().click();
  224 |     await expect(page.getByText(/Fotos de esta persona/i)).toBeVisible();
  225 |     await expect(page.getByRole('button', { name: /Descargar todas/i })).toBeVisible();
  226 | 
  227 |     // Siempre a la vista: "Ver todas las fotos de la fiesta"
  228 |     const botonVerTodas = page.getByRole('button', { name: /Ver todas las fotos de la fiesta/i });
  229 |     await expect(botonVerTodas).toBeVisible();
  230 |     await botonVerTodas.click();
  231 | 
  232 |     // Vuelve a la galería completa
  233 |     await expect(page.getByText(/Fotos de esta persona/i)).toHaveCount(0);
  234 |   });
  235 | 
  236 |   test('con el interruptor apagado no se ve ni la grilla ni el botón', async ({ page }, testInfo) => {
  237 |     test.setTimeout(120_000);
  238 | 
  239 |     await page.goto(`/evento/galeria/${ID_APAGADO}`, { waitUntil: 'domcontentloaded' });
  240 |     await page.waitForTimeout(3000);
  241 | 
  242 |     await expect(page.getByRole('button', { name: /Encontrame/i })).toHaveCount(0);
  243 |     await expect(page.locator('[data-testid="grilla-caras"]')).toHaveCount(0);
  244 |   });
  245 | 
  246 |   test('sin aceptar el permiso, la cámara no se prende y la galería sigue igual', async ({ page }, testInfo) => {
  247 |     test.setTimeout(120_000);
  248 | 
  249 |     await page.goto(`/evento/galeria/${ID_PREPARADA}`, { waitUntil: 'domcontentloaded' });
  250 |     await page.waitForTimeout(3000);
  251 | 
  252 |     const boton = page.getByRole('button', { name: /Encontrame a mí/i });
  253 |     await expect(boton).toBeVisible();
  254 |     await boton.click();
  255 | 
  256 |     // Debe mostrar el cartel de permiso claro
  257 |     await expect(
  258 |       page.getByText(/Vamos a mirar tu cara en este teléfono para buscar tus fotos\. No se guarda ni se manda a ningún lado\./i),
  259 |     ).toBeVisible();
  260 | 
  261 |     // Si cancela, el modal se cierra y la galería sigue igual
  262 |     await page.getByRole('button', { name: /Cancelar/i }).click();
  263 |     await expect(
  264 |       page.getByText(/Vamos a mirar tu cara en este teléfono/i),
  265 |     ).toHaveCount(0);
  266 |   });
  267 | 
  268 |   test('la selfie no sale del teléfono ni se manda a la red', async ({ page }, testInfo) => {
  269 |     test.setTimeout(120_000);
  270 | 
  271 |     await enchufarCamara(page);
  272 | 
  273 |     // Monitoreamos toda llamada de red para verificar que NUNCA viaje una imagen
  274 |     const llamadasConImagenes: string[] = [];
  275 |     page.on('request', (req) => {
  276 |       const url = req.url();
  277 |       const postData = req.postData() || '';
  278 |       if (
  279 |         postData.includes('data:image') ||
  280 |         postData.includes('base64') ||
  281 |         /upload|selfie|face-api|tensor|ai-vision/i.test(url)
  282 |       ) {
  283 |         llamadasConImagenes.push(`${req.method()} ${url}`);
  284 |       }
  285 |     });
  286 | 
  287 |     await page.goto(`/evento/galeria/${ID_PREPARADA}`, { waitUntil: 'domcontentloaded' });
  288 |     await page.waitForTimeout(3000);
  289 | 
  290 |     // Abrir "Encontrame a mí"
  291 |     await page.getByRole('button', { name: /Encontrame a mí/i }).click();
  292 | 
  293 |     // Aceptar permiso
  294 |     await page.getByRole('button', { name: /Entendido, buscar mis fotos/i }).click();
  295 | 
  296 |     // Esperar a que tome los cuadros y cierre el modal
  297 |     await page.waitForTimeout(4000);
  298 | 
  299 |     // LA REGLA MÁS IMPORTANTE: Que no se dispare ninguna llamada al servidor con la imagen
  300 |     expect(llamadasConImagenes, 'la selfie no se envió a ningún servidor externo ni local').toHaveLength(0);
  301 | 
  302 |     // Debe mostrar la vista de resultados o el mensaje de "no encontramos".
  303 |     // Los dos titulos conviven en la pantalla, asi que hay que contar cuantos se
  304 |     // ven y no preguntar por "el" titulo: preguntando de a uno, Playwright corta
  305 |     // por ambiguedad (paso el 4 de septiembre de 2026).
  306 |     const titulos = page.getByRole('heading', {
  307 |       name: /Resultados de tu búsqueda|No encontramos fotos tuyas todavía/i,
  308 |     });
  309 |     let visibles = 0;
  310 |     for (let i = 0; i < (await titulos.count()); i += 1) {
  311 |       if (await titulos.nth(i).isVisible()) visibles += 1;
  312 |     }
> 313 |     expect(visibles, 'muestra la pantalla de resultados, armada en el propio teléfono').toBeGreaterThan(0);
      |                                                                                         ^ Error: muestra la pantalla de resultados, armada en el propio teléfono
  314 |   });
  315 | });
  316 | 
```