# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: ak207-474-carga-contexto-controlado.spec.ts >> 474 tres cargas con contexto protegido y cache desactivada
- Location: tests\e2e\ak207-474-carga-contexto-controlado.spec.ts:8:5

# Error details

```
Error: umbral local2500ms, carga0

expect(received).toBeLessThanOrEqual(expected)

Expected: <= 2500
Received:    10519
```

# Page snapshot

```yaml
- generic [active] [ref=e1]:
  - generic [ref=e2]:
    - banner [ref=e3]:
      - generic [ref=e5]:
        - link "AK Producciones AK Producciones" [ref=e6] [cursor=pointer]:
          - /url: /
          - img "AK Producciones" [ref=e8]
          - generic [ref=e9]: AK Producciones
        - navigation [ref=e10]:
          - link "Inicio" [ref=e11] [cursor=pointer]:
            - /url: /#landing-hero
          - link "Servicios" [ref=e12] [cursor=pointer]:
            - /url: /#landing-services
          - link "Galería HD" [ref=e13] [cursor=pointer]:
            - /url: /#landing-gallery
          - link "Simulador" [ref=e14] [cursor=pointer]:
            - /url: /simulador-de-presupuesto
          - link "Blog" [ref=e15] [cursor=pointer]:
            - /url: /public/blog
          - link "Preguntas Frecuentes" [ref=e16] [cursor=pointer]:
            - /url: /#faq
          - link "Club Uruguay" [ref=e17] [cursor=pointer]:
            - /url: /club-uruguay
        - link "Simular mi presupuesto" [ref=e19] [cursor=pointer]:
          - /url: /simulador-de-presupuesto
    - main [ref=e20]:
      - generic [ref=e21]:
        - img "Fiesta de 15 años producida por AK Producciones" [ref=e23]
        - generic [ref=e26]:
          - paragraph [ref=e27]:
            - img [ref=e28]
            - text: AK Producciones Eventos · Salto, Uruguay
          - heading "Fiesta de 15 Años" [level=1] [ref=e30]
          - paragraph [ref=e31]: La noche de tus 15 pensada para que te diviertas al máximo junto a tus amigos y familia.
          - generic [ref=e32]:
            - generic [ref=e33]: Comida gourmet y barra
            - generic [ref=e35]: Ambientación y mobiliario
            - generic [ref=e37]: Discoteca, pantallas y luces
          - generic [ref=e40]:
            - generic [ref=e41]:
              - generic [ref=e42]: Tipo de evento
              - combobox "Tipo de evento" [ref=e43]:
                - option "15 Años" [selected]
                - option "Bodas"
                - option "Sociales"
                - option "Empresariales"
            - generic [ref=e44]:
              - generic [ref=e45]: Mes y año estimado
              - textbox "Mes y año estimado" [ref=e46]: 2026-12
            - generic [ref=e47]:
              - generic [ref=e48]: Invitados aprox.
              - spinbutton "Invitados aprox." [ref=e49]: "100"
            - link "Consultar disponibilidad de fecha" [ref=e51] [cursor=pointer]:
              - /url: /simulador-de-presupuesto?tipo=15%20A%C3%B1os&guests=100&mes=2026-12&entry=hero-fecha
              - img [ref=e52]
              - generic [ref=e54]: Consultar disponibilidad de fecha
          - generic [ref=e55]:
            - link "Descubrir mi fiesta ideal" [ref=e57] [cursor=pointer]:
              - /url: /simulador-de-presupuesto?tipo=XV%20a%C3%B1os
              - text: Descubrir mi fiesta ideal
              - img [ref=e58]
            - link "Hablar con un productor por WhatsApp" [ref=e61] [cursor=pointer]:
              - /url: https://wa.me/59898355530?text=Hola%20AK%20Producciones%2C%20quiero%20cotizar%20fiesta%20de%2015%20a%C3%B1os.
              - img [ref=e62]
              - text: Hablar con un productor por WhatsApp
      - generic [ref=e65]:
        - generic [ref=e66]:
          - img [ref=e67]
          - text: Presupuesto Transparente & Sin Compromiso
        - generic [ref=e70]:
          - img [ref=e71]
          - text: Reserva Tentativa de Fecha
      - generic [ref=e75]:
        - generic [ref=e76]:
          - paragraph [ref=e77]: Producción integral
          - heading "Una propuesta hecha para tu evento" [level=2] [ref=e78]
          - paragraph [ref=e79]: Armamos cada servicio alrededor de la fecha, las personas invitadas y el estilo que querés lograr.
        - generic [ref=e80]:
          - article [ref=e81]:
            - img [ref=e82]
            - heading "Barra de tragos sin alcohol" [level=3] [ref=e85]
            - paragraph [ref=e86]: Cócteles de autor frutales, milkshakes y presentaciones divertidas para tus invitados.
          - article [ref=e87]:
            - img [ref=e88]
            - heading "Espejo Mágico & Fotocabina IA" [level=3] [ref=e91]
            - paragraph [ref=e92]: Fotos divertidas impresas en el acto con accesorios y filtros mágicos de IA.
          - article [ref=e93]:
            - img [ref=e94]
            - heading "Muro Social 4K & Discoteca" [level=3] [ref=e98]
            - paragraph [ref=e99]: Subida de fotos en tiempo real desde el celular a la pantalla gigante del salón.
          - article [ref=e100]:
            - img [ref=e101]
            - heading "Catering Adolescente & Gala" [level=3] [ref=e106]
            - paragraph [ref=e107]: Finger food, hamburguesitas de autor, pizza party y menúes especiales.
          - article [ref=e108]:
            - img [ref=e109]
            - heading "Decoración & Ambientación LED" [level=3] [ref=e114]
            - paragraph [ref=e115]: Luces arquitectónicas, letras gigantes iluminadas y rincones temáticos para fotos.
      - generic [ref=e117]:
        - img "Pista de baile y luces para fiesta de 15" [ref=e119]
        - generic [ref=e120]:
          - paragraph [ref=e121]: Acompañamiento real
          - heading "Tu noche soñada con tecnología y diversión sin límites" [level=2] [ref=e122]
          - paragraph [ref=e123]: Barra de tragos de autor sin alcohol, Espejo Mágico IA con impresión al instante, Muro Social en vivo y discoteca con iluminación LED sincronizada.
          - list [ref=e124]:
            - listitem [ref=e125]:
              - img [ref=e126]
              - text: Una consulta clara desde el primer contacto.
            - listitem [ref=e129]:
              - img [ref=e130]
              - text: Opciones que se ajustan a tu evento.
            - listitem [ref=e133]:
              - img [ref=e134]
              - text: Un equipo que coordina cada momento.
          - generic [ref=e137]:
            - link "Descubrir mi fiesta ideal" [ref=e138] [cursor=pointer]:
              - /url: /simulador-de-presupuesto?tipo=XV%20a%C3%B1os
              - text: Descubrir mi fiesta ideal
              - img [ref=e139]
            - link "Hablar con un productor" [ref=e141] [cursor=pointer]:
              - /url: https://wa.me/59898355530?text=Hola%20AK%20Producciones%2C%20quiero%20cotizar%20fiesta%20de%2015%20a%C3%B1os.
              - img [ref=e142]
              - text: Hablar con un productor
      - generic [ref=e145]:
        - generic [ref=e146]:
          - paragraph [ref=e147]: Experiencias Verificadas
          - heading "Lo que dicen las familias que festejaron con AK" [level=2] [ref=e148]
        - generic [ref=e149]:
          - generic [ref=e150]:
            - generic [ref=e151]:
              - img [ref=e152]
              - img [ref=e154]
              - img [ref=e156]
              - img [ref=e158]
              - img [ref=e160]
            - paragraph [ref=e162]: "\"La organización fue impecable de punta a punta. No tuvimos que preocuparnos por nada durante la noche.\""
            - generic [ref=e163]:
              - paragraph [ref=e164]: Familia Rodríguez
              - paragraph [ref=e165]: Boda en Salto
          - generic [ref=e166]:
            - generic [ref=e167]:
              - img [ref=e168]
              - img [ref=e170]
              - img [ref=e172]
              - img [ref=e174]
              - img [ref=e176]
            - paragraph [ref=e178]: "\"La fotocabina y el show de luces fueron la sensación de los 15 de mi hija. Excelente servicio técnico.\""
            - generic [ref=e179]:
              - paragraph [ref=e180]: Mariana S.
              - paragraph [ref=e181]: Fiesta de 15
          - generic [ref=e182]:
            - generic [ref=e183]:
              - img [ref=e184]
              - img [ref=e186]
              - img [ref=e188]
              - img [ref=e190]
              - img [ref=e192]
            - paragraph [ref=e194]: "\"Cumplieron con todo lo presupuestado, sin sorpresas ni costos ocultos. Súper profesionales.\""
            - generic [ref=e195]:
              - paragraph [ref=e196]: Martín G.
              - paragraph [ref=e197]: Evento Corporativo
      - generic [ref=e199]:
        - generic [ref=e200]:
          - img [ref=e201]
          - heading "Empecemos a planificar" [level=2] [ref=e203]
          - paragraph [ref=e204]: Contanos la fecha aproximada y las personas invitadas. Nuestro equipo recibe tu consulta en el CRM para continuar por el canal que prefieras.
          - generic [ref=e205]:
            - generic [ref=e206]:
              - img [ref=e207]
              - generic [ref=e210]: Respuesta rápida por WhatsApp o llamada
            - generic [ref=e211]:
              - img [ref=e212]
              - generic [ref=e215]: Presupuestos detallados por escrito
            - generic [ref=e216]:
              - img [ref=e217]
              - generic [ref=e220]: Asesoramiento comercial personalizado
        - generic [ref=e222]:
          - generic [ref=e223]:
            - heading "Cotizá Fiesta de 15 Años" [level=3] [ref=e224]
            - paragraph [ref=e225]: Dejanos tus datos y te contactamos con una propuesta para tu evento.
          - generic [ref=e226]:
            - generic [ref=e227]:
              - generic [ref=e228]:
                - generic [ref=e229]: Nombre *
                - textbox "Nombre *" [ref=e230]:
                  - /placeholder: Tu nombre
              - generic [ref=e231]:
                - generic [ref=e232]: WhatsApp / Teléfono *
                - textbox "WhatsApp / Teléfono *" [ref=e233]:
                  - /placeholder: 099 123 456
            - generic [ref=e234]:
              - generic [ref=e235]:
                - generic [ref=e236]: Fecha estimada
                - textbox "Fecha estimada" [ref=e237]
              - generic [ref=e238]:
                - generic [ref=e239]: Invitados estimados
                - spinbutton "Invitados estimados" [ref=e240]
            - generic [ref=e241]:
              - generic [ref=e242]: Email (opcional)
              - textbox "Email (opcional)" [ref=e243]:
                - /placeholder: tu@email.com
            - generic [ref=e244]:
              - generic [ref=e245]: ¿Algo que quieras contarnos?
              - textbox "¿Algo que quieras contarnos?" [ref=e246]:
                - /placeholder: Salón, estilo, colores, ideas...
            - generic [ref=e247] [cursor=pointer]:
              - checkbox "Acepto que AK Producciones use mis datos para medir esta campaña y enviarme promociones. Es opcional." [ref=e248]
              - generic [ref=e249]: Acepto que AK Producciones use mis datos para medir esta campaña y enviarme promociones. Es opcional.
            - button "Consultar por WhatsApp" [ref=e250] [cursor=pointer]:
              - img [ref=e251]
              - text: Consultar por WhatsApp
            - paragraph [ref=e255]:
              - text: Usamos tus datos sólo para contestarte y para tu evento (Ley 18.331).
              - link "Privacidad" [ref=e256] [cursor=pointer]:
                - /url: /privacidad
            - paragraph [ref=e257]:
              - text: También podés escribirnos directo por
              - link "WhatsApp" [ref=e258] [cursor=pointer]:
                - /url: https://wa.me/59898355530?text=%C2%A1Hola%20AK%20Producciones!%20Me%20gustar%C3%ADa%20cotizar%20mi%20evento.
                - img [ref=e259]
                - text: WhatsApp
    - contentinfo [ref=e261]:
      - generic [ref=e263]:
        - generic [ref=e264]:
          - generic [ref=e265]:
            - generic [ref=e266]:
              - img "AK Producciones" [ref=e268]
              - generic [ref=e269]:
                - generic [ref=e270]: AK Producciones
                - generic [ref=e271]: Producción Integral de Eventos • Salto, Uruguay
            - paragraph [ref=e272]: Diseñamos bodas, 15 años y eventos empresariales inolvidables. Gastronomía gourmet, discoteca profesional, salones de gala y tecnología interactiva en un solo lugar.
          - generic [ref=e273]:
            - link "Consultar disponibilidad por WhatsApp (abre en nueva ventana)" [ref=e274] [cursor=pointer]:
              - /url: https://wa.me/59898355530?text=%C2%A1Hola%20AK%20Producciones!%20Quisiera%20consultar%20disponibilidad%20para%20mi%20fecha.
              - img [ref=e278]
              - generic [ref=e280]: WhatsApp Directo
            - link "Simular mi presupuesto" [ref=e281] [cursor=pointer]:
              - /url: /simulador-de-presupuesto
              - img [ref=e282]
              - generic [ref=e284]: Simular mi presupuesto
        - generic [ref=e285]:
          - generic [ref=e286]:
            - heading "Salones Destacados" [level=4] [ref=e287]:
              - img [ref=e288]
              - text: Salones Destacados
            - list [ref=e292]:
              - listitem [ref=e293]:
                - link "Salón Club Uruguay (Exclusivo)" [ref=e294] [cursor=pointer]:
                  - /url: /club-uruguay
                  - text: Salón Club Uruguay (Exclusivo)
              - listitem [ref=e296]:
                - link "Gastronomía Gourmet & Catering" [ref=e297] [cursor=pointer]:
                  - /url: "#landing-services"
                  - text: Gastronomía Gourmet & Catering
              - listitem [ref=e299]:
                - link "Discoteca & Pistas de Luces LED" [ref=e300] [cursor=pointer]:
                  - /url: "#landing-services"
                  - text: Discoteca & Pistas de Luces LED
              - listitem [ref=e302]:
                - link "Plataforma 360° & Fotocabina QR" [ref=e303] [cursor=pointer]:
                  - /url: "#landing-technology"
                  - text: Plataforma 360° & Fotocabina QR
          - generic [ref=e305]:
            - heading "Accesos Rápidos" [level=4] [ref=e306]:
              - img [ref=e307]
              - text: Accesos Rápidos
            - list [ref=e309]:
              - listitem [ref=e310]:
                - link "→ Simulador de Presupuesto" [ref=e311] [cursor=pointer]:
                  - /url: /simulador-de-presupuesto
                  - generic [ref=e312]: →
                  - text: Simulador de Presupuesto
                  - img [ref=e313]
              - listitem [ref=e316]:
                - link "→ Galería de Eventos Reales" [ref=e317] [cursor=pointer]:
                  - /url: "#landing-gallery"
                  - generic [ref=e318]: →
                  - text: Galería de Eventos Reales
              - listitem [ref=e319]:
                - link "→ Blog & Guías de Organización" [ref=e320] [cursor=pointer]:
                  - /url: /public/blog
                  - generic [ref=e321]: →
                  - text: Blog & Guías de Organización
              - listitem [ref=e322]:
                - link "→ Testimonios & Preguntas Frecuentes" [ref=e323] [cursor=pointer]:
                  - /url: "#landing-testimonials-faq"
                  - generic [ref=e324]: →
                  - text: Testimonios & Preguntas Frecuentes
          - generic [ref=e325]:
            - heading "Oficina & Atención" [level=4] [ref=e326]:
              - img [ref=e327]
              - text: Oficina & Atención
            - generic [ref=e330]:
              - paragraph [ref=e331]:
                - img [ref=e332]
                - generic [ref=e335]: Salto, Uruguay
              - paragraph [ref=e336]:
                - img [ref=e337]
                - link "+598 98 355 530" [ref=e339] [cursor=pointer]:
                  - /url: tel:+59898355530
              - paragraph [ref=e340]: Coordinación presencial el día de tu celebración.
          - generic [ref=e341]:
            - heading "Comunidad & Redes" [level=4] [ref=e342]:
              - img [ref=e343]
              - text: Comunidad & Redes
            - paragraph [ref=e345]: Seguinos en redes para ver coberturas en vivo, montajes reales y salones armados.
            - generic [ref=e346]:
              - link "Visitar Instagram de AK Producciones (abre en nueva ventana)" [ref=e347] [cursor=pointer]:
                - /url: https://www.instagram.com/akproduccionesfiestasyeventos/
                - img [ref=e348]
              - link "Visitar Facebook de AK Producciones (abre en nueva ventana)" [ref=e351] [cursor=pointer]:
                - /url: https://www.facebook.com/akproduccionessalto/
                - img [ref=e352]
              - link "Visitar Pinterest de AK Producciones (abre en nueva ventana)" [ref=e354] [cursor=pointer]:
                - /url: https://es.pinterest.com/akproduccionessalto/
                - img [ref=e355]
              - link "Visitar WhatsApp de AK Producciones (abre en nueva ventana)" [ref=e357] [cursor=pointer]:
                - /url: https://wa.me/59898355530?text=%C2%A1Hola%20AK%20Producciones!%20Quisiera%20consultar%20por%20mi%20evento.
                - img [ref=e358]
              - link "Visitar TikTok de AK Producciones (abre en nueva ventana)" [ref=e360] [cursor=pointer]:
                - /url: https://www.tiktok.com/@akproduccioneseve
                - img [ref=e361]
        - generic [ref=e365]:
          - generic [ref=e366]:
            - paragraph [ref=e367]: © 2026 AK Producciones Eventos. Todos los derechos reservados.
            - generic [ref=e368]: ·
            - paragraph [ref=e369]:
              - text: Tus datos se tratan según la
              - link "Ley 18.331" [ref=e370] [cursor=pointer]:
                - /url: /privacidad
              - text: de Protección de Datos Personales.
          - generic [ref=e371]:
            - link "Club Uruguay" [ref=e372] [cursor=pointer]:
              - /url: /club-uruguay
            - link "Simulador" [ref=e373] [cursor=pointer]:
              - /url: /simulador-de-presupuesto
            - link "Privacidad" [ref=e374] [cursor=pointer]:
              - /url: /privacidad
            - link "Acceso Staff" [ref=e375] [cursor=pointer]:
              - /url: /login
  - region "Notifications (F8)":
    - list
  - alert [ref=e376]
```

# Test source

```ts
  1  | import {test as __akAudit207} from '@playwright/test';
  2  | __akAudit207.beforeEach(async({context},info)=>{
  3  |  await context.route('**/*',async r=>{const u=new URL(r.request().url());if(/^https?:$/.test(u.protocol)&&!['127.0.0.1','localhost','[::1]'].includes(u.hostname)){await info.attach('qa-egress-blocked',{contentType:'text/plain',body:u.origin+u.pathname});await r.abort('blockedbyclient');}else await r.continue();});
  4  |  await context.route('https://firebaseinstallations.googleapis.com/**',async r=>{const u=new URL(r.request().url());const body=u.pathname.endsWith('authTokens:generate')?{token:'qa368-fis-only',expiresIn:'604800s'}:{fid:'c'+'a'.repeat(21),refreshToken:'qa368-fis-refresh-only',authToken:{token:'qa368-fis-only',expiresIn:'604800s'}};await r.fulfill({status:200,contentType:'application/json',body:JSON.stringify(body)});});
  5  |  await info.attach('qa-fis-mode',{contentType:'text/plain',body:'LOCAL DOUBLE only; no Firebase provider acceptance'});
  6  | });
  7  | import {test,expect} from '@playwright/test';
  8  | test('474 tres cargas con contexto protegido y cache desactivada',async({page,context},info)=>{
  9  |  test.setTimeout(180000);const samples:any[]=[];const cdp=await context.newCDPSession(page);
  10 |  await cdp.send('Network.enable');await cdp.send('Network.setCacheDisabled',{cacheDisabled:true});
  11 |  try{
  12 |   for(let attempt=0;attempt<3;attempt++){
  13 |    await page.goto('about:blank');const start=Date.now();let status:number|undefined;
  14 |    try{const response=await page.goto('/quinceaneras',{waitUntil:'domcontentloaded',timeout:30000});status=response?.status();const duration=Date.now()-start;
  15 |     await expect(page.locator('main,h1').first()).toBeVisible({timeout:10000});
  16 |     samples.push({attempt,status,duration,timing:await page.evaluate(()=>performance.getEntriesByType('navigation').map((n:any)=>({requestStart:n.requestStart,responseStart:n.responseStart,responseEnd:n.responseEnd,domContentLoaded:n.domContentLoadedEventEnd}))) });
  17 |    }catch(error){samples.push({attempt,status,duration:Date.now()-start,error:String(error)});}
  18 |   }
> 19 |   expect(samples).toHaveLength(3);for(const s of samples){expect(s.error,'carga'+s.attempt).toBeUndefined();expect(s.status).toBeLessThan(400);expect(s.duration,'umbral local2500ms, carga'+s.attempt).toBeLessThanOrEqual(2500);}
     |                                                                                                                                                                                                         ^ Error: umbral local2500ms, carga0
  20 |  }finally{await info.attach('qa474-muestras',{contentType:'application/json',body:Buffer.from(JSON.stringify({samples,scope:'Same2500ms DOMContentLoaded criterion; fixture context keeps local-only FIS guard. HTTP cache disabled, no SDK emulator overhead, no separate context.close loop. This local QA is not production Core Web Vitals.'}))});await cdp.detach();}
  21 | });
  22 | 
```