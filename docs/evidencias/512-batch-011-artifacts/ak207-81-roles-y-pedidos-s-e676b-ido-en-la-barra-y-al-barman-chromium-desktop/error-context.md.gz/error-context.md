# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: ak207-81-roles-y-pedidos-sin-duplicados.spec.ts >> Orden 81 — Barra tecnológica: doble toque sin duplicados y pantalla de barman >> dos toques rápidos de pedir generan un solo pedido en la barra y al barman
- Location: tests\e2e\ak207-81-roles-y-pedidos-sin-duplicados.spec.ts:89:7

# Error details

```
Error: expect(received).toBe(expected) // Object.is equality

Expected: 1
Received: 0

Call Log:
- Timeout 30000ms exceeded while waiting on the predicate
```

# Test source

```ts
  33  | import {
  34  |   crearFiestaDeEstaNoche,
  35  |   guardarFiesta,
  36  |   borrarFiesta,
  37  |   ponerSesionDelEquipo,
  38  |   leerFiesta,
  39  | } from './helpers/fiesta-de-prueba';
  40  | 
  41  | /**
  42  |  * Orden 81 — Sección D: Barra tecnológica, roles y pedidos sin duplicados.
  43  |  *
  44  |  * Flujo de usuario real:
  45  |  * 1. El invitado entra desde su invitación digital personalizada.
  46  |  * 2. Se comprueba que no tiene acceso a botones de administración ni pantalla de barman.
  47  |  * 3. Selecciona un trago del quiosco y toca DOS VECES RÁPIDO el botón de confirmar pedido.
  48  |  * 4. La protección contra doble pulsación evita duplicados:
  49  |  *    - Se verifica que en la fiesta se registró EXACTAMENTE UN pedido.
  50  |  *    - Se abre la pantalla del barman (`/evento/barra/[id]/barman`) y se comprueba
  51  |  *      que en la lista de pedidos en vivo el pedido del invitado aparece una sola vez.
  52  |  */
  53  | 
  54  | const fiesta = crearFiestaDeEstaNoche({ id: `e2e_barra_81_${Date.now()}` });
  55  | if (fiesta.modulosContratados) {
  56  |   fiesta.modulosContratados.barraTecnologica = true;
  57  | }
  58  | fiesta.others = {
  59  |   ...fiesta.others,
  60  |   barraTecnologica: {
  61  |     settings: {
  62  |       enabled: true,
  63  |       openingTime: '',
  64  |       closingTime: '',
  65  |     },
  66  |     orders: [],
  67  |   },
  68  | };
  69  | // Los datos de prueba tienen durazno y almíbar en cero, y la barra hace bien en no aceptar un
  70  | // trago sin ingredientes ("se terminó un ingrediente"). Esta prueba mira el doble toque, no el
  71  | // stock: cada trago se arma sólo con ron, que en los datos de prueba sí hay (medido el 6/10/2026).
  72  | if (fiesta.cartaTragos?.items) {
  73  |   fiesta.cartaTragos.items = fiesta.cartaTragos.items.map((trago) => ({
  74  |     ...trago,
  75  |     recetaIngredientes: [{ insumoId: 'ing-ron', nombre: 'Ron', cantidad: 0.0667, unidad: 'Botella' }],
  76  |   }));
  77  | }
  78  | const invitado = fiesta.invitados?.[0] || {
  79  |   id: 'inv_test_81',
  80  |   nombre: 'Lucía Fernández',
  81  |   tableNumber: '1',
  82  |   guestAccessToken: 'tok_test_81',
  83  | };
  84  | 
  85  | test.beforeAll(() => guardarFiesta(fiesta));
  86  | test.afterAll(() => borrarFiesta(fiesta.id));
  87  | 
  88  | test.describe('Orden 81 — Barra tecnológica: doble toque sin duplicados y pantalla de barman', () => {
  89  |   test('dos toques rápidos de pedir generan un solo pedido en la barra y al barman', async ({ page, context }, testInfo) => {
  90  |     test.setTimeout(240_000);
  91  |     const baseURL = testInfo.project.use.baseURL as string;
  92  | 
  93  |     // 1. Abrir la pantalla de invitación del invitado con quiosco de barra
  94  |     await page.goto(`/invitacion/${fiesta.id}/invitado/${invitado.id}?token=${invitado.guestAccessToken}`, { waitUntil: 'domcontentloaded' });
  95  |     await expect(page.getByText(/Estamos preparando tu información/i)).toBeHidden({ timeout: 60_000 });
  96  |     await expect(page.getByText(invitado.nombre).first()).toBeVisible({ timeout: 30_000 });
  97  | 
  98  |     // 2. Verificar que no se muestran controles administrativos de barman
  99  |     await expect(page.getByRole('button', { name: /pausar barra|entregar pedido|cerrar caja|gestionar stock/i })).toHaveCount(0);
  100 |     await expect(page.getByText(/Panel de control barman|Modo Bartender|Administración de barra/i)).toHaveCount(0);
  101 | 
  102 |     // Abrir la carta de tragos desde el portal del invitado
  103 |     const btnCarta = page.getByRole('button', { name: /carta de tragos/i }).first();
  104 |     await expect(btnCarta).toBeVisible({ timeout: 25_000 });
  105 |     await btnCarta.click();
  106 | 
  107 |     // Esperar a que el quiosco de tragos termine de cargar
  108 |     await expect(page.getByText(/Estamos preparando el quiosco de tragos/i)).toBeHidden({ timeout: 60_000 });
  109 | 
  110 |     // 3. Seleccionar el primer trago de la carta
  111 |     const btnPedir = page.locator('[data-testid="boton-pedir-trago"]').first();
  112 |     await expect(btnPedir).toBeVisible({ timeout: 20_000 });
  113 |     await btnPedir.click();
  114 | 
  115 |     // 4. Se abre el diálogo modal con el botón Confirmar
  116 |     const btnConfirmar = page.locator('[data-testid="boton-confirmar-pedido"]');
  117 |     await expect(btnConfirmar).toBeVisible({ timeout: 10_000 });
  118 | 
  119 |     // 5. Tocar el botón de confirmar pedido (y segundo toque rápido)
  120 |     await btnConfirmar.click();
  121 |     await btnConfirmar.click({ force: true }).catch(() => {});
  122 | 
  123 |     // 6. Esperar a que el diálogo se cierre y aparezca el aviso de éxito
  124 |     await expect(page.getByText(/Pedido registrado/i).first()).toBeVisible({ timeout: 90_000 });
  125 | 
  126 |     // 7. Comprobar en los datos guardados de la fiesta que hay exactamente UN pedido para este invitado
  127 |     await expect.poll(() => {
  128 |       const fiestaActualizada = leerFiesta(fiesta.id);
  129 |       const pedidos = fiestaActualizada?.others?.barraTecnologica?.orders || [];
  130 |       return pedidos.filter(
  131 |         (p: any) => p.guestName === invitado.nombre || p.guestId === invitado.id,
  132 |       ).length;
> 133 |     }, { timeout: 30_000 }).toBe(1);
      |                             ^ Error: expect(received).toBe(expected) // Object.is equality
  134 | 
  135 |     // 8. Abrir la pantalla del barman con sesión del equipo y verificar que aparece una sola vez
  136 |     await ponerSesionDelEquipo(context, baseURL);
  137 |     const barmanPage = await context.newPage();
  138 |     await barmanPage.goto(`/evento/barra/${fiesta.id}/barman`, { waitUntil: 'domcontentloaded' });
  139 |     await expect(barmanPage.getByText(/Pedidos de barra en vivo/i)).toBeVisible({ timeout: 45_000 });
  140 | 
  141 |     await expect(barmanPage.getByText(invitado.nombre)).toHaveCount(1, { timeout: 30_000 });
  142 |     await barmanPage.close();
  143 |   });
  144 | });
  145 | 
```