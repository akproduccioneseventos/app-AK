# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: ak207-90-lo-que-va-atras-dice-donde-quedo.spec.ts >> Orden 90 — Bloque 2: la pantalla dice la verdad según dónde quedó la captura >> Fotocabina con subida rechazada: muestra el error y NO dice que se sube sola
- Location: tests\e2e\ak207-90-lo-que-va-atras-dice-donde-quedo.spec.ts:137:7

# Error details

```
Error: expect(locator).toBeVisible() failed

Locator: getByRole('button', { name: /publicar en el muro/i })
Expected: visible
Timeout: 25000ms
Error: element(s) not found

Call log:
  - Expect "toBeVisible" with timeout 25000ms
  - waiting for getByRole('button', { name: /publicar en el muro/i })

```

```yaml
- button "Volver":
  - img
- heading "Fotocabina AK" [level=1]
- paragraph: Fiesta de esta noche
- paragraph: Foto 3 de 3
- paragraph: "Última: la mejor sonrisa."
- button "Cambiar de estación":
  - img
- region "Notifications (F8)":
  - list
- alert
```

# Test source

```ts
  65  | 
  66  | (fiesta as any).others.entretenimiento.modules.plataforma360 = {
  67  |   countdownSeconds: 2,
  68  |   recordingDurationSeconds: 2,
  69  | };
  70  | 
  71  | test.beforeAll(() => guardarFiesta(fiesta));
  72  | test.afterAll(() => borrarFiesta(fiesta.id));
  73  | 
  74  | async function esperarCamaraLista(page: any) {
  75  |   for (let intento = 0; intento < 15; intento++) {
  76  |     const hayCamara = await page.evaluate(() => {
  77  |       const v = document.querySelector('video');
  78  |       return Boolean(v && (v as HTMLVideoElement).srcObject);
  79  |     });
  80  |     if (hayCamara) {
  81  |       await page.waitForTimeout(500);
  82  |       return;
  83  |     }
  84  |     await page.waitForTimeout(1_000);
  85  |   }
  86  | }
  87  | 
  88  | function simularRechazoAction(texto: string, mensajeError: string) {
  89  |   let resultado = texto;
  90  |   if (resultado.includes('"error"')) {
  91  |     resultado = resultado.replace(/"error"\s*:\s*"[^"]*"/g, `"error":"${mensajeError}"`);
  92  |   } else {
  93  |     resultado = resultado.replace(/"success"\s*:\s*(true|false)/, `"success":false,"error":"${mensajeError}"`);
  94  |   }
  95  |   return resultado.replace(/"success"\s*:\s*true/g, '"success":false');
  96  | }
  97  | 
  98  | test.describe('Orden 90 — Bloque 2: la pantalla dice la verdad según dónde quedó la captura', () => {
  99  |   test('Fotocabina con corte de red: dice guardada en el equipo y NUNCA subida ni galería', async ({ context, page }, testInfo) => {
  100 |     test.setTimeout(90_000);
  101 |     const baseURL = testInfo.project.use.baseURL as string;
  102 |     await ponerSesionDelEquipo(context, baseURL);
  103 |     await enchufarCamaraFalsa(page);
  104 | 
  105 |     await page.route('**/evento/fotocabina/**', async (route) => {
  106 |       const req = route.request();
  107 |       const contentType = req.headers()['content-type'] || '';
  108 |       if (req.method() === 'POST' && contentType.includes('multipart/form-data')) {
  109 |         await route.abort('internetdisconnected');
  110 |         return;
  111 |       }
  112 |       await route.continue();
  113 |     });
  114 | 
  115 |     const permiso = crearPermisoDeEstacion(fiesta.id, 'fotocabina');
  116 |     await page.goto(`/evento/fotocabina/${fiesta.id}?access=${permiso}`, { waitUntil: 'domcontentloaded' });
  117 |     await esperarCamaraLista(page);
  118 | 
  119 |     const btnCaptura = page.locator('[data-testid="boton-sacar-foto"]').or(page.getByRole('button', { name: /preparar foto|sacar/i })).first();
  120 |     await expect(btnCaptura).toBeVisible({ timeout: 25_000 });
  121 |     await btnCaptura.click();
  122 | 
  123 |     // Esperar a que pase la captura y aparezca la vista previa con el botón para publicar
  124 |     const btnPublicar = page.getByRole('button', { name: /publicar en el muro/i });
  125 |     await expect(btnPublicar).toBeVisible({ timeout: 25_000 });
  126 |     await btnPublicar.click();
  127 | 
  128 |     // Debe mostrar que quedó guardada en el equipo
  129 |     const avisoEquipo = page.getByText(/guardada en este equipo|quedó guardada/i).first();
  130 |     await expect(avisoEquipo).toBeVisible({ timeout: 35_000 });
  131 | 
  132 |     // Y NUNCA debe decir "subida" ni "en la galería"
  133 |     const textoPagina = (await page.locator('body').innerText()).toLowerCase();
  134 |     expect(textoPagina).not.toMatch(/ya se subió|ya está subida|en la galería de la fiesta|tu recuerdo esta listo/i);
  135 |   });
  136 | 
  137 |   test('Fotocabina con subida rechazada: muestra el error y NO dice que se sube sola', async ({ context, page }, testInfo) => {
  138 |     test.setTimeout(90_000);
  139 |     const baseURL = testInfo.project.use.baseURL as string;
  140 |     await ponerSesionDelEquipo(context, baseURL);
  141 |     await enchufarCamaraFalsa(page);
  142 | 
  143 |     await page.route('**/evento/fotocabina/**', async (route) => {
  144 |       const req = route.request();
  145 |       const contentType = req.headers()['content-type'] || '';
  146 |       if (req.method() === 'POST' && contentType.includes('multipart/form-data')) {
  147 |         const respuesta = await route.fetch();
  148 |         const texto = await respuesta.text();
  149 |         const nuevoTexto = simularRechazoAction(texto, 'Contenido inapropiado');
  150 |         await route.fulfill({ response: respuesta, body: nuevoTexto });
  151 |         return;
  152 |       }
  153 |       await route.continue();
  154 |     });
  155 | 
  156 |     const permiso = crearPermisoDeEstacion(fiesta.id, 'fotocabina');
  157 |     await page.goto(`/evento/fotocabina/${fiesta.id}?access=${permiso}`, { waitUntil: 'domcontentloaded' });
  158 |     await esperarCamaraLista(page);
  159 | 
  160 |     const btnCaptura = page.locator('[data-testid="boton-sacar-foto"]').or(page.getByRole('button', { name: /preparar foto|sacar/i })).first();
  161 |     await expect(btnCaptura).toBeVisible({ timeout: 25_000 });
  162 |     await btnCaptura.click();
  163 | 
  164 |     const btnPublicar = page.getByRole('button', { name: /publicar en el muro/i });
> 165 |     await expect(btnPublicar).toBeVisible({ timeout: 25_000 });
      |                               ^ Error: expect(locator).toBeVisible() failed
  166 |     await btnPublicar.click();
  167 | 
  168 |     // Debe informar el error de rechazo
  169 |     const avisoError = page.getByText(/no se pudo publicar|contenido inapropiado/i).first();
  170 |     await expect(avisoError).toBeVisible({ timeout: 35_000 });
  171 | 
  172 |     // Y NO debe decir que se sube sola ni que quedó guardada
  173 |     const textoPagina = (await page.locator('body').innerText()).toLowerCase();
  174 |     expect(textoPagina).not.toMatch(/se sube sola|se subirá cuando vuelva la señal|guardada en este equipo/i);
  175 |   });
  176 | 
  177 |   test('Plataforma 360 con corte de red: dice guardado en el equipo y NUNCA subido ni galería', async ({ context, page }, testInfo) => {
  178 |     test.setTimeout(90_000);
  179 |     const baseURL = testInfo.project.use.baseURL as string;
  180 |     await ponerSesionDelEquipo(context, baseURL);
  181 |     await enchufarCamaraFalsa(page);
  182 | 
  183 |     await page.route('**/evento/plataforma-360/**', async (route) => {
  184 |       const req = route.request();
  185 |       const contentType = req.headers()['content-type'] || '';
  186 |       if (req.method() === 'POST' && contentType.includes('multipart/form-data')) {
  187 |         await route.abort('internetdisconnected');
  188 |         return;
  189 |       }
  190 |       await route.continue();
  191 |     });
  192 | 
  193 |     const permiso = crearPermisoDeEstacion(fiesta.id, 'plataforma360');
  194 |     await page.goto(`/evento/plataforma-360/${fiesta.id}?access=${permiso}`, { waitUntil: 'domcontentloaded' });
  195 | 
  196 |     const btnGrabar = page.getByRole('button', { name: /grabar video/i }).first();
  197 |     await expect(btnGrabar).toBeVisible({ timeout: 20_000 });
  198 |     await btnGrabar.click();
  199 | 
  200 |     // Debe mostrar que quedó guardado en el equipo
  201 |     const avisoEquipo = page.getByText(/video guardado en este equipo|quedó guardado/i).first();
  202 |     await expect(avisoEquipo).toBeVisible({ timeout: 45_000 });
  203 | 
  204 |     // Y NUNCA debe decir subido ni en la galería
  205 |     const textoPagina = (await page.locator('body').innerText()).toLowerCase();
  206 |     expect(textoPagina).not.toMatch(/tu video ya está subido|en la galería/i);
  207 |   });
  208 | 
  209 |   test('Plataforma 360 con subida rechazada: muestra el error y NO dice que se sube sola', async ({ context, page }, testInfo) => {
  210 |     test.setTimeout(90_000);
  211 |     const baseURL = testInfo.project.use.baseURL as string;
  212 |     await ponerSesionDelEquipo(context, baseURL);
  213 |     await enchufarCamaraFalsa(page);
  214 | 
  215 |     await page.route('**/evento/plataforma-360/**', async (route) => {
  216 |       const req = route.request();
  217 |       const contentType = req.headers()['content-type'] || '';
  218 |       if (req.method() === 'POST' && contentType.includes('multipart/form-data')) {
  219 |         const respuesta = await route.fetch();
  220 |         const texto = await respuesta.text();
  221 |         const nuevoTexto = simularRechazoAction(texto, 'Contenido inapropiado');
  222 |         await route.fulfill({ response: respuesta, body: nuevoTexto });
  223 |         return;
  224 |       }
  225 |       await route.continue();
  226 |     });
  227 | 
  228 |     const permiso = crearPermisoDeEstacion(fiesta.id, 'plataforma360');
  229 |     await page.goto(`/evento/plataforma-360/${fiesta.id}?access=${permiso}`, { waitUntil: 'domcontentloaded' });
  230 | 
  231 |     const btnGrabar = page.getByRole('button', { name: /grabar video/i }).first();
  232 |     await expect(btnGrabar).toBeVisible({ timeout: 20_000 });
  233 |     await btnGrabar.click();
  234 | 
  235 |     // Debe mostrar el rechazo
  236 |     const avisoError = page.getByText(/contenido inapropiado|no se pudo publicar/i).first();
  237 |     await expect(avisoError).toBeVisible({ timeout: 45_000 });
  238 | 
  239 |     // Y NO debe decir que se sube sola ni que quedó guardado en esta pantalla
  240 |     const textoPagina = (await page.locator('body').innerText()).toLowerCase();
  241 |     expect(textoPagina).not.toMatch(/se sube sola|se subirá cuando vuelva la señal|quedó guardado en esta pantalla/i);
  242 |   });
  243 | });
  244 | 
```