# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: ak207-barra-listo-contraste.spec.ts >> Contraste por píxeles rasterizados (Orden 227) >> pantalla /evento/en-vivo/fiesta-demo mantiene contraste legible mayor a 4.5:1
- Location: tests\e2e\ak207-barra-listo-contraste.spec.ts:68:9

# Error details

```
Tearing down "context" exceeded the test timeout of 90000ms.
```