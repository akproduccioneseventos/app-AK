# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: ak207-la-grilla-de-caras.spec.ts >> Orden 36: La grilla de caras >> la selfie no sale del teléfono ni se manda a la red
- Location: tests\e2e\ak207-la-grilla-de-caras.spec.ts:269:7

# Error details

```
Error: muestra la pantalla de resultados, armada en el propio teléfono

expect(received).toBeGreaterThan(expected)

Expected: > 0
Received:   0
```

# Test source

```ts
  214 | 
  215 |     // Deben haber 2 caras (Ana y Beto, el que pasaba por atrás se filtró)
  216 |     const caritas = grilla.locator('button');
  217 |     await expect(caritas).toHaveCount(2);
  218 | 
  219 |     // REGLA 2: NUNCA un nombre al lado de una cara
  220 |     const textoGrilla = await grilla.innerText();
  221 |     expect(textoGrilla.trim()).toBe(''); // Las caritas no tienen texto
  222 | 
  223 |     // Al tocar una cara se filtran sus fotos y aparece "Descargar todas"
  224 |     await caritas.first().click();
  225 |     await expect(page.getByText(/Fotos de esta persona/i)).toBeVisible();
  226 |     await expect(page.getByRole('button', { name: /Descargar todas/i })).toBeVisible();
  227 | 
  228 |     // Siempre a la vista: "Ver todas las fotos de la fiesta"
  229 |     const botonVerTodas = page.getByRole('button', { name: /Ver todas las fotos de la fiesta/i });
  230 |     await expect(botonVerTodas).toBeVisible();
  231 |     await botonVerTodas.click();
  232 | 
  233 |     // Vuelve a la galería completa
  234 |     await expect(page.getByText(/Fotos de esta persona/i)).toHaveCount(0);
  235 |   });
  236 | 
  237 |   test('con el interruptor apagado no se ve ni la grilla ni el botón', async ({ page }, testInfo) => {
  238 |     test.setTimeout(120_000);
  239 | 
  240 |     await page.goto(`/evento/galeria/${ID_APAGADO}`, { waitUntil: 'domcontentloaded' });
  241 |     await page.waitForTimeout(3000);
  242 | 
  243 |     await expect(page.getByRole('button', { name: /Encontrame/i })).toHaveCount(0);
  244 |     await expect(page.locator('[data-testid="grilla-caras"]')).toHaveCount(0);
  245 |   });
  246 | 
  247 |   test('sin aceptar el permiso, la cámara no se prende y la galería sigue igual', async ({ page }, testInfo) => {
  248 |     test.setTimeout(120_000);
  249 | 
  250 |     await page.goto(`/evento/galeria/${ID_PREPARADA}`, { waitUntil: 'domcontentloaded' });
  251 |     await page.waitForTimeout(3000);
  252 | 
  253 |     const boton = page.getByRole('button', { name: /Encontrame a mí/i });
  254 |     await expect(boton).toBeVisible();
  255 |     await boton.click();
  256 | 
  257 |     // Debe mostrar el cartel de permiso claro
  258 |     await expect(
  259 |       page.getByText(/Vamos a mirar tu cara en este teléfono para buscar tus fotos\. No se guarda ni se manda a ningún lado\./i),
  260 |     ).toBeVisible();
  261 | 
  262 |     // Si cancela, el modal se cierra y la galería sigue igual
  263 |     await page.getByRole('button', { name: /Cancelar/i }).click();
  264 |     await expect(
  265 |       page.getByText(/Vamos a mirar tu cara en este teléfono/i),
  266 |     ).toHaveCount(0);
  267 |   });
  268 | 
  269 |   test('la selfie no sale del teléfono ni se manda a la red', async ({ page }, testInfo) => {
  270 |     test.setTimeout(120_000);
  271 | 
  272 |     await enchufarCamara(page);
  273 | 
  274 |     // Monitoreamos toda llamada de red para verificar que NUNCA viaje una imagen
  275 |     const llamadasConImagenes: string[] = [];
  276 |     page.on('request', (req) => {
  277 |       const url = req.url();
  278 |       const postData = req.postData() || '';
  279 |       if (
  280 |         postData.includes('data:image') ||
  281 |         postData.includes('base64') ||
  282 |         /upload|selfie|face-api|tensor|ai-vision/i.test(url)
  283 |       ) {
  284 |         llamadasConImagenes.push(`${req.method()} ${url}`);
  285 |       }
  286 |     });
  287 | 
  288 |     await page.goto(`/evento/galeria/${ID_PREPARADA}`, { waitUntil: 'domcontentloaded' });
  289 |     await page.waitForTimeout(3000);
  290 | 
  291 |     // Abrir "Encontrame a mí"
  292 |     await page.getByRole('button', { name: /Encontrame a mí/i }).click();
  293 | 
  294 |     // Aceptar permiso
  295 |     await page.getByRole('button', { name: /Entendido, buscar mis fotos/i }).click();
  296 | 
  297 |     // Esperar a que tome los cuadros y cierre el modal
  298 |     await page.waitForTimeout(4000);
  299 | 
  300 |     // LA REGLA MÁS IMPORTANTE: Que no se dispare ninguna llamada al servidor con la imagen
  301 |     expect(llamadasConImagenes, 'la selfie no se envió a ningún servidor externo ni local').toHaveLength(0);
  302 | 
  303 |     // Debe mostrar la vista de resultados o el mensaje de "no encontramos".
  304 |     // Los dos titulos conviven en la pantalla, asi que hay que contar cuantos se
  305 |     // ven y no preguntar por "el" titulo: preguntando de a uno, Playwright corta
  306 |     // por ambiguedad (paso el 4 de septiembre de 2026).
  307 |     const titulos = page.getByRole('heading', {
  308 |       name: /Resultados de tu búsqueda|No encontramos fotos tuyas todavía/i,
  309 |     });
  310 |     let visibles = 0;
  311 |     for (let i = 0; i < (await titulos.count()); i += 1) {
  312 |       if (await titulos.nth(i).isVisible()) visibles += 1;
  313 |     }
> 314 |     expect(visibles, 'muestra la pantalla de resultados, armada en el propio teléfono').toBeGreaterThan(0);
      |                                                                                         ^ Error: muestra la pantalla de resultados, armada en el propio teléfono
  315 |   });
  316 | });
  317 | 
```