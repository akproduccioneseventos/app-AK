# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: ak207-las-pantallas-del-invitado-no-quedan-colgadas.spec.ts >> Las pantallas del invitado no quedan colgadas >> /invitacion/<id>/rsvp no queda colgada si la respuesta del servidor se corta
- Location: tests\e2e\ak207-las-pantallas-del-invitado-no-quedan-colgadas.spec.ts:103:7

# Error details

```
Test timeout of 90000ms exceeded.
```

```
Error: expect(locator).toBeVisible() failed

Locator: getByText(/Error|No se pudo enviar la confirmación/i).first()
Expected: visible
Timeout: 10000ms
Error: element(s) not found

Call log:
  - Expect "toBeVisible" with timeout 10000ms
  - waiting for getByText(/Error|No se pudo enviar la confirmación/i).first()

```

```yaml
- paragraph: Confirmación de asistencia
- heading "Fiesta E2E Pantallas Invitado" [level=1]
- img
- text: Tu nombre completo
- textbox "Tu nombre completo":
  - /placeholder: "Ej: María García"
  - text: Mariana Gómez
- text: 📞 Teléfono de contacto (opcional)
- textbox "📞 Teléfono de contacto (opcional)":
  - /placeholder: "Ej: 099 123 456"
  - text: "099123456"
- text: ¿Vas a asistir?
- button "✅ Sí, voy!"
- button "❌ No puedo ir"
- img
- text: Restricción alimentaria
- radiogroup:
  - radio "🍽️ Sin restricciones" [checked]:
    - img
  - text: 🍽️ Sin restricciones
  - radio "🌾 Celíaco / Sin gluten"
  - text: 🌾 Celíaco / Sin gluten
  - radio "🥗 Vegetariano"
  - text: 🥗 Vegetariano
  - radio "🌱 Vegano"
  - text: 🌱 Vegano
  - radio "⚠️ Otra restricción"
  - text: ⚠️ Otra restricción
- img
- text: ¿Cuántos van? (incluyéndote)
- button "−"
- text: "1"
- button "+"
- img
- text: Sugiere 3 canciones para el DJ
- paragraph: Opcional. ¡Asegúrate de que suenen tus favoritas!
- textbox "Canción 1 – Artista"
- textbox "Canción 2 – Artista"
- textbox "Canción 3 – Artista"
- text: 💌 Dedicatoria o mensaje (opcional)
- textbox "💌 Dedicatoria o mensaje (opcional)":
  - /placeholder: Dejá un mensaje para el festejado/a…
  - text: ¡Felicitaciones! Nos vemos en la fiesta
- checkbox "♿ Necesito asistencia especial / accesibilidad"
- text: ♿ Necesito asistencia especial / accesibilidad
- button "Confirmar asistencia"
- paragraph:
  - text: Tus datos quedan sólo para esta fiesta (Ley 18.331).
  - link "Privacidad":
    - /url: /privacidad
- region "Notifications (F8)":
  - list
- alert
```

# Test source

```ts
  38  |  *
  39  |  * Orden 64 — Bloque 1.
  40  |  */
  41  | import { expect, test } from '@playwright/test';
  42  | import { borrarFiesta, crearFiestaDeEstaNoche, guardarFiesta } from './helpers/fiesta-de-prueba';
  43  | 
  44  | const FIESTA_ID = `e2e_colgadas_${Date.now()}`;
  45  | 
  46  | test.describe('Las pantallas del invitado no quedan colgadas', () => {
  47  |   test.beforeAll(async () => {
  48  |     const fiesta = crearFiestaDeEstaNoche({ id: FIESTA_ID });
  49  |     fiesta.configuracion.nombreEvento = 'Fiesta E2E Pantallas Invitado';
  50  |     guardarFiesta(fiesta);
  51  |   });
  52  | 
  53  |   test.afterAll(async () => {
  54  |     borrarFiesta(FIESTA_ID);
  55  |   });
  56  | 
  57  |   test('/feedback/<id> no queda colgada si la respuesta del servidor se corta', async ({ page }) => {
  58  |     test.setTimeout(90_000);
  59  | 
  60  |     // 1. Abrir la pantalla de feedback
  61  |     await page.goto(`/feedback/${FIESTA_ID}`, { waitUntil: 'domcontentloaded' });
  62  |     await expect(page.locator('#client-name')).toBeVisible({ timeout: 20_000 });
  63  | 
  64  |     // Completar el formulario
  65  |     const nombre = 'Juan Pérez Invitado';
  66  |     const disfrute = 'La comida estuvo excelente y la música impecable';
  67  |     const mejora = 'Más postres en la mesa dulce';
  68  |     const comentarios = 'Muchas gracias por la atención';
  69  | 
  70  |     await page.locator('#client-name').fill(nombre);
  71  |     await page.locator('#enjoyed-most').fill(disfrute);
  72  |     await page.locator('#to-improve').fill(mejora);
  73  |     await page.locator('#general-comments').fill(comentarios);
  74  | 
  75  |     // 2. Cortar la respuesta del servidor en la llamada POST de la acción
  76  |     await page.route(`**/feedback/${FIESTA_ID}*`, async (route) => {
  77  |       if (route.request().method() === 'POST') {
  78  |         await route.abort('failed');
  79  |       } else {
  80  |         await route.continue();
  81  |       }
  82  |     });
  83  | 
  84  |     // 3. Apretar "Enviar Mis Comentarios"
  85  |     const submitBtn = page.getByRole('button', { name: /Enviar Mis Comentarios/i });
  86  |     await expect(submitBtn).toBeEnabled();
  87  |     await submitBtn.click();
  88  | 
  89  |     // 4. El botón vuelve a decir "Enviar Mis Comentarios" (no "Enviando...")
  90  |     await expect(submitBtn).toHaveText(/Enviar Mis Comentarios/i, { timeout: 15_000 });
  91  |     await expect(submitBtn).toBeEnabled();
  92  | 
  93  |     // Aparece el aviso de que no se pudo enviar
  94  |     await expect(page.getByText('No se pudieron enviar tus comentarios').first()).toBeVisible({ timeout: 10_000 });
  95  | 
  96  |     // 5. Lo que escribió el invitado sigue en los campos: no se perdió
  97  |     await expect(page.locator('#client-name')).toHaveValue(nombre);
  98  |     await expect(page.locator('#enjoyed-most')).toHaveValue(disfrute);
  99  |     await expect(page.locator('#to-improve')).toHaveValue(mejora);
  100 |     await expect(page.locator('#general-comments')).toHaveValue(comentarios);
  101 |   });
  102 | 
  103 |   test('/invitacion/<id>/rsvp no queda colgada si la respuesta del servidor se corta', async ({ page }) => {
  104 |     test.setTimeout(90_000);
  105 | 
  106 |     // 1. Abrir la pantalla de RSVP
  107 |     await page.goto(`/invitacion/${FIESTA_ID}/rsvp`, { waitUntil: 'domcontentloaded' });
  108 |     await expect(page.locator('#nombre')).toBeVisible({ timeout: 20_000 });
  109 | 
  110 |     // Completar los campos
  111 |     const nombre = 'Mariana Gómez';
  112 |     const contacto = '099123456';
  113 |     const mensaje = '¡Felicitaciones! Nos vemos en la fiesta';
  114 | 
  115 |     await page.locator('#nombre').fill(nombre);
  116 |     await page.locator('#contacto').fill(contacto);
  117 |     await page.locator('#mensaje').fill(mensaje);
  118 | 
  119 |     // 2. Cortar la respuesta del servidor en la llamada POST
  120 |     await page.route(`**/invitacion/${FIESTA_ID}/rsvp*`, async (route) => {
  121 |       if (route.request().method() === 'POST') {
  122 |         await route.abort('failed');
  123 |       } else {
  124 |         await route.continue();
  125 |       }
  126 |     });
  127 | 
  128 |     // 3. Apretar "Confirmar asistencia"
  129 |     const btnConfirmar = page.getByRole('button', { name: /Confirmar asistencia/i });
  130 |     await expect(btnConfirmar).toBeEnabled();
  131 |     await btnConfirmar.click();
  132 | 
  133 |     // 4. El botón vuelve a decir "Confirmar asistencia" (no "Enviando…")
  134 |     await expect(btnConfirmar).toHaveText(/Confirmar asistencia/i, { timeout: 15_000 });
  135 |     await expect(btnConfirmar).toBeEnabled();
  136 | 
  137 |     // Aparece el aviso de error
> 138 |     await expect(page.getByText(/Error|No se pudo enviar la confirmación/i).first()).toBeVisible({ timeout: 10_000 });
      |                                                                                      ^ Error: expect(locator).toBeVisible() failed
  139 | 
  140 |     // 5. Lo que escribió el invitado sigue en los campos: no se perdió
  141 |     await expect(page.locator('#nombre')).toHaveValue(nombre);
  142 |     await expect(page.locator('#contacto')).toHaveValue(contacto);
  143 |     await expect(page.locator('#mensaje')).toHaveValue(mensaje);
  144 |   });
  145 | });
  146 | 
```