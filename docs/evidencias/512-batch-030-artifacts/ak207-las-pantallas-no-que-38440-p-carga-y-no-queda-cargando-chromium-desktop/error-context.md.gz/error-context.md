# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: ak207-las-pantallas-no-quedan-cargando.spec.ts >> Las pantallas no quedan cargando (Orden 226) >> settings whatsapp carga y no queda cargando
- Location: tests\e2e\ak207-las-pantallas-no-quedan-cargando.spec.ts:78:7

# Error details

```
Error: expect(locator).toContainText(expected) failed

Locator: getByRole('heading', { name: /integración whatsapp/i })
Expected pattern: /integración whatsapp/i
Timeout: 15000ms
Error: element(s) not found

Call log:
  - Expect "toContainText" with timeout 15000ms
  - waiting for getByRole('heading', { name: /integración whatsapp/i })

```

```yaml
- link:
  - /url: /admin
- list:
  - listitem:
    - link "Centro de Control":
      - /url: /admin
      - img
      - text: Centro de Control
- text: Mi Día ☀️
- list:
  - listitem:
    - link "Mi Día":
      - /url: /mi-dia
      - img
      - text: Mi Día
- text: Fiestas 🎉
- list:
  - listitem:
    - link "Eventos Activos":
      - /url: /eventos
      - img
      - text: Eventos Activos
  - listitem:
    - link "Calendario":
      - /url: /calendario
      - img
      - text: Calendario
  - listitem:
    - link "Muro Social":
      - /url: /empresa/red-social-eventos
      - img
      - text: Muro Social
  - listitem:
    - link "Incidentes":
      - /url: /incidentes
      - img
      - text: Incidentes
  - listitem:
    - link "Guias de Armado":
      - /url: /playbooks
      - img
      - text: Guias de Armado
  - listitem:
    - link "Alergias y Dietas":
      - /url: /fiestas/nueva/alergias
      - img
      - text: Alergias y Dietas
  - listitem:
    - link "Portal de Proveedores":
      - /url: /fiestas/nueva/proveedores-portal
      - img
      - text: Portal de Proveedores
- text: La Empresa 🏢
- list:
  - listitem:
    - link "Gestión de Empresa":
      - /url: /empresa
      - img
      - text: Gestión de Empresa
  - text: Vender
  - listitem:
    - link "Simulador IA":
      - /url: /simulador-ak
      - img
      - text: Simulador IA
  - text: Recursos
  - listitem:
    - link "Salones":
      - /url: /empresa/salones
      - img
      - text: Salones
  - listitem:
    - link "Catálogo de Servicios":
      - /url: /empresa/servicios
      - img
      - text: Catálogo de Servicios
  - text: Marketing
  - listitem:
    - link "Presentación LED":
      - /url: /empresa/presentacion-led/configuracion
      - img
      - text: Presentación LED
- text: Configuración ⚙️
- list:
  - listitem:
    - link "Seguridad":
      - /url: /settings/account
      - img
      - text: Seguridad
- list:
  - listitem:
    - link "Alertas":
      - /url: /alertas
      - img
      - text: Alertas
- main:
  - heading "AK Producciones" [level=1]
  - link "Ingreso/Egreso Rápido":
    - /url: /pagos-rapidos
    - button "Ingreso/Egreso Rápido":
      - img
      - text: Ingreso/Egreso Rápido
  - button "Abrir notificaciones":
    - img
    - text: Abrir notificaciones
  - button
  - main:
    - img
- navigation "Navegacion del modulo":
  - button "Volver":
    - img
  - button "Ir al panel principal":
    - img
- button "Abrir Asistente IA AK":
  - img
- button "Mover el asistente":
  - img
- button "CTO Sistema, backup y sincronizaciones":
  - img
  - text: CTO Sistema, backup y sincronizaciones
- link "Personalizar asistentes":
  - /url: /settings/asistentes-contextuales
  - img
- link "Ver sincronizaciones":
  - /url: /settings/sincronizaciones
  - img
- button "Minimizar el asistente":
  - img
- region "Notifications (F8)":
  - list
- alert
```

```
Tearing down "context" exceeded the test timeout of 90000ms.
```