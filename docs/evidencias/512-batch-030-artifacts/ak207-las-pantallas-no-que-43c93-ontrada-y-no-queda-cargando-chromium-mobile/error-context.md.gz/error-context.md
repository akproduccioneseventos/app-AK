# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: ak207-las-pantallas-no-quedan-cargando.spec.ts >> Las pantallas no quedan cargando (Orden 226) >> modulo-invitado con fiesta inexistente muestra Fiesta no encontrada y no queda cargando
- Location: tests\e2e\ak207-las-pantallas-no-quedan-cargando.spec.ts:57:7

# Error details

```
Error: expect(locator).toContainText(expected) failed

Locator: getByRole('heading', { name: /fiesta no encontrada/i })
Expected pattern: /fiesta no encontrada/i
Timeout: 15000ms
Error: element(s) not found

Call log:
  - Expect "toContainText" with timeout 15000ms
  - waiting for getByRole('heading', { name: /fiesta no encontrada/i })

```

```yaml
- main:
  - button "Abrir menu lateral":
    - img
    - text: Toggle Sidebar
  - img
  - heading "AK Producciones" [level=1]
  - link:
    - /url: /pagos-rapidos
  - link:
    - /url: /pagos-rapidos
    - button:
      - img
  - button "Abrir notificaciones":
    - img
    - text: Abrir notificaciones
  - button
  - main:
    - img
- navigation "Navegacion del modulo":
  - button "Volver":
    - img
  - button "Ir al panel principal":
    - img
- button "Abrir Asistente IA AK":
  - img
- region "Notifications (F8)":
  - list
- alert
```

```
Tearing down "context" exceeded the test timeout of 90000ms.
```