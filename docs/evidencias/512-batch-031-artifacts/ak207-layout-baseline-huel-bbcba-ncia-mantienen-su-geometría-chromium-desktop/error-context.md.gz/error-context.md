# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: ak207-layout-baseline.spec.ts >> huella de maquetación >> las pantallas de referencia mantienen su geometría
- Location: tests\e2e\ak207-layout-baseline.spec.ts:153:7

# Error details

```
Error: La maquetación cambió:
  /admin · colores: era 2034977308, ahora 1190975077
  /customers · colores: era 2034977308, ahora 1190975077
  /presupuestos/nuevo · h1W: era 212, ahora 216
  /presupuestos/nuevo · colores: era 2034977308, ahora 1190975077
  /fiestas/nueva/portal-cliente · colores: era 2034977308, ahora 1190975077
  /contabilidad/comercial-360 · colores: era 2034977308, ahora 1190975077

expect(received).toEqual(expected) // deep equality

- Expected  - 1
+ Received  + 8

- Array []
+ Array [
+   "/admin · colores: era 2034977308, ahora 1190975077",
+   "/customers · colores: era 2034977308, ahora 1190975077",
+   "/presupuestos/nuevo · h1W: era 212, ahora 216",
+   "/presupuestos/nuevo · colores: era 2034977308, ahora 1190975077",
+   "/fiestas/nueva/portal-cliente · colores: era 2034977308, ahora 1190975077",
+   "/contabilidad/comercial-360 · colores: era 2034977308, ahora 1190975077",
+ ]
```

# Test source

```ts
  155 | 
  156 |     await context.addInitScript(() => {
  157 |       window.localStorage.setItem('ak_session', 'true');
  158 |       window.sessionStorage.setItem('ak_session', 'true');
  159 |     });
  160 |     await context.addCookies([
  161 |       { name: 'ak_session', value: createSessionToken(), url: baseURL!, httpOnly: true, sameSite: 'Lax' },
  162 |     ]);
  163 | 
  164 |     // La geometria depende del tamano de pantalla, asi que cada perfil de
  165 |     // Playwright (escritorio y celular) guarda su propia referencia.
  166 |     const perfil = test.info().project.name;
  167 |     const clave = (ruta: string) => `${perfil} ${ruta}`;
  168 | 
  169 |     const referencia = leerReferencia();
  170 |     const actual: Record<string, Huella> = {};
  171 |     const referenciasFaltantes: Record<string, Huella> = {};
  172 |     const desvios: string[] = [];
  173 |     /** Fallas que valen aunque la referencia diga que "siempre fue asi". */
  174 |     const absolutos: string[] = [];
  175 | 
  176 |     for (const { ruta } of RUTAS) {
  177 |       const response = await page.goto(ruta, { waitUntil: 'domcontentloaded' });
  178 |       expect(response?.status(), `${ruta} devolvio una respuesta invalida`).toBeLessThan(400);
  179 |       expect(new URL(page.url()).pathname, `${ruta} redirigio inesperadamente`).toBe(ruta);
  180 |       await page.waitForLoadState('networkidle', { timeout: 5_000 }).catch(() => {});
  181 |       if (ruta === '/presentacion-led') {
  182 |         await expect(page.getByText(/Cargando presentaci/i)).toBeHidden({ timeout: 45_000 });
  183 |       }
  184 |       // Las pantallas del panel traen datos del servidor antes de dibujar el
  185 |       // titulo. Con el servidor despertandose, 2,5 segundos no alcanzaban y la
  186 |       // prueba avisaba "la ruta no existe o no carga" con la pantalla sana.
  187 |       await page.locator('h1, main, header').first().waitFor({ state: 'visible', timeout: 60_000 }).catch(() => {});
  188 |       /**
  189 |        * ANTES DE MEDIR, ESPERAR A QUE LAS LETRAS ESTEN CARGADAS.
  190 |        *
  191 |        * **Esto dio una falsa alarma el 9 de septiembre de 2026.** La pantalla de la
  192 |        * presentacion acuso ocho pixeles de corrimiento en el titular; abierta sola,
  193 |        * estaba perfecta. Con la maquina cargada, la tipografia termina de cargar
  194 |        * DESPUES de la medicion, y el titular se acomoda unos pixeles: se estaba
  195 |        * midiendo la pagina a medio vestir.
  196 |        *
  197 |        * Esperar a las letras no afloja el control: lo hace medir lo que el usuario
  198 |        * ve de verdad, en vez de una foto sacada antes de tiempo.
  199 |        */
  200 |       await page.evaluate(() => (document as any).fonts?.ready).catch(() => {});
  201 |       await page.waitForTimeout(2500);
  202 |       const huella = await medirHuella(page);
  203 |       actual[clave(ruta)] = huella;
  204 | 
  205 |       // Reglas absolutas: no dependen de la referencia. Sin esto, la referencia
  206 |       // congelaba defectos como si fueran lo normal (paso de verdad: el catalogo
  207 |       // se salia 54px en celular y la prueba lo daba por bueno porque "no habia
  208 |       // cambiado").
  209 |       if (huella.desborde > 2) {
  210 |         absolutos.push(`${ruta} · se sale ${huella.desborde}px a lo ancho`);
  211 |       }
  212 |       if (huella.h1W === -1 && huella.mainX === -1) {
  213 |         absolutos.push(`${ruta} · no tiene ni titulo ni contenido: la ruta no existe o no carga`);
  214 |       }
  215 | 
  216 |       const esperado = referencia[clave(ruta)];
  217 |       if (!esperado) {
  218 |         referenciasFaltantes[clave(ruta)] = actual[clave(ruta)];
  219 |         if (!ACTUALIZAR_REFERENCIAS_FALTANTES) desvios.push(`${ruta} · falta referencia para ${perfil}`);
  220 |         continue;
  221 |       }
  222 | 
  223 |       for (const [medida, valor] of Object.entries(actual[clave(ruta)])) {
  224 |         const antes = esperado[medida];
  225 |         if (typeof antes !== 'number') continue;
  226 |         // El desborde es exacto; las medidas geométricas admiten redondeo.
  227 |         const margen = medida === 'desborde' ? 0 : TOLERANCIA;
  228 |         if (Math.abs(valor - antes) > margen) {
  229 |           desvios.push(`${ruta} · ${medida}: era ${antes}, ahora ${valor}`);
  230 |         }
  231 |       }
  232 |     }
  233 | 
  234 |     // Si se activo la actualizacion de referencias faltantes, se persisten en disco
  235 |     if (Object.keys(referenciasFaltantes).length > 0 && ACTUALIZAR_REFERENCIAS_FALTANTES) {
  236 |       const nuevaReferencia = { ...referencia, ...referenciasFaltantes };
  237 |       fs.writeFileSync(REFERENCIA, `${JSON.stringify(nuevaReferencia, null, 2)}\n`);
  238 |       test.info().annotations.push({
  239 |         type: 'referencia',
  240 |         description: `Se agregaron ${Object.keys(referenciasFaltantes).length} referencias faltantes para ${perfil}.`,
  241 |       });
  242 |     }
  243 | 
  244 |     // Primera corrida (o referencia borrada a proposito): se genera la referencia
  245 |     // pero las reglas absolutas se exigen igual, para no grabar un defecto.
  246 |     const faltaEsteperfil = !Object.keys(referencia).some((k) => k.startsWith(`${perfil} `));
  247 |     if (Object.keys(referencia).length === 0 || faltaEsteperfil) {
  248 |       fs.writeFileSync(REFERENCIA, `${JSON.stringify({ ...referencia, ...actual }, null, 2)}\n`);
  249 |       test.info().annotations.push({ type: 'referencia', description: `Huella generada para ${perfil}.` });
  250 |       expect(absolutos, `Pantallas con defectos propios:\n  ${absolutos.join('\n  ')}`).toEqual([]);
  251 |       return;
  252 |     }
  253 | 
  254 |     expect(absolutos, `Pantallas con defectos propios:\n  ${absolutos.join('\n  ')}`).toEqual([]);
> 255 |     expect(desvios, `La maquetación cambió:\n  ${desvios.join('\n  ')}`).toEqual([]);
      |                                                                          ^ Error: La maquetación cambió:
  256 |   });
  257 | });
  258 | 
```