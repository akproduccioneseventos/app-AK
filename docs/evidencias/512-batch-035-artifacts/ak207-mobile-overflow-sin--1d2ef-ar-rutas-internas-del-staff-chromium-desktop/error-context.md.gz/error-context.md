# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: ak207-mobile-overflow.spec.ts >> sin desborde horizontal en celular >> rutas internas del staff
- Location: tests\e2e\ak207-mobile-overflow.spec.ts:80:7

# Error details

```
Test timeout of 300000ms exceeded.
```