# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: ak207-muro-subir-foto.spec.ts >> el invitado sube una foto al muro >> encuentra cómo compartir y, si falla, se entera
- Location: tests\e2e\ak207-muro-subir-foto.spec.ts:70:7

# Error details

```
Error: El invitado tocó publicar y no recibió ninguna respuesta: no sabe si su foto salió o no

expect(locator).toBeVisible() failed

Locator: getByText(/No se pudo publicar|publicada|Se subió|subida/i).first()
Expected: visible
Timeout: 45000ms
Error: element(s) not found

Call log:
  - El invitado tocó publicar y no recibió ninguna respuesta: no sabe si su foto salió o no with timeout 45000ms
  - waiting for getByText(/No se pudo publicar|publicada|Se subió|subida/i).first()

```

```yaml
- banner:
  - heading "Muro social de Valentina" [level=1]
  - paragraph: Hola, Lucía Fernández
  - 'link "Mi mesa: buscar dónde me siento"':
    - /url: /evento/mi-mesa/e2e_muro_1792903262344?guestId=inv_prueba_0&token=token-prueba-0
    - img
    - text: Mi Mesa
  - button "Actualizar":
    - img
- navigation:
  - button "Inicio" [pressed]:
    - img
    - text: Inicio
  - button "Cronograma":
    - img
    - text: Cronograma
  - button "Ranking":
    - img
    - text: Ranking
  - button "Misiones":
    - img
    - text: Misiones
  - button "Canciones":
    - img
    - text: Canciones
  - button "Mensajes":
    - img
    - text: Mensajes
  - button "Chat":
    - img
    - text: Chat
- main:
  - img
  - text: ¿Cuándo cumplís tus quince?
  - button "Cerrar pregunta de 15":
    - img
  - button "Ya los festejé"
  - button "Este año"
  - button "El año que viene"
  - button "No es lo mío"
  - text: ¿Querés guardar el enlace de tus fotos? Para volver a ver tu recuerdo y video mañana.
  - link "Mandármelo por WhatsApp":
    - /url: https://wa.me/?text=%C2%A1Hola!%20Guard%C3%A1%20este%20enlace%20para%20ver%20tus%20fotos%20y%20el%20video%20recuerdo%20de%20la%20fiesta%20ma%C3%B1ana%3A%20http%3A%2F%2F127.0.0.1%3A3300%2Finvitacion%2Fe2e_muro_1792903262344%2Frecap%3FguestId%3Dinv_prueba_0%26token%3Dtoken-prueba-0
    - img
    - text: Mandármelo por WhatsApp
  - text: LF
  - button "¿Qué querés compartir?"
  - button "Foto":
    - img
    - text: Foto
  - button "Video":
    - img
    - text: Video
  - img
  - paragraph: Todavía no hay publicaciones
  - paragraph: Sé la primera persona en compartir un momento de la fiesta.
  - button "Subí tu primera foto"
  - paragraph: Todo lo que subas aparece también en la pantalla grande del salón.
  - link "¿Te toca festejar el año que viene? Mirá cuánto sale tu fiesta":
    - /url: /simulador-de-presupuesto?source=guest_portal&campaign=muro_social&refFiesta=e2e_muro_1792903262344
  - button "👏"
  - button "❤️"
  - button "🔥"
- region "Notifications (F8)":
  - list
- alert
```

# Test source

```ts
  15  |  if(process.env.FIRESTORE_EMULATOR_HOST!=='127.0.0.1:8085')throw new Error('SDK509 emulator-only');
  16  |  const cleared=await fetch('http://127.0.0.1:8085/emulator/v1/projects/demo-ak-producciones/databases/(default)/documents',{method:'DELETE'});if(cleared.status!==200)throw new Error('QA509 clear failed');
  17  |  let batch=__db509.batch(),count=0;
  18  |  const set=async(ref,data)=>{batch.set(ref,data);if(++count===350){await batch.commit();batch=__db509.batch();count=0;}};
  19  |  for(const descriptor of __catalogue509){
  20  |   const item={...descriptor};const paths=['data','src/data'].map(folder=>path509.join(process.cwd(),folder,item.file)).filter(p=>fs509.existsSync(p)).sort((a,b)=>fs509.statSync(b).mtimeMs-fs509.statSync(a).mtimeMs);if(paths.length)item.data=JSON.parse(fs509.readFileSync(paths[0],'utf8'));
  21  | 
  22  |   await set(__db509.collection('json_documents').doc(encodeURIComponent(item.file)),{_filePath:item.file,...(Array.isArray(item.data)?{_arrayData:item.data}:{_data:item.data})});
  23  |   if(item.config)await set(__db509.collection('configuracion').doc(item.config),item.data);
  24  |   if(item.collection&&Array.isArray(item.data))for(const[rowIndex,row]of item.data.entries())await set(__db509.collection(item.collection).doc(String(row.id||'qa509-'+rowIndex)),row);
  25  |  }
  26  |  const folder=path509.join(process.cwd(),'data/fiestas');if(fs509.existsSync(folder))for(const name of fs509.readdirSync(folder))if(/^.*\.json$/.test(name)){const f=JSON.parse(fs509.readFileSync(path509.join(folder,name),'utf8'));await set(__db509.collection('fiestas').doc(f.id),f);}
  27  |  const meta=path509.join(process.cwd(),'data/social-gallery/metadata.json');if(fs509.existsSync(meta))for(const row of JSON.parse(fs509.readFileSync(meta,'utf8')))await set(__db509.collection('social_gallery_posts').doc(row.id),row);
  28  |  if(count)await batch.commit();
  29  | });
  30  | __akAudit207.afterEach(async({},info)=>{const result={budgets:[],leads:[]};for(const[name,key]of[['presupuestos','budgets'],['prospectos','leads']]){const rows=await __db509.collection(name).get();result[key]=rows.docs.map(d=>({id:d.id,nombre:d.data().clienteNombre||d.data().nombre||d.data().name,total:d.data().totalFinal||d.data().total||d.data().totalAmount}));}await info.attach('qa509-sdk-persistence',{contentType:'application/json',body:Buffer.from(JSON.stringify(result))});});
  31  | __akAudit207.afterAll(async()=>{await __db509.terminate();await __app509.deleteApp(__instance509);});
  32  | import { expect, test } from '@playwright/test';
  33  | import { borrarFiesta, crearFiestaDeEstaNoche } from './helpers/fiesta-de-prueba';
  34  | 
  35  | /**
  36  |  * El invitado subiendo una foto al muro, hasta donde se puede probar acá.
  37  |  *
  38  |  * La foto termina guardándose en el servicio de archivos de Firebase, que no
  39  |  * existe en este entorno. Eso deja **una sola cosa** sin probar: que los bytes
  40  |  * lleguen al servidor de Google.
  41  |  *
  42  |  * Todo lo anterior sí se prueba, y es donde estaban los problemas: que el
  43  |  * invitado encuentre el botón, que pueda poner su nombre, que elija una foto, y
  44  |  * sobre todo que **si algo falla se entere**. Un muro que se traga la foto sin
  45  |  * decir nada es peor que uno que avisa: el invitado se queda esperando que
  46  |  * aparezca en la pantalla del salón y nunca aparece.
  47  |  */
  48  | 
  49  | const fiesta = crearFiestaDeEstaNoche({ id: `e2e_muro_${Date.now()}` });
  50  | const ID = fiesta.id;
  51  | 
  52  | /** Un invitado de la lista, con su enlace personal. */
  53  | const INVITADO = { id: 'inv_prueba_0', token: 'token-prueba-0' };
  54  | 
  55  | /** Una imagen mínima de verdad, para que el navegador la trate como foto. */
  56  | const FOTO_DE_PRUEBA = {
  57  |   name: 'foto-de-prueba.png',
  58  |   mimeType: 'image/png',
  59  |   buffer: Buffer.from(
  60  |     'iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR42mP8z8BQDwAEhQGAhKmMIQAAAABJRU5ErkJggg==',
  61  |     'base64',
  62  |   ),
  63  | };
  64  | 
  65  | test.afterAll(() => {
  66  |   borrarFiesta(ID);
  67  | });
  68  | 
  69  | test.describe('el invitado sube una foto al muro', () => {
  70  |   test('encuentra cómo compartir y, si falla, se entera', async ({ page }) => {
  71  |     test.setTimeout(300_000);
  72  | 
  73  |     const erroresJs: string[] = [];
  74  |     page.on('pageerror', (e) => erroresJs.push(e.message));
  75  | 
  76  |     // Se entra con el enlace personal del invitado, que es como llega de verdad:
  77  |     // sin él, el muro sólo deja mirar y avisa "abrí tu enlace personal para
  78  |     // publicar".
  79  |     await page.goto(`/evento/social/${ID}?guestId=${INVITADO.id}&token=${INVITADO.token}`, {
  80  |       waitUntil: 'domcontentloaded',
  81  |     });
  82  | 
  83  |     // Al entrar por primera vez, el muro pide el nombre: es lo que después
  84  |     // aparece debajo de la foto en la pantalla del salón.
  85  |     const campoNombre = page.getByPlaceholder(/Ej: Sofía Pérez|Tu nombre/i).first();
  86  |     if (await campoNombre.isVisible().catch(() => false)) {
  87  |       await campoNombre.fill('Invitada de prueba');
  88  |       await page.getByRole('button', { name: /Continuar|Entrar|Listo/i }).first().click();
  89  |       await page.waitForTimeout(2000);
  90  |     }
  91  | 
  92  |     // El botón para compartir tiene que estar a la vista, sin buscarlo.
  93  |     const compartir = page.getByText(/Qué querés compartir/i).first();
  94  |     await expect(compartir, 'El invitado no encuentra cómo subir una foto').toBeVisible({ timeout: 45_000 });
  95  |     await compartir.click();
  96  |     await page.waitForTimeout(1500);
  97  | 
  98  |     // Elige una foto de su celular.
  99  |     const campoArchivo = page.locator('input[type="file"]').first();
  100 |     await expect(campoArchivo, 'No hay dónde elegir la foto').toHaveCount(1, { timeout: 20_000 });
  101 |     await campoArchivo.setInputFiles(FOTO_DE_PRUEBA);
  102 |     await page.waitForTimeout(2000);
  103 | 
  104 |     const publicar = page.getByRole('button', { name: /^Publicar/i }).first();
  105 |     await expect(publicar, 'No aparece el botón de publicar').toBeVisible({ timeout: 20_000 });
  106 |     await publicar.click();
  107 | 
  108 |     // Lo que importa: pase lo que pase, el invitado tiene que recibir una
  109 |     // respuesta. En este entorno el guardado falla porque no hay servicio de
  110 |     // archivos, así que lo correcto es ver el aviso de que no se pudo.
  111 |     const respuesta = page.getByText(/No se pudo publicar|publicada|Se subió|subida/i).first();
  112 |     await expect(
  113 |       respuesta,
  114 |       'El invitado tocó publicar y no recibió ninguna respuesta: no sabe si su foto salió o no',
> 115 |     ).toBeVisible({ timeout: 45_000 });
      |       ^ Error: El invitado tocó publicar y no recibió ninguna respuesta: no sabe si su foto salió o no
  116 | 
  117 |     expect(erroresJs, `El muro tuvo fallas de JavaScript:\n${erroresJs.join('\n')}`).toEqual([]);
  118 |   });
  119 | 
  120 |   test('el muro no se cuelga después de un intento fallido', async ({ page }) => {
  121 |     test.setTimeout(180_000);
  122 | 
  123 |     // Después de un error, la pantalla tiene que seguir usable: el invitado
  124 |     // suele probar de nuevo.
  125 |     await page.goto(`/evento/social/${ID}`, { waitUntil: 'domcontentloaded' });
  126 | 
  127 |     // El muro pide varias cosas al servidor antes de dibujarse; se le da el
  128 |     // mismo margen que en la fiesta real.
  129 |     let texto = '';
  130 |     const arranque = Date.now();
  131 |     while (Date.now() - arranque < 20_000) {
  132 |       texto = await page.locator('body').innerText().catch(() => '');
  133 |       if (texto.trim().length > 40) break;
  134 |       await page.waitForTimeout(1000);
  135 |     }
  136 | 
  137 |     expect(texto.trim().length, 'El muro quedó en blanco').toBeGreaterThan(40);
  138 |     expect(texto).not.toMatch(/NaN|Infinity|\[object Object\]|Failed to fetch/);
  139 |   });
  140 | });
  141 | 
```