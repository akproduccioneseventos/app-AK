# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: ak207-noche-de-fiesta.spec.ts >> noche de fiesta >> las pantallas del invitado funcionan con una fiesta real
- Location: tests\e2e\ak207-noche-de-fiesta.spec.ts:223:7

# Error details

```
Error: Pantallas del invitado con problemas:
  /feedback/e2e_noche_1792903367763 → tardó 22 segundos en mostrar algo

expect(received).toEqual(expected) // deep equality

- Expected  - 1
+ Received  + 6

- Array []
+ Array [
+   Object {
+     "problema": "tardó 22 segundos en mostrar algo",
+     "ruta": "/feedback/e2e_noche_1792903367763",
+   },
+ ]
```

# Test source

```ts
  129 |     if (texto.trim().length >= 40) break;
  130 |     await page.waitForTimeout(1000);
  131 |   }
  132 |   const segundos = Math.round((Date.now() - arranque) / 1000);
  133 |   if (texto.trim().length >= 40 && segundos > 12) {
  134 |     problemas.push({ ruta, problema: `tardó ${segundos} segundos en mostrar algo` });
  135 |   }
  136 | 
  137 |   for (const senal of SENALES_DE_FALLA) {
  138 |     if (senal.test(texto)) {
  139 |       problemas.push({ ruta, problema: `dice "${texto.match(senal)?.[0]}"` });
  140 |       break;
  141 |     }
  142 |   }
  143 | 
  144 |   // Una pantalla de la fiesta que después de 20 segundos sigue sin texto está
  145 |   // colgada: el invitado ve una ruedita girando y nada más.
  146 |   if (texto.trim().length < 40) {
  147 |     problemas.push({ ruta, problema: `sigue vacía después de ${segundos} segundos` });
  148 |   }
  149 | 
  150 |   // Desborde horizontal: en la fiesta todo se usa desde el celular.
  151 |   const desborde = await page.evaluate(() => document.documentElement.scrollWidth - document.documentElement.clientWidth);
  152 |   if (desborde > 2) {
  153 |     problemas.push({ ruta, problema: `se sale ${desborde}px de la pantalla` });
  154 |   }
  155 | 
  156 |   if (erroresJs.length > 0) {
  157 |     problemas.push({ ruta, problema: `falla de JavaScript: ${erroresJs[0]}` });
  158 |   }
  159 | 
  160 |   page.off('pageerror', onError);
  161 |   return problemas;
  162 | }
  163 | 
  164 | async function revisarPantallas(context: BrowserContext, rutas: string[]): Promise<Resultado[]> {
  165 |   const problemas: Resultado[] = [];
  166 |   for (const ruta of rutas) {
  167 |     const page = await context.newPage();
  168 |     try {
  169 |       problemas.push(...(await revisarPantalla(page, ruta)));
  170 |     } finally {
  171 |       await page.close();
  172 |     }
  173 |   }
  174 |   return problemas;
  175 | }
  176 | 
  177 | /** Lo que abre el invitado desde su celular durante la fiesta. */
  178 | const INVITADO = { id: 'inv_prueba_0', token: 'token-prueba-0' };
  179 | 
  180 | const PANTALLAS_DEL_INVITADO = [
  181 |   `/evento/hub/${ID}?guestId=${INVITADO.id}&token=${INVITADO.token}`,
  182 |   `/evento/mi-mesa/${ID}`,
  183 |   `/evento/social/${ID}?guestId=${INVITADO.id}&token=${INVITADO.token}`,
  184 |   `/evento/social/${ID}?estacion=totems&access=${crearPermisoDeEstacion(ID, 'totems')}`,
  185 |   `/evento/galeria/${ID}`,
  186 |   `/evento/barra/${ID}`,
  187 |   `/evento/zona-digital/${ID}`,
  188 |   // Las estaciones se abren con el permiso que lleva el QR del salón, igual que
  189 |   // en una fiesta real. Sin él la app tiene que negar el acceso, no fallar.
  190 |   `/evento/buzon/${ID}?access=${crearPermisoDeEstacion(ID, 'capsulaTiempo')}`,
  191 |   `/evento/fotocabina/${ID}?access=${crearPermisoDeEstacion(ID, 'fotocabina')}`,
  192 |   `/evento/plataforma-360/${ID}?access=${crearPermisoDeEstacion(ID, 'plataforma360')}`,
  193 |   `/evento/touchpix/${ID}?access=${crearPermisoDeEstacion(ID, 'espejoMagicoIA')}`,
  194 |   `/evento/espejo-magico/${ID}?access=${crearPermisoDeEstacion(ID, 'espejoMagicoFirma')}`,
  195 |   `/evento/bogue/${ID}?access=${crearPermisoDeEstacion(ID, 'bogue')}`,
  196 |   `/evento/en-vivo/${ID}/invitados`,
  197 |   `/invitacion/${ID}`,
  198 |   `/invitacion/${ID}/rsvp`,
  199 |   `/portal-invitado/${ID}/${INVITADO.id}?token=${INVITADO.token}`,
  200 |   `/feedback/${ID}`,
  201 |   // La familia sube acá las fotos del video de vida.
  202 |   `/video-vida/${ID}`,
  203 | ];
  204 | 
  205 | /** Lo que maneja el equipo de AK durante la fiesta. */
  206 | const PANTALLAS_DEL_EQUIPO = [
  207 |   `/fiestas/${ID}/centro`,
  208 |   `/evento/muro-en-vivo/${ID}`,
  209 |   `/evento/en-vivo/${ID}/pantalla`,
  210 |   `/evento/en-vivo/${ID}/organizador`,
  211 |   `/evento/barra/${ID}/barman`,
  212 |   `/evento/barra/${ID}/stats`,
  213 |   // Estas dos piden sesión del equipo, no son del invitado.
  214 |   `/evento/dj/${ID}`,
  215 |   `/evento/video-vida/${ID}`,
  216 |   `/evento/logistica/${ID}`,
  217 |   `/evento/moderacion/${ID}`,
  218 |   `/evento/accesos/${ID}`,
  219 |   `/evento/impresion/${ID}`,
  220 | ];
  221 | 
  222 | test.describe('noche de fiesta', () => {
  223 |   test('las pantallas del invitado funcionan con una fiesta real', async ({ context }) => {
  224 |     test.setTimeout(900_000);
  225 |     const problemas = await revisarPantallas(context, PANTALLAS_DEL_INVITADO);
  226 |     expect(
  227 |       problemas,
  228 |       `Pantallas del invitado con problemas:\n  ${problemas.map((p) => `${p.ruta} → ${p.problema}`).join('\n  ')}`,
> 229 |     ).toEqual([]);
      |       ^ Error: Pantallas del invitado con problemas:
  230 |   });
  231 | 
  232 |   test('las pantallas del equipo funcionan con una fiesta real', async ({ context, baseURL }) => {
  233 |     test.setTimeout(900_000);
  234 |     await context.addInitScript(() => {
  235 |       window.localStorage.setItem('ak_session', 'true');
  236 |       window.sessionStorage.setItem('ak_session', 'true');
  237 |     });
  238 |     await context.addCookies([
  239 |       { name: 'ak_session', value: crearCookieDeSesion(), url: baseURL!, httpOnly: true, sameSite: 'Lax' },
  240 |     ]);
  241 | 
  242 |     const problemas = await revisarPantallas(context, PANTALLAS_DEL_EQUIPO);
  243 |     expect(
  244 |       problemas,
  245 |       `Pantallas del equipo con problemas:\n  ${problemas.map((p) => `${p.ruta} → ${p.problema}`).join('\n  ')}`,
  246 |     ).toEqual([]);
  247 |   });
  248 | 
  249 |   test('el control de entrada marca el ingreso de un invitado', async ({ page, context, baseURL }) => {
  250 |     test.setTimeout(180_000);
  251 |     await context.addInitScript(() => {
  252 |       window.localStorage.setItem('ak_session', 'true');
  253 |       window.sessionStorage.setItem('ak_session', 'true');
  254 |     });
  255 |     await context.addCookies([
  256 |       { name: 'ak_session', value: crearCookieDeSesion(), url: baseURL!, httpOnly: true, sameSite: 'Lax' },
  257 |     ]);
  258 | 
  259 |     // Esto es lo que pasa cuando en la puerta se escanea el QR de una invitada.
  260 |     // El QR de verdad lleva la credencial del invitado; desde la orden 143 el servidor la compara
  261 |     // con la vigente y un QR sin ella (o con una vieja) no entra.
  262 |     await page.goto(`/evento/actual/checkin?fiestaId=${ID}&guestId=${INVITADO.id}&token=${INVITADO.token}`, { waitUntil: 'domcontentloaded' });
  263 | 
  264 |     await expect(page.getByText(/Lucía Fernández/)).toBeVisible({ timeout: 45_000 });
  265 |     await expect(page.getByText(/no corresponde|no encontramos/i)).toHaveCount(0);
  266 | 
  267 |     // Y tiene que quedar registrado en la fiesta, no sólo mostrarse en pantalla.
  268 |     await expect(async () => {
  269 |       const guardado = leerFiesta(ID);
  270 |       const invitado = (guardado?.invitados ?? []).find((i: any) => i.id === INVITADO.id);
  271 |       expect(invitado?.checkedIn, 'La entrada no quedó registrada').toBe(true);
  272 |     }).toPass({ timeout: 30_000 });
  273 |   });
  274 | 
  275 |   test('el invitado deja su opinión y queda registrada', async ({ page }) => {
  276 |     test.setTimeout(180_000);
  277 | 
  278 |     await page.goto(`/feedback/${ID}`, { waitUntil: 'domcontentloaded' });
  279 |     await expect(page.getByRole('button', { name: /Enviar Mis Comentarios/i })).toBeVisible({ timeout: 45_000 });
  280 | 
  281 |     await page.getByRole('button', { name: '9', exact: true }).click();
  282 |     await page.locator('#client-name').fill('Lucía Fernández');
  283 |     await page.locator('#enjoyed-most').fill('La barra y la pantalla del salón.');
  284 |     await page.locator('#to-improve').fill('Más variedad de postres.');
  285 |     await page.getByRole('button', { name: /Enviar Mis Comentarios/i }).click();
  286 | 
  287 |     // Tiene que confirmar en pantalla: si el envío falla en silencio, el invitado
  288 |     // se va creyendo que opinó y AK nunca se entera.
  289 |     await expect(page.getByText(/gracias/i).first()).toBeVisible({ timeout: 45_000 });
  290 |   });
  291 | });
  292 | 
```