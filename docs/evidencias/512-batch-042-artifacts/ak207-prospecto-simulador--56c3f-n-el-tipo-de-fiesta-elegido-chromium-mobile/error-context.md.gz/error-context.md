# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: ak207-prospecto-simulador.spec.ts >> recorrido del prospecto >> el catálogo lleva al simulador con el tipo de fiesta elegido
- Location: tests\e2e\ak207-prospecto-simulador.spec.ts:146:7

# Error details

```
Test timeout of 90000ms exceeded while running "beforeEach" hook.
```

```
Test timeout of 90000ms exceeded while running "afterEach" hook.
```

```
TypeError: fetch failed
```