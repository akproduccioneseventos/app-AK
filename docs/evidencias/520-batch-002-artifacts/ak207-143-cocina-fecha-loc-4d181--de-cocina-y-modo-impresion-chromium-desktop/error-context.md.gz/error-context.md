# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: ak207-143-cocina-fecha-local.spec.ts >> fecha civil del evento se conserva en hoja de cocina y modo impresion
- Location: tests\e2e\ak207-143-cocina-fecha-local.spec.ts:13:5

# Error details

```
TimeoutError: locator.screenshot: Timeout 4904.24ms exceeded.
Call log:
  - taking element screenshot
  - waiting for fonts to load...
  - fonts loaded
  - attempting scroll into view action
    - waiting for element to be stable

```

# Page snapshot

```yaml
- generic [active] [ref=e1]:
  - main [ref=e6]:
    - main [ref=e8]:
      - generic [ref=e9]:
        - generic [ref=e10]:
          - paragraph [ref=e11]:
            - img [ref=e12]
            - text: Hoja de cocina
          - heading "Fecha cocina QA143" [level=1] [ref=e14]
          - paragraph [ref=e15]:
            - generic [ref=e16]: 8/8/2027 ·
            - text: 160 adultos y 0 chicos —
            - strong [ref=e17]: 160 personas
            - generic [ref=e18]: · 121 confirmaron
        - paragraph [ref=e20]:
          - img [ref=e21]
          - text: "Todavía no hay platos cargados en el presupuesto: la hoja sale vacía."
        - generic [ref=e23]:
          - heading "Qué sale, y cuánto" [level=2] [ref=e24]
          - table [ref=e25]:
            - rowgroup [ref=e26]:
              - row "Momento Plato Porciones" [ref=e27]:
                - columnheader "Momento" [ref=e28]
                - columnheader "Plato" [ref=e29]
                - columnheader "Porciones" [ref=e30]
            - rowgroup
        - generic [ref=e31]:
          - heading "Platos especiales, aparte" [level=2] [ref=e32]
          - paragraph [ref=e33]: Ningún invitado confirmado avisó restricciones. Igual conviene tener algo sin gluten a mano.
  - region "Notifications (F8)":
    - list
  - alert [ref=e34]
```

# Test source

```ts
  1  | import {test as __akAudit207} from '@playwright/test';
  2  | __akAudit207.beforeEach(async({context},info)=>{
  3  |  await context.route('**/*',async r=>{const u=new URL(r.request().url());if(/^https?:$/.test(u.protocol)&&!['127.0.0.1','localhost','[::1]'].includes(u.hostname)){await info.attach('qa-egress-blocked',{contentType:'text/plain',body:u.origin+u.pathname});await r.abort('blockedbyclient');}else await r.continue();});
  4  |  await context.route('https://firebaseinstallations.googleapis.com/**',async r=>{const u=new URL(r.request().url());const body=u.pathname.endsWith('authTokens:generate')?{token:'qa368-fis-only',expiresIn:'604800s'}:{fid:'c'+'a'.repeat(21),refreshToken:'qa368-fis-refresh-only',authToken:{token:'qa368-fis-only',expiresIn:'604800s'}};await r.fulfill({status:200,contentType:'application/json',body:JSON.stringify(body)});});
  5  |  await info.attach('qa-fis-mode',{contentType:'text/plain',body:'LOCAL DOUBLE only; no Firebase provider acceptance'});
  6  | });
  7  | import { test, expect } from '@playwright/test';
  8  | import { crearFiestaDeEstaNoche, guardarFiesta, borrarFiesta, ponerSesionDelEquipo } from './helpers/fiesta-de-prueba';
  9  | 
  10 | test.skip(process.env.AK_ENTORNO_AISLADO !== 'true' || process.env.AK_USE_LOCAL_JSON_ONLY !== 'true', 'QA ficticio local');
  11 | const ids: string[] = [];
  12 | test.afterEach(() => { while (ids.length) borrarFiesta(ids.pop()!); });
  13 | test('fecha civil del evento se conserva en hoja de cocina y modo impresion', async ({ page, context, baseURL }, info) => {
  14 |   await context.route('**/*', (route) => {
  15 |     const url = new URL(route.request().url());
  16 |     if (url.hostname === 'firebaseinstallations.googleapis.com') return route.fulfill({ status: 200,
  17 |       contentType: 'application/json', body: JSON.stringify({ fid: 'cQA143localinstallation00', refreshToken: 'synthetic',
  18 |         authToken: { token: 'synthetic', expiresIn: '604800s' }, token: 'synthetic', expiresIn: '604800s' }) });
  19 |     return ['localhost', '127.0.0.1'].includes(url.hostname) || ['data:', 'blob:'].includes(url.protocol)
  20 |       ? route.continue() : route.abort('blockedbyclient');
  21 |   });
  22 |   await ponerSesionDelEquipo(context, baseURL);
  23 |   const date = '2027-08-08';
  24 |   const id = `e2e_143_${info.project.name}_${Date.now()}`;
  25 |   const fiesta = crearFiestaDeEstaNoche({ id, fechaEvento: date });
  26 |   fiesta.configuracion.nombreEvento = 'Fecha cocina QA143';
  27 |   delete fiesta.presupuestoId;
  28 |   guardarFiesta(fiesta); ids.push(id);
  29 |   await page.goto(`/fiestas/nueva/catering/hoja-de-cocina?fiestaId=${id}`, { waitUntil: 'domcontentloaded' });
  30 |   const header = page.locator('header.cabecera-documento');
  31 |   await expect(header.getByRole('heading', { name: 'Fecha cocina QA143', exact: true })).toBeVisible();
  32 |   const screen = await header.innerText();
  33 |   await page.emulateMedia({ media: 'print' });
  34 |   const printed = await header.innerText();
  35 |   const timezone = await page.evaluate(() => Intl.DateTimeFormat().resolvedOptions().timeZone);
  36 |   await info.attach('fecha.json', { contentType: 'application/json', body: Buffer.from(JSON.stringify({
  37 |     fixtureDate: fiesta.configuracion.fechaEvento, expectedCivilDate: [8, 8, 2027], screen, printed, timezone,
  38 |   })) });
> 39 |   await info.attach('cabecera.jpeg', { contentType: 'image/jpeg', body: await header.screenshot({ type: 'jpeg', quality: 65, timeout: 5000 }) });
     |                                                                                      ^ TimeoutError: locator.screenshot: Timeout 4904.24ms exceeded.
  40 |   const civilParts = (text: string) => text.match(/(\d{1,2})\/(\d{1,2})\/(\d{4})/)?.slice(1).map(Number);
  41 |   expect(civilParts(screen)).toEqual([8, 8, 2027]);
  42 |   expect(civilParts(printed)).toEqual([8, 8, 2027]);
  43 | });
  44 | 
```