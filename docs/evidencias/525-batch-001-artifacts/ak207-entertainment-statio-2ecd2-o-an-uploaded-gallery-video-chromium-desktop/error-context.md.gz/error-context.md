# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: ak207-entertainment-stations.spec.ts >> time capsule bakes the configured frame into an uploaded gallery video
- Location: tests\e2e\ak207-entertainment-stations.spec.ts:220:5

# Error details

```
Error: expect(received).toBeGreaterThan(expected)

Expected: > 20
Received:   0

Call Log:
- Timeout 45000ms exceeded while waiting on the predicate
```

# Test source

```ts
  154 |         drawing.fillRect(0, 0, canvas.width, canvas.height);
  155 |       }
  156 |       const stream = canvas.captureStream(20);const qa523Audio=new AudioContext();const qa523Destination=qa523Audio.createMediaStreamDestination();const qa523Tone=qa523Audio.createOscillator();qa523Tone.connect(qa523Destination);qa523Tone.start();for(const a of qa523Destination.stream.getAudioTracks())stream.addTrack(a);const qa523Pump=setInterval(()=>{const c=canvas.getContext("2d");if(c){c.fillStyle=Date.now()%100<50?"#ffffff":"#eeeeee";c.fillRect(100,100,12,12);}},50);for(const t of stream.getTracks()){const stop=t.stop.bind(t);t.stop=()=>{clearInterval(qa523Pump);stop();qa523Audio.close().catch(()=>{});};}
  157 |       const testWindow = window as typeof window & { __buzonTestStreams?: MediaStream[] };
  158 |       testWindow.__buzonTestStreams = [...(testWindow.__buzonTestStreams || []), stream];
  159 |       return stream;
  160 |     };
  161 |     Object.defineProperty(navigator, 'mediaDevices', {
  162 |       configurable: true,
  163 |       value: { getUserMedia },
  164 |     });
  165 |   });
  166 | 
  167 |   const response = await page.goto(`/evento/buzon/${FIESTA_ID}`, { waitUntil: 'domcontentloaded' });
  168 |   expect(response?.status()).toBeLessThan(400);
  169 |   await expect(page.getByRole('button', { name: /Grabar Video/i })).toBeVisible();
  170 |   await expect(page.getByRole('button', { name: /Mensaje de Audio/i })).toBeVisible();
  171 |   await expect(page.getByRole('button', { name: /Subir video/i })).toBeVisible();
  172 |   await expect(page.getByRole('button', { name: /Subir audio/i })).toBeVisible();
  173 |   await expect(page.getByRole('button', { name: /Cabina telefónica retro/i })).toBeVisible();
  174 | 
  175 |   await page.getByRole('button', { name: /Grabar Video/i }).click();
  176 |   const frameCanvas = page.locator('canvas').first();
  177 |   await expect(frameCanvas).toBeVisible();
  178 |   await expect.poll(async () => frameCanvas.evaluate((element) => {
  179 |     const canvas = element as HTMLCanvasElement;
  180 |     const drawing = canvas.getContext('2d');
  181 |     if (!drawing || canvas.width !== 640 || canvas.height !== 480) return 0;
  182 |     const pixels = drawing.getImageData(0, 0, 40, canvas.height).data;
  183 |     let floralPixels = 0;
  184 |     for (let index = 0; index < pixels.length; index += 4) {
  185 |       const red = pixels[index];
  186 |       const green = pixels[index + 1];
  187 |       const blue = pixels[index + 2];
  188 |       if (green > 170 && green > red * 1.25 && blue > 100) floralPixels += 1;
  189 |     }
  190 |     return floralPixels;
  191 |   })).toBeGreaterThan(20);
  192 | 
  193 |   await page.getByRole('button', { name: /Comenzar a Grabar/i }).click();
  194 |   const stopButton = page.getByRole('button', { name: /Detener Grabación/i });
  195 |   await expect(stopButton).toBeVisible();
  196 |   await page.waitForTimeout(1_000);
  197 |   await stopButton.click();
  198 |   // La etiqueta se llama "Video Grabado", no "Video Analogico". Se verifico en
  199 |   // `src/app/evento/buzon/[fiestaId]/page.tsx`: el paso de revision existe y
  200 |   // funciona, solo cambio el texto. La prueba habia quedado con el nombre viejo.
  201 |   await expect(page.getByText('Video Grabado')).toBeVisible();
  202 |   const reviewVideo = page.locator('video[src^="blob:"]').first();
  203 |   await expect(reviewVideo).toBeVisible();
  204 |   await expect.poll(async () => reviewVideo.evaluate(async (element) => {
  205 |     const source = (element as HTMLVideoElement).src;
  206 |     return (await (await fetch(source)).blob()).size;
  207 |   })).toBeGreaterThan(0);
  208 | 
  209 |   await page.getByRole('button', { name: /Grabar de nuevo/i }).click();
  210 |   await expect(page.getByRole('button', { name: /Comenzar a Grabar/i })).toBeVisible();
  211 |   await page.getByRole('button', { name: /Volver al menú/i }).click();
  212 |   await expect.poll(() => page.evaluate(() => {
  213 |     const testWindow = window as typeof window & { __buzonTestStreams?: MediaStream[] };
  214 |     return (testWindow.__buzonTestStreams || []).every(
  215 |       (mediaStream) => mediaStream.getTracks().every((track) => track.readyState === 'ended'),
  216 |     );
  217 |   })).toBe(true);
  218 | });
  219 | 
  220 | test('time capsule bakes the configured frame into an uploaded gallery video', async ({ context, page }, testInfo) => {
  221 |   test.setTimeout(180000); test.skip(testInfo.project.name !== 'chromium-desktop', 'Browser video processing only needs Chromium desktop.');
  222 |   const baseURL = testInfo.project.use.baseURL as string;
  223 |   await addAppSession(context, baseURL);
  224 | 
  225 |   const response = await page.goto(`/evento/buzon/${FIESTA_ID}`, { waitUntil: 'domcontentloaded' });
  226 |   expect(response?.status()).toBeLessThan(400);
  227 |   await page.getByRole('button', { name: /Subir video/i }).click();
  228 |   const input = page.locator('input[type="file"][accept="video/*"]');
  229 |   await input.setInputFiles("C:/Users/Usuario/Documents/Codex/ak-codex88/ak-auditoria267-cierre/docs/evidencias/469-video-ficticio.mp4");;
  230 | 
  231 |   await expect(page.getByText('Video Cargado')).toBeVisible();
  232 |   const reviewVideo = page.locator('video[src^="blob:"]').first();
  233 |   await expect(reviewVideo).toBeVisible();
  234 |   await expect.poll(async () => reviewVideo.evaluate(async (element) => {
  235 |     const video = element as HTMLVideoElement;
  236 |     video.muted = true;
  237 |     await video.play();
  238 |     await new Promise((resolve) => setTimeout(resolve, 250));
  239 |     const canvas = document.createElement('canvas');
  240 |     canvas.width = 640;
  241 |     canvas.height = 480;
  242 |     const drawing = canvas.getContext('2d');
  243 |     if (!drawing) return 0;
  244 |     drawing.drawImage(video, 0, 0, canvas.width, canvas.height);
  245 |     const pixels = drawing.getImageData(0, 0, 40, canvas.height).data;
  246 |     let floralPixels = 0;
  247 |     for (let index = 0; index < pixels.length; index += 4) {
  248 |       const red = pixels[index];
  249 |       const green = pixels[index + 1];
  250 |       const blue = pixels[index + 2];
  251 |       if (green > 170 && green > red * 1.25 && blue > 100) floralPixels += 1;
  252 |     }
  253 |     return floralPixels;
> 254 |   })).toBeGreaterThan(20);
      |       ^ Error: expect(received).toBeGreaterThan(expected)
  255 | });
  256 | 
  257 | test('AI mirror keeps one coherent touch selector on desktop and mobile', async ({ context, page }, testInfo) => {
  258 |   const baseURL = testInfo.project.use.baseURL as string;
  259 |   await addAppSession(context, baseURL);
  260 |   await page.addInitScript(() => {
  261 |     const getUserMedia = async () => {
  262 |       const canvas = document.createElement('canvas');
  263 |       canvas.width = 720;
  264 |       canvas.height = 1280;
  265 |       canvas.getContext('2d')?.fillRect(0, 0, canvas.width, canvas.height);
  266 |       const qa523Canvas=canvas;const qa523Stream=canvas.captureStream(30);const qa523Pump=setInterval(()=>{const c=qa523Canvas.getContext("2d");if(c){c.fillStyle=Date.now()%100<50?"#ffffff":"#eeeeee";c.fillRect(100,100,12,12);}},50);for(const t of qa523Stream.getTracks()){const stop=t.stop.bind(t);t.stop=()=>{clearInterval(qa523Pump);stop();};}return qa523Stream;
  267 |     };
  268 |     Object.defineProperty(navigator, 'mediaDevices', {
  269 |       configurable: true,
  270 |       value: { getUserMedia },
  271 |     });
  272 |   });
  273 | 
  274 |   const response = await page.goto(
  275 |     `/evento/espejo-magico/${FIESTA_ID}?mode=ia`,
  276 |     { waitUntil: 'domcontentloaded' },
  277 |   );
  278 |   expect(response?.status()).toBeLessThan(400);
  279 |   await expect(page.getByText('1. Elegí tu Estilo IA')).toBeVisible();
  280 |   await expect(page.getByRole('checkbox')).toHaveCount(1);
  281 | 
  282 |   const captureButton = page.getByRole('button', { name: 'Crear avatar IA' });
  283 |   await expect(captureButton).toBeDisabled();
  284 |   await page.getByRole('button', { name: 'Cine & Accion' }).click();
  285 |   await expect(page.getByTestId('selected-ai-style')).toHaveText('Afiche de Cine');
  286 |   await expect(
  287 |     page.getByRole('button', { name: 'Afiche de Cine' }),
  288 |   ).toHaveAttribute('aria-pressed', 'true');
  289 | 
  290 |   await page.getByRole('checkbox').check();
  291 |   await expect(captureButton).toBeEnabled();
  292 |   expect(
  293 |     await page.evaluate(
  294 |       () => document.documentElement.scrollWidth <= window.innerWidth + 1,
  295 |     ),
  296 |   ).toBe(true);
  297 | });
  298 | 
  299 | 
```