# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: ak207-pantallas-tocadas-tanda-12-10.spec.ts >> /fiestas/nueva/centro-total?fiestaId=B lleva al Centro de la fiesta B, no a la A
- Location: tests\e2e\ak207-pantallas-tocadas-tanda-12-10.spec.ts:100:7

# Error details

```
Error: QA495 fixture bridge: TypeError: fetch failed

```

```
Error: QA495 fixture bridge: TypeError: fetch failed

```

# Test source

```ts
  1   | import {spawnSync as __qa495Spawn} from 'node:child_process';
> 2   | function __qa495(op:string,id:string,value?:unknown){if(process.env.FIRESTORE_EMULATOR_HOST!=='127.0.0.1:8085')throw new Error('QA495 emulator only');const r=__qa495Spawn(process.execPath,[process.cwd()+'/.qa528-fiesta-rest-bridge.cjs',op,id],{cwd:process.cwd(),env:{...process.env,NODE_OPTIONS:(process.env.NODE_OPTIONS||'').replace(/--max-old-space-size=\d+/g,'')+' --max-old-space-size=256'},input:value===undefined?undefined:JSON.stringify(value),encoding:'utf8',timeout:30000,maxBuffer:16*1024*1024});if(r.status!==0)throw new Error('QA495 fixture bridge: '+r.stderr);return JSON.parse(r.stdout||'null');}
      |                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                 ^ Error: QA495 fixture bridge: TypeError: fetch failed
  3   | import crypto from 'node:crypto';
  4   | import fs from 'node:fs';
  5   | import path from 'node:path';
  6   | import { buildAkDemoFiesta } from '../../../src/lib/experience-ak/demo-fiesta-factory';
  7   | import type { FiestaEnPlanificacion } from '../../../src/types/fiesta';
  8   | import { getUruguayParts } from '../../../src/lib/utils';
  9   | 
  10  | /**
  11  |  * Fiesta de prueba con datos de verdad.
  12  |  *
  13  |  * La app tiene un modo local que guarda los eventos como archivos en vez de en
  14  |  * la base. Con la escritura habilitada, ese modo permite probar el recorrido
  15  |  * completo: el invitado confirma, el dato se guarda y el equipo lo ve.
  16  |  *
  17  |  * Este ayudante crea la fiesta, la deja en las dos carpetas donde la app busca
  18  |  * los datos locales, y la borra al terminar.
  19  |  */
  20  | 
  21  | export const SESSION_SECRET = 'playwright-session-secret-with-enough-entropy';
  22  | 
  23  | /** Cookie de sesión del equipo, firmada igual que en la app. */
  24  | export function crearCookieDeSesion() {
  25  |   const payload = `v1.${Date.now() + 60 * 60 * 1000}.${crypto.randomUUID()}`;
  26  |   return `${payload}.${crypto.createHmac('sha256', SESSION_SECRET).update(payload).digest('hex')}`;
  27  | }
  28  | 
  29  | /**
  30  |  * Deja la sesion del equipo puesta en el navegador de la prueba.
  31  |  *
  32  |  * **Se usa esto y no `addCookies` a mano.** Costo una hora el 20 de septiembre de 2026:
  33  |  * una cookie puesta sin `sameSite` la toma Chromium como `None`, y una cookie `None` sin
  34  |  * `Secure` **se descarta en http**. La pantalla abria sin sesion, rebotaba al ingreso, y de
  35  |  * paso perdia lo que venia en la direccion (`?fiestaId=...`): quedaba en "elegi una fiesta"
  36  |  * o cargando para siempre, como si el defecto fuera de la pantalla.
  37  |  */
  38  | export async function ponerSesionDelEquipo(
  39  |   context: {
  40  |     addCookies: (c: any[]) => Promise<unknown>;
  41  |     addInitScript: (fn: any) => Promise<unknown>;
  42  |   },
  43  |   baseURL: string | undefined,
  44  | ) {
  45  |   // Las DOS mitades, y sin la segunda la pantalla rebota al ingreso:
  46  |   // 1) la cookie firmada, que es lo que mira el portero del servidor;
  47  |   // 2) la marca en el navegador, que es lo que mira el guardia de la pantalla
  48  |   //    (`AuthGuard`, `getSession()`). Con la cookie sola, el guardia manda al ingreso
  49  |   //    y de paso se pierde lo que venia en la direccion (`?fiestaId=...`).
  50  |   await context.addInitScript(() => {
  51  |     window.localStorage.setItem('ak_session', 'true');
  52  |     window.sessionStorage.setItem('ak_session', 'true');
  53  |   });
  54  |   await context.addCookies([
  55  |     {
  56  |       name: 'ak_session',
  57  |       value: crearCookieDeSesion(),
  58  |       url: baseURL,
  59  |       httpOnly: true,
  60  |       sameSite: 'Lax' as const,
  61  |     },
  62  |   ]);
  63  | }
  64  | 
  65  | /**
  66  |  * Permiso de estación, igual que el que genera el equipo desde el Centro de
  67  |  * Fiesta. Las estaciones (buzón, fotocabina, espejo, 360) no se abren con el
  68  |  * link pelado: hay que llegar con este permiso, que es lo que lleva el QR.
  69  |  *
  70  |  * Se reproduce acá el mismo formato que usa la app (`ent-v2` + firma) para poder
  71  |  * probar el camino real del invitado y no una versión inventada.
  72  |  */
  73  | export function crearPermisoDeEstacion(fiestaId: string, moduloId: string, horas = 18) {
  74  |   const datos = Buffer.from(
  75  |     JSON.stringify({
  76  |       version: 'ent-v2',
  77  |       fiestaId,
  78  |       moduleId: moduloId,
  79  |       scope: 'guest',
  80  |       expiresAt: Date.now() + horas * 60 * 60 * 1000,
  81  |       nonce: crypto.randomUUID(),
  82  |     }),
  83  |   ).toString('base64url');
  84  |   const firma = crypto.createHmac('sha256', SESSION_SECRET).update(datos).digest('base64url');
  85  |   return `${datos}.${firma}`;
  86  | }
  87  | 
  88  | const CARPETAS_DATOS = [
  89  |   path.join(process.cwd(), 'data', 'fiestas'),
  90  |   path.join(process.cwd(), 'src', 'data', 'fiestas'),
  91  | ];
  92  | 
  93  | export function archivosDe(fiestaId: string) {
  94  |   return CARPETAS_DATOS.map((dir) => path.join(dir, `${fiestaId}.json`));
  95  | }
  96  | 
  97  | export function guardarFiesta(fiesta: FiestaEnPlanificacion) {
  98  |   for (const archivo of archivosDe(fiesta.id)) {
  99  |     fs.mkdirSync(path.dirname(archivo), { recursive: true });
  100 |     fs.writeFileSync(archivo, `${JSON.stringify(fiesta, null, 2)}\n`);
  101 |   }
  102 | 
```