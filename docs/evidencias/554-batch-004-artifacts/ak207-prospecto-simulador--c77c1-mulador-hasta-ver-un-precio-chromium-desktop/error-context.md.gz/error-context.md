# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: ak207-prospecto-simulador.spec.ts >> recorrido del prospecto >> llega desde el simulador hasta ver un precio
- Location: tests\e2e\ak207-prospecto-simulador.spec.ts:59:7

# Error details

```
Error: El prospecto llegó al final pero no tiene cómo cerrar

expect(locator).toBeVisible() failed

Locator: getByRole('button', { name: /WhatsApp|Generar presupuesto/i }).first()
Expected: visible
Timeout: 20000ms
Error: element(s) not found

Call log:
  - El prospecto llegó al final pero no tiene cómo cerrar with timeout 20000ms
  - waiting for getByRole('button', { name: /WhatsApp|Generar presupuesto/i }).first()

```

```yaml
- img "AK Producciones"
- text: Armá tu presupuesto Paso 5 de 5 · Edición
- progressbar
- heading "Personalización de tu presupuesto" [level=2]
- paragraph: ¡Llegamos a la etapa final! Ajustá la fecha y los invitados, quitá opcionales de tu paquete o agregá extras a tu gusto. El total se recalcula al instante.
- heading "Información General del Evento" [level=3]:
  - img
  - text: Información General del Evento
- text: Fecha del evento
- button "15 de noviembre de 2026":
  - img
  - text: 15 de noviembre de 2026
- text: Invitados Adultos
- spinbutton: "80"
- text: Niños y Adolescentes
- spinbutton
- heading "Servicios contratados en tu propuesta" [level=3]:
  - img
  - text: Servicios contratados en tu propuesta
- img
- text: Personal 2 activos Mozo Personal • $ 11.960
- button "Retirar servicio":
  - img
- text: Mozo de cocina Personal • $ 11.960
- button "Retirar servicio":
  - img
- img
- text: Servicio de bebidas 1 activos Barra de tragos Servicio de bebidas • $ 31.920
- button "Retirar servicio":
  - img
- img
- text: Servicio de comida 3 activos Mantelería completa Servicio de comida • $ 6.320
- button "Retirar servicio":
  - img
- text: Mobiliario completo Servicio de comida • $ 6.000
- button "Retirar servicio":
  - img
- text: Vajilla Completa Servicio de comida • $ 6.320
- button "Retirar servicio":
  - img
- img
- text: Servicio de decoración 2 activos Cuadro de firmas Servicio de decoración • $ 2.990
- button "Retirar servicio":
  - img
- text: Servicio de Decoración Servicio de decoración • $ 14.990
- button "Retirar servicio":
  - img
- img
- text: Servicio de discoteca 1 activos Servicio de Discoteca Servicio de discoteca • $ 14.900
- button "Retirar servicio":
  - img
- img
- text: Servicio de entretenimiento 1 activos Fotocabina Servicio de entretenimiento • $ 2.990
- button "Retirar servicio":
  - img
- img
- text: Servicio de fotografía 2 activos Fotografía de exteriores Servicio de fotografía • $ 3.990
- button "Retirar servicio":
  - img
- text: Fotografía de la fiesta Servicio de fotografía • $ 9.990
- button "Retirar servicio":
  - img
- img
- text: Servicio de repostería 2 activos Mesa dulce con fuente de chocolate Servicio de repostería • $ 9.520
- button "Retirar servicio":
  - img
- text: Torta Principal Servicio de repostería • $ 8.720
- button "Retirar servicio":
  - img
- img
- text: Regalos Incluidos 6 activos Invitaciones digitales Regalo incluido Organizamos de la fiesta Regalo incluido Mesa de café Regalo incluido Album digital Regalo incluido Video de vida Regalo incluido Pantalla gigante y proyector Regalo incluido
- heading "Personalizá tu fiesta con más servicios" [level=4]:
  - img
  - text: Personalizá tu fiesta con más servicios
- img
- heading "🔥 ¡Subí tu evento al Plan Paquete premium!" [level=4]
- paragraph: "Llevá tu fiesta al siguiente nivel. Agregá estos servicios clave incluidos en el paquete Paquete premium y asegurá una experiencia inolvidable para todos tus invitados:"
- button "⚡ Pasarme al Plan Paquete premium"
- text: Refrescos +$ 11.600
- button "Sumar +"
- text: Banner Gigantografía +$ 2.990
- button "Sumar +"
- text: Candy Bar Temático +$ 8.800
- button "Sumar +"
- text: Lluvia de burbujas +$ 1.500
- button "Sumar +"
- text: Fuegos fríos (2 disparos) +$ 3.000
- button "Sumar +"
- text: Filmación de la fiesta +$ 9.990
- button "Sumar +"
- img
- 'textbox "Buscá servicios adicionales por nombre (ej: cabina, plataforma, barra, cascada)..."'
- heading "¿Querés comparar con otros paquetes?" [level=4]
- text: Alternativa
- heading "Paquete basico" [level=5]
- paragraph: $ 64.821
- paragraph: "- $ 705 por persona"
- button "Cambiar a Paquete basico"
- text: Alternativa
- heading "Paquete premium" [level=5]
- paragraph: $ 149.557
- paragraph: + $ 355 por persona
- button "Cambiar a Paquete premium"
- strong: Precios 2026
- text: — El total mostrado corresponde al precio vigente.
- button "Ver Preguntas Frecuentes (FAQ)":
  - img
  - text: Ver Preguntas Frecuentes (FAQ)
- button "Anterior"
- text: 🎁 ¡Ahorrás $ 22.900 en regalos incluidos!
- button "Ver Resumen y Propuesta"
- paragraph: "Total vigente:"
- paragraph: $ 121.184
- paragraph: $ 1.515 p/p
- region "Notifications (F8)":
  - list
- alert
```

# Test source

```ts
  41  |  *
  42  |  * La prueba llega hasta ver el precio, y **no** genera el presupuesto: ese paso
  43  |  * crea un prospecto de verdad y ensuciaría los datos del negocio con gente que
  44  |  * no existe.
  45  |  */
  46  | 
  47  | const NOMBRE = 'Prospecto de prueba';
  48  | 
  49  | // El simulador registra el avance paso a paso, así que el recorrido crea un
  50  | // prospecto de verdad. Se borra al terminar: el CRM es del negocio, no de las
  51  | // pruebas.
  52  | test.afterAll(() => {
  53  |   borrarProspectosDePrueba();
  54  |   borrarPresupuestosDePrueba();
  55  | });
  56  | const TELEFONO = '099 123 456';
  57  | 
  58  | test.describe('recorrido del prospecto', () => {
  59  |   test('llega desde el simulador hasta ver un precio', async ({ page }) => {
  60  |     test.setTimeout(300_000);
  61  | 
  62  |     const erroresJs: string[] = [];
  63  |     page.on('pageerror', (e) => erroresJs.push(e.message));
  64  | 
  65  |     await page.goto('/simulador-de-presupuesto', { waitUntil: 'domcontentloaded' });
  66  | 
  67  |     // Paso 1: la portada. Se busca por el texto que ve una persona, no por una
  68  |     // marca interna: si el botón cambia de nombre, la prueba tiene que avisar.
  69  |     const empezar = page.getByRole('button', { name: /Comenzar mi presupuesto|Cotizar/i }).first();
  70  |     await expect(empezar, 'No aparece el botón para empezar a cotizar').toBeVisible({ timeout: 45_000 });
  71  |     await empezar.click();
  72  | 
  73  |     // La portada del simulador tiene su propio botón para arrancar el paso a paso.
  74  |     const arrancar = page.getByRole('button', { name: /Cotizar mi fiesta/i }).first();
  75  |     await expect(arrancar, 'No aparece el botón que arranca el paso a paso').toBeVisible({ timeout: 45_000 });
  76  |     await arrancar.click();
  77  | 
  78  |     // Paso 2: sus datos.
  79  |     await expect(page.locator('#simulator-name')).toBeVisible({ timeout: 45_000 });
  80  |     await page.locator('#simulator-name').fill(NOMBRE);
  81  |     await page.locator('#simulator-phone').fill(TELEFONO);
  82  | 
  83  |     // Duración y salón: dos decisiones que cambian el precio.
  84  |     await page.getByText('Mas de 4 horas').first().click();
  85  |     await page.getByText('Tengo salón o locación propia').first().click();
  86  | 
  87  |     // Cantidad de gente.
  88  |     const adultos = page.locator('input[type="number"]').first();
  89  |     await adultos.fill('80');
  90  | 
  91  |     // La fecha: se abre el calendario y se toma un día disponible del mes que viene.
  92  |     const calendario = page.getByRole('button', { name: /fecha|Elegí|Seleccion/i }).first();
  93  |     if (await calendario.isVisible().catch(() => false)) {
  94  |       await calendario.click();
  95  |       const siguiente = page.getByRole('button', { name: /next month|mes siguiente/i }).first();
  96  |       if (await siguiente.isVisible().catch(() => false)) await siguiente.click();
  97  |       // react-day-picker 9: el dia es un boton dentro de la grilla, con nombre
  98  |       // accesible largo ("viernes, 15 de ..."), no una celda llamada "15".
  99  |       const dia = page.getByRole('grid').getByRole('button', { name: /\b15\b/, disabled: false }).first();
  100 |       if (await dia.isVisible().catch(() => false)) await dia.click();
  101 |     }
  102 | 
  103 |     // Avanzar hasta el final del recorrido. Cada "Continuar" tiene que llevar a
  104 |     // algún lado: si uno se traba, la venta se corta ahí.
  105 |     for (let paso = 0; paso < 4; paso += 1) {
  106 |       const continuar = page.getByRole('button', { name: 'Continuar' }).first();
  107 |       if (!(await continuar.isVisible().catch(() => false))) break;
  108 |       await expect(continuar, `El botón "Continuar" quedó bloqueado en el paso ${paso + 2}`).toBeEnabled({ timeout: 20_000 });
  109 |       await continuar.click();
  110 |       await page.waitForTimeout(2500);
  111 |     }
  112 | 
  113 |     // Sobre el final aparece el cartel que ofrece subir de paquete. Es parte de
  114 |     // la venta: una persona lo lee y decide. Acá se elige quedarse con lo que
  115 |     // venía armando, que es lo que hace la mayoría.
  116 |     const mantener = page.getByRole('button', { name: /Mantener mi selección actual/i }).first();
  117 |     if (await mantener.isVisible().catch(() => false)) {
  118 |       await mantener.click();
  119 |       await page.waitForTimeout(1500);
  120 |     }
  121 | 
  122 |     // Lo que importa: el prospecto tiene que ver un precio, no un cero ni un
  123 |     // texto roto.
  124 |     const textoFinal = await page.locator('body').innerText();
  125 |     const montos = textoFinal.match(/\$\s?[\d.]{4,}/g) ?? [];
  126 |     expect(montos.length, `No apareció ningún precio en el recorrido:\n${textoFinal.slice(0, 400)}`).toBeGreaterThan(0);
  127 |     expect(textoFinal).not.toMatch(/NaN|Infinity|\[object Object\]/);
  128 | 
  129 |     // El último paso no dice "Continuar" sino "Ver Resumen y Propuesta": ahí es
  130 |     // donde aparece la propuesta con el precio congelado y el botón para
  131 |     // escribirle a AK. Sin este clic, el recorrido se cortaba una pantalla antes.
  132 |     const verResumen = page.getByRole('button', { name: /Ver Resumen y Propuesta/i }).first();
  133 |     if (await verResumen.isVisible().catch(() => false)) {
  134 |       await expect(verResumen, 'El botón que abre la propuesta final quedó bloqueado').toBeEnabled({ timeout: 20_000 });
  135 |       await verResumen.click();
  136 |       await page.waitForTimeout(2500);
  137 |     }
  138 | 
  139 |     // Y tiene que poder cerrar: o generar el presupuesto o escribirle a AK.
  140 |     const cierre = page.getByRole('button', { name: /WhatsApp|Generar presupuesto/i }).first();
> 141 |     await expect(cierre, 'El prospecto llegó al final pero no tiene cómo cerrar').toBeVisible({ timeout: 20_000 });
      |                                                                                   ^ Error: El prospecto llegó al final pero no tiene cómo cerrar
  142 | 
  143 |     expect(erroresJs, `El simulador tuvo fallas de JavaScript:\n${erroresJs.join('\n')}`).toEqual([]);
  144 |   });
  145 | 
  146 |   test('el catálogo lleva al simulador con el tipo de fiesta elegido', async ({ page }) => {
  147 |     test.setTimeout(180_000);
  148 | 
  149 |     // Es lo que se hace sentado con el cliente: se le muestra el catálogo y de
  150 |     // ahí se pasa a cotizar.
  151 |     await page.goto('/catalogo/bodas', { waitUntil: 'domcontentloaded' });
  152 |     await expect(page.getByRole('button', { name: /Siguiente/i }).first()).toBeVisible({ timeout: 45_000 });
  153 | 
  154 |     const textoCatalogo = await page.locator('body').innerText();
  155 |     expect(textoCatalogo).not.toMatch(/NaN|Infinity|\[object Object\]/);
  156 |     expect(textoCatalogo.length, 'El catálogo quedó vacío').toBeGreaterThan(200);
  157 |   });
  158 | });
  159 | 
```