# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: ak207-89-la-barra-no-ofrece-lo-agotado.spec.ts >> Orden 89 — Bloque 2: La barra no ofrece lo agotado >> trago con stock 0 se muestra como Agotado, no se puede pedir, va al final y nunca es sugerido
- Location: tests\e2e\ak207-89-la-barra-no-ofrece-lo-agotado.spec.ts:107:7

# Error details

```
Test timeout of 90000ms exceeded.
```