# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: ak207-entertainment-stations.spec.ts >> time capsule exposes every media mode and records the configured frame
- Location: tests\e2e\ak207-entertainment-stations.spec.ts:143:5

# Error details

```
Error: expect(received).toBeGreaterThan(expected)

Expected: > 0
Received:   0

Call Log:
- Timeout 45000ms exceeded while waiting on the predicate
```

# Test source

```ts
  108 |     expect(response?.status(), route).toBeLessThan(400);
  109 |     await expect(page.locator('body'), route).not.toContainText(/acceso de estacion no autorizado|no se pudo abrir esta estacion/i);
  110 |     await expect(page.locator('button:visible').first(), route).toBeVisible();
  111 |   }
  112 | });
  113 | 
  114 | test('photobooth display receives a browser camera stream', async ({ context, page }, testInfo) => {
  115 |   const baseURL = testInfo.project.use.baseURL as string;
  116 |   await addAppSession(context, baseURL);
  117 |   await page.addInitScript(() => {
  118 |     const getUserMedia = async () => {
  119 |       const canvas = document.createElement('canvas');
  120 |       canvas.width = 720;
  121 |       canvas.height = 1280;
  122 |       const drawing = canvas.getContext('2d');
  123 |       drawing?.fillRect(0, 0, canvas.width, canvas.height);
  124 |       return canvas.captureStream(30);
  125 |     };
  126 |     Object.defineProperty(navigator, 'mediaDevices', {
  127 |       configurable: true,
  128 |       value: { getUserMedia },
  129 |     });
  130 |   });
  131 | 
  132 |   const response = await page.goto(`/evento/fotocabina/${FIESTA_ID}`, { waitUntil: 'domcontentloaded' });
  133 |   expect(response?.status()).toBeLessThan(400);
  134 |   await expect(page.locator('body')).not.toContainText(/acceso de estacion no autorizado|no se pudo abrir esta estacion/i);
  135 |   // El invitado tiene que VERSE. Puede ser en el `<video>` directo o en el
  136 |   // lienzo de la vista previa: desde que la fotocabina cambia el fondo en vivo,
  137 |   // el video queda oculto a proposito y lo que se muestra es el lienzo con el
  138 |   // fondo ya aplicado. Lo que importa es que se vea la camara, no en cual de
  139 |   // los dos elementos.
  140 |   await expect(page.locator('video:visible, canvas:visible').first()).toBeVisible();
  141 | });
  142 | 
  143 | test('time capsule exposes every media mode and records the configured frame', async ({ context, page }, testInfo) => {
  144 |   test.skip(testInfo.project.name !== 'chromium-desktop', 'MediaRecorder coverage only needs Chromium desktop.');
  145 |   const baseURL = testInfo.project.use.baseURL as string;
  146 |   await addAppSession(context, baseURL);
  147 |   await page.addInitScript(() => {
  148 |     const getUserMedia = async () => {
  149 |       const canvas = document.createElement('canvas');
  150 |       canvas.width = 640;
  151 |       canvas.height = 480;
  152 |       const drawing = canvas.getContext('2d');
  153 |       if (drawing) {
  154 |         drawing.fillStyle = '#1e3a5f';
  155 |         drawing.fillRect(0, 0, canvas.width, canvas.height);
  156 |       }
  157 |       const stream = canvas.captureStream(20);
  158 |       const testWindow = window as typeof window & { __buzonTestStreams?: MediaStream[] };
  159 |       testWindow.__buzonTestStreams = [...(testWindow.__buzonTestStreams || []), stream];
  160 |       return stream;
  161 |     };
  162 |     Object.defineProperty(navigator, 'mediaDevices', {
  163 |       configurable: true,
  164 |       value: { getUserMedia },
  165 |     });
  166 |   });
  167 | 
  168 |   const response = await page.goto(`/evento/buzon/${FIESTA_ID}`, { waitUntil: 'domcontentloaded' });
  169 |   expect(response?.status()).toBeLessThan(400);
  170 |   await expect(page.getByRole('button', { name: /Grabar Video/i })).toBeVisible();
  171 |   await expect(page.getByRole('button', { name: /Mensaje de Audio/i })).toBeVisible();
  172 |   await expect(page.getByRole('button', { name: /Subir video/i })).toBeVisible();
  173 |   await expect(page.getByRole('button', { name: /Subir audio/i })).toBeVisible();
  174 |   await expect(page.getByRole('button', { name: /Cabina telefónica retro/i })).toBeVisible();
  175 | 
  176 |   await page.getByRole('button', { name: /Grabar Video/i }).click();
  177 |   const frameCanvas = page.locator('canvas').first();
  178 |   await expect(frameCanvas).toBeVisible();
  179 |   await expect.poll(async () => frameCanvas.evaluate((element) => {
  180 |     const canvas = element as HTMLCanvasElement;
  181 |     const drawing = canvas.getContext('2d');
  182 |     if (!drawing || canvas.width !== 640 || canvas.height !== 480) return 0;
  183 |     const pixels = drawing.getImageData(0, 0, 40, canvas.height).data;
  184 |     let floralPixels = 0;
  185 |     for (let index = 0; index < pixels.length; index += 4) {
  186 |       const red = pixels[index];
  187 |       const green = pixels[index + 1];
  188 |       const blue = pixels[index + 2];
  189 |       if (green > 170 && green > red * 1.25 && blue > 100) floralPixels += 1;
  190 |     }
  191 |     return floralPixels;
  192 |   })).toBeGreaterThan(20);
  193 | 
  194 |   await page.getByRole('button', { name: /Comenzar a Grabar/i }).click();
  195 |   const stopButton = page.getByRole('button', { name: /Detener Grabación/i });
  196 |   await expect(stopButton).toBeVisible();
  197 |   await page.waitForTimeout(1_000);
  198 |   await stopButton.click();
  199 |   // La etiqueta se llama "Video Grabado", no "Video Analogico". Se verifico en
  200 |   // `src/app/evento/buzon/[fiestaId]/page.tsx`: el paso de revision existe y
  201 |   // funciona, solo cambio el texto. La prueba habia quedado con el nombre viejo.
  202 |   await expect(page.getByText('Video Grabado')).toBeVisible();
  203 |   const reviewVideo = page.locator('video[src^="blob:"]').first();
  204 |   await expect(reviewVideo).toBeVisible();
  205 |   await expect.poll(async () => reviewVideo.evaluate(async (element) => {
  206 |     const source = (element as HTMLVideoElement).src;
  207 |     return (await (await fetch(source)).blob()).size;
> 208 |   })).toBeGreaterThan(0);
      |       ^ Error: expect(received).toBeGreaterThan(expected)
  209 | 
  210 |   await page.getByRole('button', { name: /Grabar de nuevo/i }).click();
  211 |   await expect(page.getByRole('button', { name: /Comenzar a Grabar/i })).toBeVisible();
  212 |   await page.getByRole('button', { name: /Volver al menú/i }).click();
  213 |   await expect.poll(() => page.evaluate(() => {
  214 |     const testWindow = window as typeof window & { __buzonTestStreams?: MediaStream[] };
  215 |     return (testWindow.__buzonTestStreams || []).every(
  216 |       (mediaStream) => mediaStream.getTracks().every((track) => track.readyState === 'ended'),
  217 |     );
  218 |   })).toBe(true);
  219 | });
  220 | 
  221 | test('time capsule bakes the configured frame into an uploaded gallery video', async ({ context, page }, testInfo) => {
  222 |   test.skip(testInfo.project.name !== 'chromium-desktop', 'Browser video processing only needs Chromium desktop.');
  223 |   const baseURL = testInfo.project.use.baseURL as string;
  224 |   await addAppSession(context, baseURL);
  225 | 
  226 |   const response = await page.goto(`/evento/buzon/${FIESTA_ID}`, { waitUntil: 'domcontentloaded' });
  227 |   expect(response?.status()).toBeLessThan(400);
  228 |   await page.getByRole('button', { name: /Subir video/i }).click();
  229 |   const input = page.locator('input[type="file"][accept="video/*"]');
  230 |   await input.evaluate(async (element) => {
  231 |     const canvas = document.createElement('canvas');
  232 |     canvas.width = 320;
  233 |     canvas.height = 240;
  234 |     const drawing = canvas.getContext('2d');
  235 |     if (drawing) {
  236 |       drawing.fillStyle = '#1e3a5f';
  237 |       drawing.fillRect(0, 0, canvas.width, canvas.height);
  238 |     }
  239 |     const stream = canvas.captureStream(20);
  240 |     const candidates = ['video/mp4', 'video/webm;codecs=vp9', 'video/webm'];
  241 |     const mimeType = candidates.find((candidate) => MediaRecorder.isTypeSupported(candidate)) || '';
  242 |     const recorder = mimeType ? new MediaRecorder(stream, { mimeType }) : new MediaRecorder(stream);
  243 |     const chunks: Blob[] = [];
  244 |     recorder.ondataavailable = (event) => {
  245 |       if (event.data.size > 0) chunks.push(event.data);
  246 |     };
  247 |     const stopped = new Promise<void>((resolve) => {
  248 |       recorder.onstop = () => resolve();
  249 |     });
  250 |     recorder.start(100);
  251 |     let frame = 0;
  252 |     const drawingInterval = window.setInterval(() => {
  253 |       if (!drawing) return;
  254 |       drawing.fillStyle = frame % 2 === 0 ? '#1e3a5f' : '#315b82';
  255 |       drawing.fillRect(0, 0, canvas.width, canvas.height);
  256 |       drawing.fillStyle = '#ffffff';
  257 |       drawing.fillRect((frame * 8) % canvas.width, 80, 40, 40);
  258 |       frame += 1;
  259 |     }, 50);
  260 |     await new Promise((resolve) => setTimeout(resolve, 1_500));
  261 |     window.clearInterval(drawingInterval);
  262 |     recorder.stop();
  263 |     await stopped;
  264 |     stream.getTracks().forEach((track) => track.stop());
  265 | 
  266 |     const outputType = recorder.mimeType || mimeType || 'video/webm';
  267 |     const extension = outputType.includes('mp4') ? 'mp4' : 'webm';
  268 |     const transfer = new DataTransfer();
  269 |     transfer.items.add(new File(chunks, `gallery-test.${extension}`, { type: outputType }));
  270 |     const fileInput = element as HTMLInputElement;
  271 |     fileInput.files = transfer.files;
  272 |     fileInput.dispatchEvent(new Event('change', { bubbles: true }));
  273 |   });
  274 | 
  275 |   await expect(page.getByText('Video Cargado')).toBeVisible();
  276 |   const reviewVideo = page.locator('video[src^="blob:"]').first();
  277 |   await expect(reviewVideo).toBeVisible();
  278 |   await expect.poll(async () => reviewVideo.evaluate(async (element) => {
  279 |     const video = element as HTMLVideoElement;
  280 |     video.muted = true;
  281 |     await video.play();
  282 |     await new Promise((resolve) => setTimeout(resolve, 250));
  283 |     const canvas = document.createElement('canvas');
  284 |     canvas.width = 640;
  285 |     canvas.height = 480;
  286 |     const drawing = canvas.getContext('2d');
  287 |     if (!drawing) return 0;
  288 |     drawing.drawImage(video, 0, 0, canvas.width, canvas.height);
  289 |     const pixels = drawing.getImageData(0, 0, 40, canvas.height).data;
  290 |     let floralPixels = 0;
  291 |     for (let index = 0; index < pixels.length; index += 4) {
  292 |       const red = pixels[index];
  293 |       const green = pixels[index + 1];
  294 |       const blue = pixels[index + 2];
  295 |       if (green > 170 && green > red * 1.25 && blue > 100) floralPixels += 1;
  296 |     }
  297 |     return floralPixels;
  298 |   })).toBeGreaterThan(20);
  299 | });
  300 | 
  301 | test('AI mirror keeps one coherent touch selector on desktop and mobile', async ({ context, page }, testInfo) => {
  302 |   const baseURL = testInfo.project.use.baseURL as string;
  303 |   await addAppSession(context, baseURL);
  304 |   await page.addInitScript(() => {
  305 |     const getUserMedia = async () => {
  306 |       const canvas = document.createElement('canvas');
  307 |       canvas.width = 720;
  308 |       canvas.height = 1280;
```