# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: ak207-las-estaciones-respetan-los-ajustes.spec.ts >> cada estación muestra en la pantalla de compartir el texto de marca que puso el equipo
- Location: tests\e2e\ak207-las-estaciones-respetan-los-ajustes.spec.ts:153:5

# Error details

```
Error: Bogue: no llego a la pantalla de compartir en 90 segundos

expect(received).toBe(expected) // Object.is equality

Expected: ""
Received: "Bogue: no llego a la pantalla de compartir en 90 segundos"
```

# Test source

```ts
  93  |     const armar = () => {
  94  |       const lienzo = document.createElement('canvas');
  95  |       lienzo.width = 720;
  96  |       lienzo.height = 1280;
  97  |       lienzo.getContext('2d')?.fillRect(0, 0, lienzo.width, lienzo.height);
  98  |       return lienzo.captureStream(30);
  99  |     };
  100 |     Object.defineProperty(navigator, 'mediaDevices', {
  101 |       configurable: true,
  102 |       value: {
  103 |         getUserMedia: async () => armar(),
  104 |         enumerateDevices: async () => [{ deviceId: 'cam', kind: 'videoinput', label: 'Camara', groupId: 'g' }],
  105 |         addEventListener: () => {},
  106 |         removeEventListener: () => {},
  107 |       },
  108 |     });
  109 |   });
  110 | }
  111 | 
  112 | const ESTACIONES = [
  113 |   { nombre: 'Plataforma 360', ruta: 'plataforma-360', modulo: 'plataforma360' },
  114 |   { nombre: 'Bogue', ruta: 'bogue', modulo: 'bogue' },
  115 |   // TOUCHPIX QUEDA AFUERA, Y NO ES QUE ESTE MAL LA ESTACION.
  116 |   // Su texto de marca vive en la ventanita del QR (page.tsx:794), que se abre
  117 |   // con "Compartir" despues de sacar la foto. Pero el boton de disparar es un
  118 |   // circulo con un dibujo y SIN NOMBRE, asi que no hay forma de tocarlo desde
  119 |   // una prueba. Se intento tres veces.
  120 |   // Ponerle el nombre esta pedido en docs/ordenes/20, bloque 9.c. Cuando lo
  121 |   // tenga, se vuelve a poner aca y se comprueba de verdad.
  122 |   // Mientras tanto figura como NO VERIFICADO en docs/LO-AUDITADO.md, no como hecho.
  123 | ];
  124 | 
  125 | /**
  126 |  * Lleva la estación hasta la pantalla de compartir y devuelve lo que dice.
  127 |  *
  128 |  * El texto de marca NO se dibuja al abrir: aparece junto al QR, recién después de
  129 |  * la captura. Por eso hay que sacar la foto de verdad, con paciencia: la 360 graba
  130 |  * un video y Bogue arma un loop.
  131 |  */
  132 | async function llegarACompartir(page: Page): Promise<string> {
  133 |   const disparar = page
  134 |     .getByRole('button', { name: /sacar|empezar|comenzar|iniciar|grabar|foto|video/i })
  135 |     .and(page.locator('button:not([disabled])'))
  136 |     .first();
  137 |   if ((await disparar.count()) === 0) return '';
  138 |   await disparar.click().catch(() => {});
  139 | 
  140 |   // Se espera a que aparezca el QR, que es la señal de que llegó a compartir.
  141 |   const limite = Date.now() + 90_000;
  142 |   let texto = '';
  143 |   while (Date.now() < limite) {
  144 |     await page.waitForTimeout(3_000);
  145 |     texto = ((await page.locator('body').innerText().catch(() => '')) || '')
  146 |       .replace(/\s+/g, ' ')
  147 |       .trim();
  148 |     if (texto.includes(MARCA) || /QR/i.test(texto)) break;
  149 |   }
  150 |   return texto;
  151 | }
  152 | 
  153 | test('cada estación muestra en la pantalla de compartir el texto de marca que puso el equipo', async ({ page }, testInfo) => {
  154 |   test.setTimeout(600_000);
  155 |   test.skip(testInfo.project.name !== 'chromium-desktop', 'Alcanza con un navegador.');
  156 |   await enchufarCamara(page);
  157 | 
  158 |   const noLoRespetan: string[] = [];
  159 | 
  160 |   for (const estacion of ESTACIONES) {
  161 |     const acceso = crearPermisoDeEstacion(ID, estacion.modulo);
  162 |     await page.goto(`/evento/${estacion.ruta}/${ID}?access=${acceso}`, { waitUntil: 'domcontentloaded' });
  163 |     await page.waitForTimeout(4_000);
  164 | 
  165 |     let texto = await llegarACompartir(page);
  166 | 
  167 |     // Touchpix no muestra la marca al capturar: la tiene en la ventanita del QR,
  168 |     // que se abre con el boton "Compartir". Hay que tocarlo.
  169 |     if (!texto.includes(MARCA)) {
  170 |       const compartir = page.getByRole('button', { name: /compartir/i }).first();
  171 |       if ((await compartir.count()) > 0) {
  172 |         await compartir.click().catch(() => {});
  173 |         await page.waitForTimeout(3_000);
  174 |         texto = ((await page.locator('body').innerText().catch(() => '')) || '')
  175 |           .replace(/\s+/g, ' ')
  176 |           .trim();
  177 |       }
  178 |     }
  179 | 
  180 |     if (!texto) {
  181 |       noLoRespetan.push(`${estacion.nombre}: no hay boton para sacar la captura`);
  182 |     } else if (!texto.includes(MARCA)) {
  183 |       // Se separan las dos fallas posibles: no llegar, o llegar y no respetar.
  184 |       const llego = /QR/i.test(texto);
  185 |       noLoRespetan.push(
  186 |         llego
  187 |           ? `${estacion.nombre}: llego a la pantalla de compartir y NO muestra el texto de marca configurado`
  188 |           : `${estacion.nombre}: no llego a la pantalla de compartir en 90 segundos`,
  189 |       );
  190 |     }
  191 |   }
  192 | 
> 193 |   expect(noLoRespetan.join('\n'), noLoRespetan.join('\n')).toBe('');
      |                                                            ^ Error: Bogue: no llego a la pantalla de compartir en 90 segundos
  194 | });
  195 | 
  196 | test('el buzón respeta la cuenta regresiva que puso el equipo', async ({ page }, testInfo) => {
  197 |   test.setTimeout(180_000);
  198 |   test.skip(testInfo.project.name !== 'chromium-desktop', 'Alcanza con un navegador.');
  199 |   await enchufarCamara(page);
  200 | 
  201 |   const acceso = crearPermisoDeEstacion(ID, 'capsulaTiempo');
  202 |   const respuesta = await page.goto(`/evento/buzon/${ID}?access=${acceso}`, {
  203 |     waitUntil: 'domcontentloaded',
  204 |   });
  205 |   expect(respuesta?.status(), 'el buzón abre').toBeLessThan(400);
  206 |   await page.waitForTimeout(3_000);
  207 | 
  208 |   const texto = ((await page.locator('body').innerText().catch(() => '')) || '').trim();
  209 |   // No se le pide más que estar sano: el buzón graba mensajes, no saca tandas.
  210 |   expect(texto, 'el buzón no muestra texto técnico').not.toMatch(
  211 |     /undefined|firestore|is not a valid|Algo sali[oó] mal/i,
  212 |   );
  213 |   expect(texto.length, 'el buzón muestra su pantalla').toBeGreaterThan(50);
  214 | });
  215 | 
```