# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: ak207-la-grilla-de-caras.spec.ts >> Orden 36: La grilla de caras >> la selfie no sale del teléfono ni se manda a la red
- Location: tests\e2e\ak207-la-grilla-de-caras.spec.ts:278:7

# Error details

```
Error: expect(received).toBeGreaterThan(expected)

Expected: > 0
Received:   0

Call Log:
- Timeout 75000ms exceeded while waiting on the predicate
```

# Test source

```ts
  207 |     await expect(botonEncontrame).toHaveCount(0);
  208 | 
  209 |     // La grilla de caras tampoco debe mostrarse
  210 |     const grillaCaras = page.locator('[data-testid="grilla-caras"]');
  211 |     await expect(grillaCaras).toHaveCount(0);
  212 |   });
  213 | 
  214 |   test('la grilla muestra caritas sin nombres y permite descargar las fotos de una persona', async ({ page }, testInfo) => {
  215 |     test.setTimeout(120_000);
  216 | 
  217 |     await page.goto(`/evento/galeria/${ID_PREPARADA}`, { waitUntil: 'domcontentloaded' });
  218 |     await page.waitForTimeout(4000);
  219 | 
  220 |     // La grilla de caras debe ser visible
  221 |     const grilla = page.locator('[data-testid="grilla-caras"]');
  222 |     await expect(grilla).toBeVisible();
  223 | 
  224 |     // Deben haber 2 caras (Ana y Beto, el que pasaba por atrás se filtró)
  225 |     const caritas = grilla.locator('button');
  226 |     await expect(caritas).toHaveCount(2);
  227 | 
  228 |     // REGLA 2: NUNCA un nombre al lado de una cara
  229 |     const textoGrilla = await grilla.innerText();
  230 |     expect(textoGrilla.trim()).toBe(''); // Las caritas no tienen texto
  231 | 
  232 |     // Al tocar una cara se filtran sus fotos y aparece "Descargar todas"
  233 |     await caritas.first().click();
  234 |     await expect(page.getByText(/Fotos de esta persona/i)).toBeVisible();
  235 |     await expect(page.getByRole('button', { name: /Descargar todas/i })).toBeVisible();
  236 | 
  237 |     // Siempre a la vista: "Ver todas las fotos de la fiesta"
  238 |     const botonVerTodas = page.getByRole('button', { name: /Ver todas las fotos de la fiesta/i }).first();
  239 |     await expect(botonVerTodas).toBeVisible();
  240 |     await botonVerTodas.click();
  241 | 
  242 |     // Vuelve a la galería completa
  243 |     await expect(page.getByText(/Fotos de esta persona/i)).toHaveCount(0);
  244 |   });
  245 | 
  246 |   test('con el interruptor apagado no se ve ni la grilla ni el botón', async ({ page }, testInfo) => {
  247 |     test.setTimeout(120_000);
  248 | 
  249 |     await page.goto(`/evento/galeria/${ID_APAGADO}`, { waitUntil: 'domcontentloaded' });
  250 |     await page.waitForTimeout(3000);
  251 | 
  252 |     await expect(page.getByRole('button', { name: /Encontrame/i })).toHaveCount(0);
  253 |     await expect(page.locator('[data-testid="grilla-caras"]')).toHaveCount(0);
  254 |   });
  255 | 
  256 |   test('sin aceptar el permiso, la cámara no se prende y la galería sigue igual', async ({ page }, testInfo) => {
  257 |     test.setTimeout(120_000);
  258 | 
  259 |     await page.goto(`/evento/galeria/${ID_PREPARADA}`, { waitUntil: 'domcontentloaded' });
  260 |     await page.waitForTimeout(3000);
  261 | 
  262 |     const boton = page.getByRole('button', { name: /Encontrame a mí/i });
  263 |     await expect(boton).toBeVisible();
  264 |     await boton.click();
  265 | 
  266 |     // Debe mostrar el cartel de permiso claro
  267 |     await expect(
  268 |       page.getByText(/Vamos a mirar tu cara en este teléfono para buscar tus fotos\. No se guarda ni se manda a ningún lado\./i),
  269 |     ).toBeVisible();
  270 | 
  271 |     // Si cancela, el modal se cierra y la galería sigue igual
  272 |     await page.getByRole('button', { name: /Cancelar/i }).click();
  273 |     await expect(
  274 |       page.getByText(/Vamos a mirar tu cara en este teléfono/i),
  275 |     ).toHaveCount(0);
  276 |   });
  277 | 
  278 |   test('la selfie no sale del teléfono ni se manda a la red', async ({ page }, testInfo) => {
  279 |     test.setTimeout(120_000);
  280 | 
  281 |     await enchufarCamara(page);
  282 | 
  283 |     // Monitoreamos toda llamada de red para verificar que NUNCA viaje una imagen
  284 |     const llamadasConImagenes: string[] = [];
  285 |     page.on('request', (req) => {
  286 |       const url = req.url();
  287 |       const postData = req.postData() || '';
  288 |       if (
  289 |         postData.includes('data:image') ||
  290 |         postData.includes('base64') ||
  291 |         /upload|selfie|face-api|tensor|ai-vision/i.test(url)
  292 |       ) {
  293 |         llamadasConImagenes.push(`${req.method()} ${url}`);
  294 |       }
  295 |     });
  296 | 
  297 |     await page.goto(`/evento/galeria/${ID_PREPARADA}`, { waitUntil: 'domcontentloaded' });
  298 |     await page.waitForTimeout(3000);
  299 | 
  300 |     // Abrir "Encontrame a mí"
  301 |     await page.getByRole('button', { name: /Encontrame a mí/i }).click();
  302 | 
  303 |     // Aceptar permiso
  304 |     await page.getByRole('button', { name: /Entendido, buscar mis fotos/i }).click();
  305 | 
  306 |     // Wait for the real terminal state only AFTER accepting the selfie.
> 307 |     await expect.poll(()=>page.getByRole("heading",{name:/Resultados de tu búsqueda|No encontramos fotos tuyas todavía/i}).evaluateAll(nodes=>nodes.filter(n=>{const r=n.getBoundingClientRect();return r.width>0&&r.height>0;}).length),{timeout:75000}).toBeGreaterThan(0);
      |                                                                                                                                                                                                                                                           ^ Error: expect(received).toBeGreaterThan(expected)
  308 | 
  309 |     // LA REGLA MÁS IMPORTANTE: Que no se dispare ninguna llamada al servidor con la imagen
  310 |     expect(llamadasConImagenes, 'la selfie no se envió a ningún servidor externo ni local').toHaveLength(0);
  311 | 
  312 |     // Debe mostrar la vista de resultados o el mensaje de "no encontramos".
  313 |     // Los dos titulos conviven en la pantalla, asi que hay que contar cuantos se
  314 |     // ven y no preguntar por "el" titulo: preguntando de a uno, Playwright corta
  315 |     // por ambiguedad (paso el 4 de septiembre de 2026).
  316 |     const titulos = page.getByRole('heading', {
  317 |       name: /Resultados de tu búsqueda|No encontramos fotos tuyas todavía/i,
  318 |     });
  319 |     let visibles = 0;
  320 |     for (let i = 0; i < (await titulos.count()); i += 1) {
  321 |       if (await titulos.nth(i).isVisible()) visibles += 1;
  322 |     }
  323 |     expect(visibles, 'muestra la pantalla de resultados, armada en el propio teléfono').toBeGreaterThan(0);
  324 |   });
  325 | });
  326 | 
```