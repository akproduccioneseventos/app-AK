# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: ak207-muro-subir-foto.spec.ts >> el invitado sube una foto al muro >> encuentra cómo compartir y, si falla, se entera
- Location: tests\e2e\ak207-muro-subir-foto.spec.ts:79:7

# Error details

```
Error: El invitado tocó publicar y no recibió ninguna respuesta: no sabe si su foto salió o no

expect(locator).toBeVisible() failed

Locator: getByText(/No se pudo publicar|publicada|Se subió|subida/i).first()
Expected: visible
Timeout: 45000ms
Error: element(s) not found

Call log:
  - El invitado tocó publicar y no recibió ninguna respuesta: no sabe si su foto salió o no with timeout 45000ms
  - waiting for getByText(/No se pudo publicar|publicada|Se subió|subida/i).first()

```

```yaml
- banner:
  - heading "Muro social de Valentina" [level=1]
  - paragraph: Hola, Lucía Fernández
  - 'link "Mi mesa: buscar dónde me siento"':
    - /url: /evento/mi-mesa/e2e_muro_1792933037820?guestId=inv_prueba_0&token=token-prueba-0
    - img
    - text: Mi Mesa
  - button "Actualizar":
    - img
- navigation:
  - button "Inicio" [pressed]:
    - img
    - text: Inicio
  - button "Cronograma":
    - img
    - text: Cronograma
  - button "Ranking":
    - img
    - text: Ranking
  - button "Misiones":
    - img
    - text: Misiones
  - button "Canciones":
    - img
    - text: Canciones
  - button "Mensajes":
    - img
    - text: Mensajes
  - button "Chat":
    - img
    - text: Chat
- main:
  - img
  - text: ¿Cuándo cumplís tus quince?
  - button "Cerrar pregunta de 15":
    - img
  - button "Ya los festejé"
  - button "Este año"
  - button "El año que viene"
  - button "No es lo mío"
  - text: ¿Querés guardar el enlace de tus fotos? Para volver a ver tu recuerdo y video mañana.
  - link "Mandármelo por WhatsApp":
    - /url: https://wa.me/?text=%C2%A1Hola!%20Guard%C3%A1%20este%20enlace%20para%20ver%20tus%20fotos%20y%20el%20video%20recuerdo%20de%20la%20fiesta%20ma%C3%B1ana%3A%20http%3A%2F%2F127.0.0.1%3A3300%2Finvitacion%2Fe2e_muro_1792933037820%2Frecap%3FguestId%3Dinv_prueba_0%26token%3Dtoken-prueba-0
    - img
    - text: Mandármelo por WhatsApp
  - text: LF
  - button "¿Qué querés compartir?"
  - button "Foto":
    - img
    - text: Foto
  - button "Video":
    - img
    - text: Video
  - img
  - paragraph: Todavía no hay publicaciones
  - paragraph: Sé la primera persona en compartir un momento de la fiesta.
  - button "Subí tu primera foto"
  - paragraph: Todo lo que subas aparece también en la pantalla grande del salón.
  - link "¿Te toca festejar el año que viene? Mirá cuánto sale tu fiesta":
    - /url: /simulador-de-presupuesto?source=guest_portal&campaign=muro_social&refFiesta=e2e_muro_1792933037820
  - button "👏"
  - button "❤️"
  - button "🔥"
- region "Notifications (F8)":
  - list
- alert
```

# Test source

```ts
  24  |   if(item.collection&&Array.isArray(item.data))for(const[rowIndex,row]of item.data.entries())await set(__db608.collection(item.collection).doc(String(row.id||'qa608-'+rowIndex)),row);
  25  |  }
  26  |  const folder=path608.join(process.cwd(),'data/fiestas');if(fs608.existsSync(folder))for(const name of fs608.readdirSync(folder))if(/^.*\.json$/.test(name)){const f=JSON.parse(fs608.readFileSync(path608.join(folder,name),'utf8'));await set(__db608.collection('fiestas').doc(f.id),f);}
  27  |  const meta=path608.join(process.cwd(),'data/social-gallery/metadata.json');if(fs608.existsSync(meta))for(const row of JSON.parse(fs608.readFileSync(meta,'utf8')))await set(__db608.collection('social_gallery_posts').doc(row.id),row);
  28  |  if(count)await batch.commit();
  29  | });
  30  | __akAudit207.afterEach(async({},info)=>{const result={budgets:[],leads:[]};for(const[name,key]of[['presupuestos','budgets'],['prospectos','leads']]){const rows=await __db608.collection(name).get();result[key]=rows.docs.map(d=>({id:d.id,nombre:d.data().clienteNombre||d.data().nombre||d.data().name,total:d.data().totalFinal||d.data().total||d.data().totalAmount}));}await info.attach('qa608-sdk-persistence',{contentType:'application/json',body:Buffer.from(JSON.stringify(result))});});
  31  | __akAudit207.afterAll(async()=>{await __db608.terminate();await __app608.deleteApp(__instance608);});
  32  | 
  33  | __akAudit207.beforeEach(async({page})=>{
  34  |  const events=[];page.__qa604events=events;
  35  |  page.on('request',r=>{if(r.method()==='POST')events.push({kind:'request',url:new URL(r.url()).pathname,method:r.method(),contentType:r.headers()['content-type']||''});});
  36  |  page.on('response',r=>{if(r.request().method()==='POST')events.push({kind:'response',url:new URL(r.url()).pathname,status:r.status()});});
  37  |  page.on('pageerror',e=>events.push({kind:'pageerror',message:e.message}));
  38  |  await page.addInitScript(()=>{const Native=window.MediaRecorder;window.__qa604recorders=[];if(Native)window.MediaRecorder=class extends Native{constructor(...args){super(...args);const entry={mime:this.mimeType,tracks:this.stream.getTracks().map(t=>({kind:t.kind,state:t.readyState})),events:[]};window.__qa604recorders.push(entry);for(const name of ['start','stop','error','dataavailable'])this.addEventListener(name,e=>entry.events.push({name,bytes:e.data?.size,message:e.error?.message}));}};});
  39  | });
  40  | __akAudit207.afterEach(async({page},info)=>{await info.attach('qa604-observations',{contentType:'application/json',body:Buffer.from(JSON.stringify({url:page.url(),events:page.__qa604events||[],body:await page.locator('body').innerText({timeout:3000}).catch(()=>'<unavailable>'),media:await page.evaluate(()=>({recorders:window.__qa604recorders||[],videos:[...document.querySelectorAll('video')].map(v=>({ready:v.readyState,width:v.videoWidth,height:v.videoHeight,paused:v.paused,src:v.src.startsWith('blob:')?'blob':v.src,tracks:v.srcObject?.getTracks?.().map(t=>({kind:t.kind,state:t.readyState}))}))})).catch(()=>null)}))});});
  41  | import { expect, test } from '@playwright/test';
  42  | import { borrarFiesta, crearFiestaDeEstaNoche } from './helpers/fiesta-de-prueba';
  43  | 
  44  | /**
  45  |  * El invitado subiendo una foto al muro, hasta donde se puede probar acá.
  46  |  *
  47  |  * La foto termina guardándose en el servicio de archivos de Firebase, que no
  48  |  * existe en este entorno. Eso deja **una sola cosa** sin probar: que los bytes
  49  |  * lleguen al servidor de Google.
  50  |  *
  51  |  * Todo lo anterior sí se prueba, y es donde estaban los problemas: que el
  52  |  * invitado encuentre el botón, que pueda poner su nombre, que elija una foto, y
  53  |  * sobre todo que **si algo falla se entere**. Un muro que se traga la foto sin
  54  |  * decir nada es peor que uno que avisa: el invitado se queda esperando que
  55  |  * aparezca en la pantalla del salón y nunca aparece.
  56  |  */
  57  | 
  58  | const fiesta = crearFiestaDeEstaNoche({ id: `e2e_muro_${Date.now()}` });
  59  | const ID = fiesta.id;
  60  | 
  61  | /** Un invitado de la lista, con su enlace personal. */
  62  | const INVITADO = { id: 'inv_prueba_0', token: 'token-prueba-0' };
  63  | 
  64  | /** Una imagen mínima de verdad, para que el navegador la trate como foto. */
  65  | const FOTO_DE_PRUEBA = {
  66  |   name: 'foto-de-prueba.png',
  67  |   mimeType: 'image/png',
  68  |   buffer: Buffer.from(
  69  |     'iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR42mP8z8BQDwAEhQGAhKmMIQAAAABJRU5ErkJggg==',
  70  |     'base64',
  71  |   ),
  72  | };
  73  | 
  74  | test.afterAll(() => {
  75  |   borrarFiesta(ID);
  76  | });
  77  | 
  78  | test.describe('el invitado sube una foto al muro', () => {
  79  |   test('encuentra cómo compartir y, si falla, se entera', async ({ page }) => {
  80  |     test.setTimeout(300_000);
  81  | 
  82  |     const erroresJs: string[] = [];
  83  |     page.on('pageerror', (e) => erroresJs.push(e.message));
  84  | 
  85  |     // Se entra con el enlace personal del invitado, que es como llega de verdad:
  86  |     // sin él, el muro sólo deja mirar y avisa "abrí tu enlace personal para
  87  |     // publicar".
  88  |     await page.goto(`/evento/social/${ID}?guestId=${INVITADO.id}&token=${INVITADO.token}`, {
  89  |       waitUntil: 'domcontentloaded',
  90  |     });
  91  | 
  92  |     // Al entrar por primera vez, el muro pide el nombre: es lo que después
  93  |     // aparece debajo de la foto en la pantalla del salón.
  94  |     const campoNombre = page.getByPlaceholder(/Ej: Sofía Pérez|Tu nombre/i).first();
  95  |     if (await campoNombre.isVisible().catch(() => false)) {
  96  |       await campoNombre.fill('Invitada de prueba');
  97  |       await page.getByRole('button', { name: /Continuar|Entrar|Listo/i }).first().click();
  98  |       await page.waitForTimeout(2000);
  99  |     }
  100 | 
  101 |     // El botón para compartir tiene que estar a la vista, sin buscarlo.
  102 |     const compartir = page.getByText(/Qué querés compartir/i).first();
  103 |     await expect(compartir, 'El invitado no encuentra cómo subir una foto').toBeVisible({ timeout: 45_000 });
  104 |     await compartir.click();
  105 |     await page.waitForTimeout(1500);
  106 | 
  107 |     // Elige una foto de su celular.
  108 |     const campoArchivo = page.locator('input[type="file"]').first();
  109 |     await expect(campoArchivo, 'No hay dónde elegir la foto').toHaveCount(1, { timeout: 20_000 });
  110 |     await campoArchivo.setInputFiles(FOTO_DE_PRUEBA);
  111 |     await page.waitForTimeout(2000);
  112 | 
  113 |     const publicar = page.getByRole('button', { name: /^Publicar/i }).first();
  114 |     await expect(publicar, 'No aparece el botón de publicar').toBeVisible({ timeout: 20_000 });
  115 |     await publicar.click();
  116 | 
  117 |     // Lo que importa: pase lo que pase, el invitado tiene que recibir una
  118 |     // respuesta. En este entorno el guardado falla porque no hay servicio de
  119 |     // archivos, así que lo correcto es ver el aviso de que no se pudo.
  120 |     const respuesta = page.getByText(/No se pudo publicar|publicada|Se subió|subida/i).first();
  121 |     await expect(
  122 |       respuesta,
  123 |       'El invitado tocó publicar y no recibió ninguna respuesta: no sabe si su foto salió o no',
> 124 |     ).toBeVisible({ timeout: 45_000 });
      |       ^ Error: El invitado tocó publicar y no recibió ninguna respuesta: no sabe si su foto salió o no
  125 | 
  126 |     expect(erroresJs, `El muro tuvo fallas de JavaScript:\n${erroresJs.join('\n')}`).toEqual([]);
  127 |   });
  128 | 
  129 |   test('el muro no se cuelga después de un intento fallido', async ({ page }) => {
  130 |     test.setTimeout(180_000);
  131 | 
  132 |     // Después de un error, la pantalla tiene que seguir usable: el invitado
  133 |     // suele probar de nuevo.
  134 |     await page.goto(`/evento/social/${ID}`, { waitUntil: 'domcontentloaded' });
  135 | 
  136 |     // El muro pide varias cosas al servidor antes de dibujarse; se le da el
  137 |     // mismo margen que en la fiesta real.
  138 |     let texto = '';
  139 |     const arranque = Date.now();
  140 |     while (Date.now() - arranque < 20_000) {
  141 |       texto = await page.locator('body').innerText().catch(() => '');
  142 |       if (texto.trim().length > 40) break;
  143 |       await page.waitForTimeout(1000);
  144 |     }
  145 | 
  146 |     expect(texto.trim().length, 'El muro quedó en blanco').toBeGreaterThan(40);
  147 |     expect(texto).not.toMatch(/NaN|Infinity|\[object Object\]|Failed to fetch/);
  148 |   });
  149 | });
  150 | 
```