# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: ak207-entertainment-stations.spec.ts >> time capsule exposes every media mode and records the configured frame
- Location: tests\e2e\ak207-entertainment-stations.spec.ts:152:5

# Error details

```
Error: expect(received).toBeGreaterThan(expected)

Expected: > 0
Received:   0

Call Log:
- Timeout 45000ms exceeded while waiting on the predicate
```

# Test source

```ts
  117 |     expect(response?.status(), route).toBeLessThan(400);
  118 |     await expect(page.locator('body'), route).not.toContainText(/acceso de estacion no autorizado|no se pudo abrir esta estacion/i);
  119 |     await expect(page.locator('button:visible').first(), route).toBeVisible();
  120 |   }
  121 | });
  122 | 
  123 | test('photobooth display receives a browser camera stream', async ({ context, page }, testInfo) => {
  124 |   const baseURL = testInfo.project.use.baseURL as string;
  125 |   await addAppSession(context, baseURL);
  126 |   await page.addInitScript(() => {
  127 |     const getUserMedia = async () => {
  128 |       const canvas = document.createElement('canvas');
  129 |       canvas.width = 720;
  130 |       canvas.height = 1280;
  131 |       const drawing = canvas.getContext('2d');
  132 |       drawing?.fillRect(0, 0, canvas.width, canvas.height);
  133 |       const c604=canvas;const s604=canvas.captureStream(30);const p604=setInterval(()=>{const c=c604.getContext("2d");c.fillStyle=Date.now()%2?"#fefefe":"#eeeeee";c.fillRect(100,100,15,15);},33);for(const t of s604.getTracks()){const stop=t.stop.bind(t);t.stop=()=>{clearInterval(p604);stop();};}return s604;
  134 |     };
  135 |     Object.defineProperty(navigator, 'mediaDevices', {
  136 |       configurable: true,
  137 |       value: { getUserMedia },
  138 |     });
  139 |   });
  140 | 
  141 |   const response = await page.goto(`/evento/fotocabina/${FIESTA_ID}`, { waitUntil: 'domcontentloaded' });
  142 |   expect(response?.status()).toBeLessThan(400);
  143 |   await expect(page.locator('body')).not.toContainText(/acceso de estacion no autorizado|no se pudo abrir esta estacion/i);
  144 |   // El invitado tiene que VERSE. Puede ser en el `<video>` directo o en el
  145 |   // lienzo de la vista previa: desde que la fotocabina cambia el fondo en vivo,
  146 |   // el video queda oculto a proposito y lo que se muestra es el lienzo con el
  147 |   // fondo ya aplicado. Lo que importa es que se vea la camara, no en cual de
  148 |   // los dos elementos.
  149 |   await expect(page.locator('video:visible, canvas:visible').first()).toBeVisible();
  150 | });
  151 | 
  152 | test('time capsule exposes every media mode and records the configured frame', async ({ context, page }, testInfo) => {
  153 |   test.setTimeout(180000);test.skip(testInfo.project.name !== 'chromium-desktop', 'MediaRecorder coverage only needs Chromium desktop.');
  154 |   const baseURL = testInfo.project.use.baseURL as string;
  155 |   await addAppSession(context, baseURL);
  156 |   await page.addInitScript(() => {
  157 |     const getUserMedia = async () => {
  158 |       const canvas = document.createElement('canvas');
  159 |       canvas.width = 640;
  160 |       canvas.height = 480;
  161 |       const drawing = canvas.getContext('2d');
  162 |       if (drawing) {
  163 |         drawing.fillStyle = '#1e3a5f';
  164 |         drawing.fillRect(0, 0, canvas.width, canvas.height);
  165 |       }
  166 |       const stream = canvas.captureStream(20);const ac616=new AudioContext();const dest616=ac616.createMediaStreamDestination();const oscillator616=ac616.createOscillator();oscillator616.connect(dest616);oscillator616.start();await ac616.resume();for(const a of dest616.stream.getAudioTracks())stream.addTrack(a);const pump616=setInterval(()=>{const c=canvas.getContext("2d");c.fillStyle="#ffffff";c.fillRect((Date.now()/10)%550,80,20,20);},33);for(const t of stream.getTracks()){const stop=t.stop.bind(t);t.stop=()=>{clearInterval(pump616);stop();ac616.close().catch(()=>{});};}
  167 |       const testWindow = window as typeof window & { __buzonTestStreams?: MediaStream[] };
  168 |       testWindow.__buzonTestStreams = [...(testWindow.__buzonTestStreams || []), stream];
  169 |       return stream;
  170 |     };
  171 |     Object.defineProperty(navigator, 'mediaDevices', {
  172 |       configurable: true,
  173 |       value: { getUserMedia },
  174 |     });
  175 |   });
  176 | 
  177 |   const response = await page.goto(`/evento/buzon/${FIESTA_ID}`, { waitUntil: 'domcontentloaded' });
  178 |   expect(response?.status()).toBeLessThan(400);
  179 |   await expect(page.getByRole('button', { name: /Grabar Video/i })).toBeVisible();
  180 |   await expect(page.getByRole('button', { name: /Mensaje de Audio/i })).toBeVisible();
  181 |   await expect(page.getByRole('button', { name: /Subir video/i })).toBeVisible();
  182 |   await expect(page.getByRole('button', { name: /Subir audio/i })).toBeVisible();
  183 |   await expect(page.getByRole('button', { name: /Cabina telefónica retro/i })).toBeVisible();
  184 | 
  185 |   await page.getByRole('button', { name: /Grabar Video/i }).click();
  186 |   const frameCanvas = page.locator('canvas').first();
  187 |   await expect(frameCanvas).toBeVisible();
  188 |   await expect.poll(async () => frameCanvas.evaluate((element) => {
  189 |     const canvas = element as HTMLCanvasElement;
  190 |     const drawing = canvas.getContext('2d');
  191 |     if (!drawing || canvas.width !== 640 || canvas.height !== 480) return 0;
  192 |     const pixels = drawing.getImageData(0, 0, 40, canvas.height).data;
  193 |     let floralPixels = 0;
  194 |     for (let index = 0; index < pixels.length; index += 4) {
  195 |       const red = pixels[index];
  196 |       const green = pixels[index + 1];
  197 |       const blue = pixels[index + 2];
  198 |       if (green > 170 && green > red * 1.25 && blue > 100) floralPixels += 1;
  199 |     }
  200 |     return floralPixels;
  201 |   })).toBeGreaterThan(20);
  202 | 
  203 |   await page.getByRole('button', { name: /Comenzar a Grabar/i }).click();
  204 |   const stopButton = page.getByRole('button', { name: /Detener Grabación/i });
  205 |   await expect(stopButton).toBeVisible();
  206 |   await page.waitForTimeout(1_000);
  207 |   await stopButton.click();
  208 |   // La etiqueta se llama "Video Grabado", no "Video Analogico". Se verifico en
  209 |   // `src/app/evento/buzon/[fiestaId]/page.tsx`: el paso de revision existe y
  210 |   // funciona, solo cambio el texto. La prueba habia quedado con el nombre viejo.
  211 |   await expect(page.getByText('Video Grabado')).toBeVisible();
  212 |   const reviewVideo = page.locator('video[src^="blob:"]').first();
  213 |   await expect(reviewVideo).toBeVisible();
  214 |   await expect.poll(async () => reviewVideo.evaluate(async (element) => {
  215 |     const source = (element as HTMLVideoElement).src;
  216 |     return (await (await fetch(source)).blob()).size;
> 217 |   })).toBeGreaterThan(0);
      |       ^ Error: expect(received).toBeGreaterThan(expected)
  218 | 
  219 |   await page.getByRole('button', { name: /Grabar de nuevo/i }).click();
  220 |   await expect(page.getByRole('button', { name: /Comenzar a Grabar/i })).toBeVisible();
  221 |   await page.getByRole('button', { name: /Volver al menú/i }).click();
  222 |   await expect.poll(() => page.evaluate(() => {
  223 |     const testWindow = window as typeof window & { __buzonTestStreams?: MediaStream[] };
  224 |     return (testWindow.__buzonTestStreams || []).every(
  225 |       (mediaStream) => mediaStream.getTracks().every((track) => track.readyState === 'ended'),
  226 |     );
  227 |   })).toBe(true);
  228 | });
  229 | 
  230 | test('time capsule bakes the configured frame into an uploaded gallery video', async ({ context, page }, testInfo) => {
  231 |   test.skip(testInfo.project.name !== 'chromium-desktop', 'Browser video processing only needs Chromium desktop.');
  232 |   const baseURL = testInfo.project.use.baseURL as string;
  233 |   await addAppSession(context, baseURL);
  234 | 
  235 |   const response = await page.goto(`/evento/buzon/${FIESTA_ID}`, { waitUntil: 'domcontentloaded' });
  236 |   expect(response?.status()).toBeLessThan(400);
  237 |   await page.getByRole('button', { name: /Subir video/i }).click();
  238 |   const input = page.locator('input[type="file"][accept="video/*"]');
  239 |   await input.evaluate(async (element) => {
  240 |     const canvas = document.createElement('canvas');
  241 |     canvas.width = 320;
  242 |     canvas.height = 240;
  243 |     const drawing = canvas.getContext('2d');
  244 |     if (drawing) {
  245 |       drawing.fillStyle = '#1e3a5f';
  246 |       drawing.fillRect(0, 0, canvas.width, canvas.height);
  247 |     }
  248 |     const stream = canvas.captureStream(20);
  249 |     const candidates = ['video/mp4', 'video/webm;codecs=vp9', 'video/webm'];
  250 |     const mimeType = candidates.find((candidate) => MediaRecorder.isTypeSupported(candidate)) || '';
  251 |     const recorder = mimeType ? new MediaRecorder(stream, { mimeType }) : new MediaRecorder(stream);
  252 |     const chunks: Blob[] = [];
  253 |     recorder.ondataavailable = (event) => {
  254 |       if (event.data.size > 0) chunks.push(event.data);
  255 |     };
  256 |     const stopped = new Promise<void>((resolve) => {
  257 |       recorder.onstop = () => resolve();
  258 |     });
  259 |     recorder.start(100);
  260 |     let frame = 0;
  261 |     const drawingInterval = window.setInterval(() => {
  262 |       if (!drawing) return;
  263 |       drawing.fillStyle = frame % 2 === 0 ? '#1e3a5f' : '#315b82';
  264 |       drawing.fillRect(0, 0, canvas.width, canvas.height);
  265 |       drawing.fillStyle = '#ffffff';
  266 |       drawing.fillRect((frame * 8) % canvas.width, 80, 40, 40);
  267 |       frame += 1;
  268 |     }, 50);
  269 |     await new Promise((resolve) => setTimeout(resolve, 1_500));
  270 |     window.clearInterval(drawingInterval);
  271 |     recorder.stop();
  272 |     await stopped;
  273 |     stream.getTracks().forEach((track) => track.stop());
  274 | 
  275 |     const outputType = recorder.mimeType || mimeType || 'video/webm';
  276 |     const extension = outputType.includes('mp4') ? 'mp4' : 'webm';
  277 |     const transfer = new DataTransfer();
  278 |     transfer.items.add(new File(chunks, `gallery-test.${extension}`, { type: outputType }));
  279 |     const fileInput = element as HTMLInputElement;
  280 |     fileInput.files = transfer.files;
  281 |     fileInput.dispatchEvent(new Event('change', { bubbles: true }));
  282 |   });
  283 | 
  284 |   await expect(page.getByText('Video Cargado')).toBeVisible();
  285 |   const reviewVideo = page.locator('video[src^="blob:"]').first();
  286 |   await expect(reviewVideo).toBeVisible();
  287 |   await expect.poll(async () => reviewVideo.evaluate(async (element) => {
  288 |     const video = element as HTMLVideoElement;
  289 |     video.muted = true;
  290 |     await video.play();
  291 |     await new Promise((resolve) => setTimeout(resolve, 250));
  292 |     const canvas = document.createElement('canvas');
  293 |     canvas.width = 640;
  294 |     canvas.height = 480;
  295 |     const drawing = canvas.getContext('2d');
  296 |     if (!drawing) return 0;
  297 |     drawing.drawImage(video, 0, 0, canvas.width, canvas.height);
  298 |     const pixels = drawing.getImageData(0, 0, 40, canvas.height).data;
  299 |     let floralPixels = 0;
  300 |     for (let index = 0; index < pixels.length; index += 4) {
  301 |       const red = pixels[index];
  302 |       const green = pixels[index + 1];
  303 |       const blue = pixels[index + 2];
  304 |       if (green > 170 && green > red * 1.25 && blue > 100) floralPixels += 1;
  305 |     }
  306 |     return floralPixels;
  307 |   })).toBeGreaterThan(20);
  308 | });
  309 | 
  310 | test('AI mirror keeps one coherent touch selector on desktop and mobile', async ({ context, page }, testInfo) => {
  311 |   const baseURL = testInfo.project.use.baseURL as string;
  312 |   await addAppSession(context, baseURL);
  313 |   await page.addInitScript(() => {
  314 |     const getUserMedia = async () => {
  315 |       const canvas = document.createElement('canvas');
  316 |       canvas.width = 720;
  317 |       canvas.height = 1280;
```