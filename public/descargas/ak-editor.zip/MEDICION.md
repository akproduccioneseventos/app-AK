# Mediciones de AK Editor en la computadora del dueño

Todavía no se probó con una fiesta real.

## Medición de corrida real — 2026-11-10 22:39:16
- **Material analizado**: 4.0 s (2 archivos)
- **Tiempo transcurrido**: 0.35 s
- **Memoria RAM máxima (proceso)**: 167.33 MB
- **Cortes revisados por el dueño**: sin revisar
- **Compatibilidad con Filmora**: sin probar

## Medición de corrida real — 2026-11-10 22:39:16
- **Material analizado**: 6.0 s (3 archivos)
- **Tiempo transcurrido**: 0.56 s
- **Memoria RAM máxima (proceso)**: 167.91 MB
- **Cortes revisados por el dueño**: sin revisar
- **Compatibilidad con Filmora**: sin probar
